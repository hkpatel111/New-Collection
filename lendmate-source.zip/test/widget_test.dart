import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:lendmate/core/app_localizations.dart';
import 'package:lendmate/core/theme.dart';

void main() {
  testWidgets('App shell renders with theme + localization', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.light(),
        localizationsDelegates: const [AppLocalizations.delegate],
        supportedLocales: AppLocalizations.supportedLocales,
        locale: const Locale('en'),
        home: const Scaffold(
          body: Center(child: Text('LendMate')),
        ),
      ),
    );
    expect(find.text('LendMate'), findsOneWidget);
  });

  test('Hindi localization falls back to English for any missing key', () {
    final hi = AppLocalizations(const Locale('hi'));
    final en = AppLocalizations(const Locale('en'));
    expect(hi.t('save'), isNot('save'));
    expect(en.t('save'), 'Save');
  });

  test('delegate supports en/hi/gu only', () {
    expect(AppLocalizations.delegate.isSupported(const Locale('en')), isTrue);
    expect(AppLocalizations.delegate.isSupported(const Locale('hi')), isTrue);
    expect(AppLocalizations.delegate.isSupported(const Locale('gu')), isTrue);
    expect(AppLocalizations.delegate.isSupported(const Locale('fr')), isFalse);
  });
}
