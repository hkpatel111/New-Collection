import 'package:flutter_test/flutter_test.dart';

import 'package:lendmate/core/enums.dart';
import 'package:lendmate/models/models.dart';
import 'package:lendmate/services/emi_engine.dart';

Loan _loan({
  double principal = 100000,
  double rate = 2,
  int emiCount = 12,
  InterestType type = InterestType.flat,
  PaymentCycle cycle = PaymentCycle.monthly,
  int everyNMonths = 1,
}) {
  return Loan(
    id: 't',
    businessId: 'b',
    borrowerId: 'x',
    borrowerName: 'Test',
    principal: principal,
    rate: rate,
    emiCount: emiCount,
    interestType: type,
    cycle: cycle,
    everyNMonths: everyNMonths,
    startDate: DateTime(2026, 1, 1),
  );
}

void main() {
  group('EmiEngine', () {
    test('flat: equal EMIs of principal + total interest split over n', () {
      final loan = _loan(); // 100000 @2%/mo flat, 12 months
      // total interest = 100000 * 2% * 12 cycles = 24000 → EMI = 124000/12
      final emi = EmiEngine.emiDue(loan, 1);
      expect(emi, closeTo(10333.33, 1));
    });

    test('flat: every EMI is identical', () {
      final loan = _loan();
      final a = EmiEngine.emiDue(loan, 1);
      final b = EmiEngine.emiDue(loan, 7);
      final c = EmiEngine.emiDue(loan, 12);
      expect(a, b);
      expect(b, c);
    });

    test('reducing: total payable is less than flat for same terms', () {
      final flat = _loan();
      final reducing = _loan(type: InterestType.reducing);
      final flatTotal = EmiEngine.summarize(
        principal: flat.principal,
        ratePctPerMonth: flat.rate,
        interestType: InterestType.flat,
        cycle: PaymentCycle.monthly,
        installments: 12,
      ).totalPayable;
      final reducingTotal = EmiEngine.summarize(
        principal: reducing.principal,
        ratePctPerMonth: reducing.rate,
        interestType: InterestType.reducing,
        cycle: PaymentCycle.monthly,
        installments: 12,
      ).totalPayable;
      expect(reducingTotal, lessThan(flatTotal));
    });

    test('interest-only: EMI is principal * rate, principal repaid at end '
        'via flat+interestOnly path', () {
      final loan = _loan(type: InterestType.interestOnly);
      final emi = EmiEngine.emiDue(loan, 1);
      expect(emi, closeTo(2000, 1)); // 100000 * 2%
    });

    test('schedule dates advance monthly', () {
      final loan = _loan();
      final rows = EmiEngine.buildSchedule(loan);
      expect(rows.length, 12);
      expect(rows[0].dueDate.month, 1 + 1); // start Jan → first due Feb
      expect(rows[0].dueDate.year, 2026);
    });

    test('weekly cycle advances 7 days', () {
      final loan = _loan(cycle: PaymentCycle.weekly, emiCount: 4);
      final rows = EmiEngine.buildSchedule(loan);
      expect(
        rows[1].dueDate.difference(rows[0].dueDate).inDays,
        7,
      );
    });

    test('custom cycle: every 3 months', () {
      final loan = _loan(cycle: PaymentCycle.custom, everyNMonths: 3);
      final rows = EmiEngine.buildSchedule(loan);
      expect(rows[0].dueDate.month, 4); // Jan + 3
      expect(rows[1].dueDate.month, 7);
    });

    test('payments fill earliest rows first (FIFO)', () {
      final loan = _loan();
      final payment = Payment(
        id: 'p',
        businessId: 'b',
        loanId: 't',
        borrowerId: 'x',
        amount: EmiEngine.emiDue(loan, 1) + 10,
        date: DateTime(2026, 2, 5),
      );
      final rows = EmiEngine.buildSchedule(loan, payments: [payment]);
      expect(rows[0].isPaid, isTrue);
      expect(rows[1].paid, closeTo(10, 0.01));
    });

    test('summarize totals add up', () {
      final s = EmiEngine.summarize(
        principal: 50000,
        ratePctPerMonth: 1.5,
        interestType: InterestType.flat,
        cycle: PaymentCycle.monthly,
        installments: 10,
      );
      expect(s.totalPayable, closeTo(s.emi * 10, 1));
      expect(s.totalInterest, closeTo(s.totalPayable - 50000, 1));
    });

    test('daily collection loan uses fixed daily amount when provided', () {
      final loan = _loan()
        ..category = LoanCategory.dailyCollection
        ..emiAmount = 500;
      expect(EmiEngine.emiDue(loan, 3), 500);
    });
  });
}
