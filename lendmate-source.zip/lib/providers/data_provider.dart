import 'dart:async';

import 'package:flutter/foundation.dart';

import '../core/utils.dart';
import '../models/models.dart';
import '../services/emi_engine.dart';
import '../services/repository.dart';

/// Holds live Repository-backed lists for the active business and exposes
/// computed dashboard/report numbers.
class DataProvider extends ChangeNotifier {
  final Repository _db = Repository.instance;

  StreamSubscription? _b, _c, _l, _p;

  List<Borrower> borrowers = [];
  List<Customer> customers = [];
  List<Loan> loans = [];
  List<Payment> payments = [];

  bool loaded = false;

  /// AuthProvider calls this after switching businesses.
  void resubscribe() {
    _b?.cancel();
    _c?.cancel();
    _l?.cancel();
    _p?.cancel();
    loaded = false;
    if (!_db.hasContext) {
      borrowers = [];
      customers = [];
      loans = [];
      payments = [];
      notifyListeners();
      return;
    }

    _b = _db.borrowersStream().listen((list) {
      borrowers = list;
      loaded = true;
      notifyListeners();
    });
    _c = _db.customersStream().listen((list) {
      customers = list;
      loaded = true;
      notifyListeners();
    });
    _l = _db.loansStream().listen((list) {
      loans = list;
      loaded = true;
      notifyListeners();
    });
    _p = _db.allPaymentsStream().listen((list) {
      payments = list;
      loaded = true;
      notifyListeners();
    });
  }

  void disposeStreams() {
    _b?.cancel();
    _c?.cancel();
    _l?.cancel();
    _p?.cancel();
  }

  // ------------------------------------------------------------------
  // Dashboard numbers
  // ------------------------------------------------------------------

  List<Loan> get activeLoans => loans.where((l) => l.isActive).toList();

  double get totalPrincipalOutstanding =>
      activeLoans.fold(0, (s, l) => s + l.balanceDue);

  double get totalPrincipalGiven =>
      loans.fold(0, (s, l) => s + l.principal);

  /// Collected today / this week / this month.
  Map<String, double> collectionTotals() {
    final now = DateTime.now();
    final today = Utils.dayStart(now);
    final weekStart = today.subtract(Duration(days: now.weekday - 1));
    final monthStart = DateTime(now.year, now.month, 1);

    var t = 0.0, w = 0.0, m = 0.0;
    for (final p in payments) {
      final amt = p.amount + p.lateFee;
      if (Utils.isSameDay(p.date, today)) t += amt;
      if (p.date.isAfter(weekStart) || Utils.isSameDay(p.date, weekStart)) {
        w += amt;
      }
      if (p.date.isAfter(monthStart) || Utils.isSameDay(p.date, monthStart)) {
        m += amt;
      }
    }
    return {'today': t, 'week': w, 'month': m};
  }

  /// Interest earned (paid - principal returned, simplified) vs overdue.
  Map<String, double> profitLossSummary() {
    var overdue = 0.0;
    for (final l in activeLoans) {
      for (final row in EmiEngine.buildSchedule(l)) {
        if (row.isOverdue) overdue += row.remaining;
      }
    }
    final earned = payments.fold(0.0, (s, p) => s + p.amount) -
        totalPrincipalRecovered;
    return {
      'interestEarned': earned < 0 ? 0.0 : earned,
      'overdue': overdue,
    };
  }

  double get totalPrincipalRecovered {
    var recovered = 0.0;
    for (final l in loans) {
      recovered += (l.totalPaid).clamp(0.0, l.totalPayable == 0 ? l.totalPaid : l.totalPayable);
    }
    return recovered;
  }

  /// Upcoming + overdue EMIs grouped by date for the due calendar.
  Map<DateTime, double> dueCalendar({int days = 31}) {
    final map = <DateTime, double>{};
    final now = DateTime.now();
    for (final l in activeLoans) {
      for (final row in EmiEngine.buildSchedule(l)) {
        final d = Utils.dayStart(row.dueDate);
        if (d.isBefore(now) && row.isPaid) continue;
        if (d.isAfter(now.add(Duration(days: days)))) continue;
        map[d] = (map[d] ?? 0) + (row.isPaid ? 0 : row.remaining);
      }
    }
    return map;
  }
}
