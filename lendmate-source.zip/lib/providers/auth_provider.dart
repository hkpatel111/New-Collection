import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';
import '../models/models.dart';
import '../services/auth_service.dart';
export '../services/auth_service.dart' show VoidSuccess, VoidError;
import '../services/firestore_service.dart';
import '../services/notification_service.dart';

/// Holds the signed-in user, their businesses and the active business.
/// Also wires the FirestoreService per-business context.
class AuthProvider extends ChangeNotifier {
  final AuthService _auth = AuthService.instance;
  final FirestoreService _db = FirestoreService.instance;

  StreamSubscription<User?>? _sub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _bizSub;

  User? user;
  bool get isLoggedIn => user != null;
  bool get isConfigured => _auth.isConfigured;

  List<Business> businesses = [];
  Business? activeBusiness;

  String? _activeBusinessIdPref;

  void init() {
    _sub ??= _auth.authStateChanges.listen(_onAuthChanged);
  }

  Future<void> _onAuthChanged(User? u) async {
    user = u;
    _bizSub?.cancel();
    businesses = [];
    activeBusiness = null;
    if (u == null) {
      _db.clearContext();
      notifyListeners();
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    _activeBusinessIdPref = prefs.getString(AppConstants.prefActiveBusiness);

    _bizSub = _db.businessesStream(u.uid).listen((snap) {
      businesses = snap.docs
          .map((d) => Business.fromMap(d.id, d.data()))
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      _pickActive();
      notifyListeners();
    });

    await NotificationService.instance.registerPush(uid: u.uid);
    notifyListeners();
  }

  void _pickActive() {
    if (businesses.isEmpty) {
      activeBusiness = null;
      _db.clearContext();
      return;
    }
    Business selected;
    try {
      selected = businesses.firstWhere((b) => b.id == _activeBusinessIdPref);
    } catch (_) {
      selected = businesses.first;
    }
    activeBusiness = selected;
    _db.setContext(
      user?.uid ?? '',
      selected.id,
      user?.displayName ?? user?.phoneNumber ?? 'Owner',
    );
  }

  Future<void> switchBusiness(String businessId) async {
    _activeBusinessIdPref = businessId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefActiveBusiness, businessId);
    _pickActive();
    notifyListeners();
  }

  Future<Business> createBusiness({
    required String name,
    String address = '',
    String phone = '',
    String logoUrl = '',
  }) async {
    final b = Business(
      id: '',
      ownerId: user!.uid,
      name: name,
      address: address,
      phone: phone,
      logoUrl: logoUrl,
    );
    final ref = await _db.addBusiness(b);
    final created = Business(
      id: ref.id,
      ownerId: b.ownerId,
      name: name,
      address: address,
      phone: phone,
      logoUrl: logoUrl,
    );
    await switchBusiness(ref.id);
    return created;
  }

  // ---- Pass-through auth actions ----

  Future<void> sendOtp({
    required String phone,
    required VoidSuccess onSent,
    required VoidError onError,
  }) =>
      _auth.sendOtp(phone: phone, onCodeSent: onSent, onError: onError);

  Future<void> verifyOtp(String otp) => _auth.verifyOtp(otp);

  Future<void> signInWithGoogle() => _auth.signInWithGoogle();

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Future<void> deleteAccount(VoidError onError) async {
    final phone = user?.phoneNumber ?? '';
    await _auth.deleteAccount(phone, onError);
  }

  @override
  void dispose() {
    _sub?.cancel();
    _bizSub?.cancel();
    super.dispose();
  }
}
