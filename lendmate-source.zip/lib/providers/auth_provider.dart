import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';
import '../models/models.dart';
import '../services/repository.dart';

/// Holds the active business and wires the Repository's per-business context.
///
/// The app runs fully offline: there is no login step. A default business is
/// seeded on first run and the active business is remembered in prefs.
class AuthProvider extends ChangeNotifier {
  final Repository _db = Repository.instance;

  StreamSubscription? _bizSub;

  List<Business> businesses = [];
  Business? activeBusiness;

  /// True once the first businesses snapshot has arrived.
  bool ready = false;

  bool _seeding = false;
  String? _activeBusinessIdPref;

  static const String localUid = 'local';
  static const String localUserName = 'Owner';

  Future<void> init() async {
    _db.clearContext();
    final prefs = await SharedPreferences.getInstance();
    _activeBusinessIdPref = prefs.getString(AppConstants.prefActiveBusiness);
    _bizSub = _db.businessesStream(localUid).listen((list) {
      businesses = list;
      if (list.isEmpty) {
        _seed();
      } else {
        _pickActive();
      }
      ready = true;
      notifyListeners();
    });
  }

  Future<void> _seed() async {
    if (_seeding) return;
    _seeding = true;
    try {
      await createBusiness(name: 'My Business');
    } catch (_) {
      // Seed failure leaves the empty state; user can add a business from
      // the home menu, and the next snapshot retries automatically.
    } finally {
      _seeding = false;
    }
  }

  void _pickActive() {
    if (businesses.isEmpty) {
      activeBusiness = null;
      _db.clearContext();
      return;
    }
    Business selected;
    try {
      selected = businesses.firstWhere((b) => b.id == _activeBusinessIdPref);
    } catch (_) {
      selected = businesses.first;
    }
    activeBusiness = selected;
    _db.setContext(localUid, selected.id, localUserName);
  }

  Future<void> switchBusiness(String businessId) async {
    _activeBusinessIdPref = businessId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefActiveBusiness, businessId);
    _pickActive();
    notifyListeners();
  }

  Future<Business> createBusiness({
    required String name,
    String address = '',
    String phone = '',
    String logoUrl = '',
  }) async {
    final id = await _db.addBusiness(
      Business(
        id: '',
        ownerId: localUid,
        name: name,
        address: address,
        phone: phone,
        logoUrl: logoUrl,
      ),
    );
    final created = Business(
      id: id,
      ownerId: localUid,
      name: name,
      address: address,
      phone: phone,
      logoUrl: logoUrl,
    );
    await switchBusiness(id);
    return created;
  }

  @override
  void dispose() {
    _bizSub?.cancel();
    super.dispose();
  }
}
