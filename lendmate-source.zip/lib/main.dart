import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/app_localizations.dart';
import 'core/theme.dart';
import 'firebase_options.dart';
import 'providers/app_settings_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/data_provider.dart';
import 'screens/home_shell.dart';
import 'screens/lock_screen.dart';
import 'screens/login_screen.dart';
import 'screens/setup_screen.dart';
import 'services/app_lock_service.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();

  // Firebase may be unconfigured (placeholder options) — the app still runs
  // and shows the setup screen.
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (_) {
    // If even the default app failed to register, register a dummy so
    // FirebaseAuth.instance doesn't throw before RootGate shows SetupScreen.
    try {
      await Firebase.initializeApp(name: 'lendmate-fallback');
    } catch (_) {}
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppSettingsProvider()..load()),
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProvider(create: (_) => DataProvider()),
      ],
      child: const LendMateApp(),
    ),
  );
}

class LendMateApp extends StatelessWidget {
  const LendMateApp();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettingsProvider>();

    return MaterialApp(
      title: 'LendMate',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: settings.themeMode,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [AppLocalizations.delegate],
      locale: Locale(settings.language.code),
      home: const RootGate(),
    );
  }
}

/// Decides: setup screen (Firebase missing) -> lock -> login -> home.
class RootGate extends StatefulWidget {
  const RootGate();

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _unlocked = false;
  String? _lastSyncedBid;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    if (!auth.isConfigured) return const SetupScreen();

    if (!auth.isLoggedIn) {
      _unlocked = false;
      _lastSyncedBid = null;
      return const LoginScreen();
    }

    // Re-subscribe DataProvider when the active business changes.
    final data = context.watch<DataProvider>();
    final bid = auth.activeBusiness?.id;
    if (bid != _lastSyncedBid) {
      _lastSyncedBid = bid;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) data.resubscribe();
      });
    }

    if (!_unlocked) {
      return LockGate(onUnlocked: () {
        if (mounted) setState(() => _unlocked = true);
      });
    }
    return const HomeShell();
  }
}

class LockGate extends StatelessWidget {
  const LockGate({required this.onUnlocked});

  final VoidCallback onUnlocked;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: AppLockService.instance.isEnabled(),
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const SizedBox.shrink();
        }
        if (snap.data == true) {
          return LockScreen(onUnlocked: onUnlocked);
        }
        // No lock enabled — unlock immediately.
        WidgetsBinding.instance.addPostFrameCallback((_) => onUnlocked());
        return const SizedBox.shrink();
      },
    );
  }
}
