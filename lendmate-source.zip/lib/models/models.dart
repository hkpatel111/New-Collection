import '../core/enums.dart';

// ===========================================================================
// All Firestore-backed models. Every model has toMap()/fromMap() and keeps
// extra unknown keys via `extra` so server-side additions never break old
// app versions.
// ===========================================================================

/// Base helpers shared by all models.
Map<String, dynamic> _clean(Map<String, dynamic> m) {
  m.removeWhere((k, v) => v == null);
  return m;
}

DateTime _dt(dynamic v) {
  if (v is DateTime) return v;
  if (v is int) return DateTime.fromMillisecondsSinceEpoch(v);
  return DateTime.now();
}

// ---------------------------------------------------------------------------

class AppUser {
  AppUser({
    required this.uid,
    this.phone = '',
    this.email = '',
    this.name = '',
    this.photoUrl = '',
    this.businessIds = const [],
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String uid;
  String phone;
  String email;
  String name;
  String photoUrl;
  List<String> businessIds;
  DateTime createdAt;

  factory AppUser.fromMap(String uid, Map<String, dynamic> m) => AppUser(
        uid: uid,
        phone: m['phone'] as String? ?? '',
        email: m['email'] as String? ?? '',
        name: m['name'] as String? ?? '',
        photoUrl: m['photoUrl'] as String? ?? '',
        businessIds:
            (m['businessIds'] as List<dynamic>?)?.cast<String>() ?? const [],
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'phone': phone,
        'email': email,
        'name': name,
        'photoUrl': photoUrl,
        'businessIds': businessIds,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class Business {
  Business({
    required this.id,
    required this.ownerId,
    required this.name,
    this.logoUrl = '',
    this.address = '',
    this.phone = '',
    this.staffIds = const [],
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  final String ownerId;
  String name;
  String logoUrl;
  String address;
  String phone;
  List<String> staffIds;
  DateTime createdAt;

  factory Business.fromMap(String id, Map<String, dynamic> m) => Business(
        id: id,
        ownerId: m['ownerId'] as String? ?? '',
        name: m['name'] as String? ?? 'My Business',
        logoUrl: m['logoUrl'] as String? ?? '',
        address: m['address'] as String? ?? '',
        phone: m['phone'] as String? ?? '',
        staffIds: (m['staffIds'] as List<dynamic>?)?.cast<String>() ?? const [],
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'ownerId': ownerId,
        'name': name,
        'logoUrl': logoUrl,
        'address': address,
        'phone': phone,
        'staffIds': staffIds,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class Borrower {
  Borrower({
    required this.id,
    required this.businessId,
    required this.name,
    this.phone = '',
    this.address = '',
    this.notes = '',
    this.photoUrls = const [],
    this.pinned = false,
    this.reminderUpdates = true,
    this.reminderDues = true,
    this.customFields = const {},
    this.createdBy = '',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  final String businessId;
  String name;
  String phone;
  String address;
  String notes;
  List<String> photoUrls;
  bool pinned;
  bool reminderUpdates;
  bool reminderDues;
  Map<String, String> customFields;
  String createdBy;
  DateTime createdAt;

  factory Borrower.fromMap(String id, Map<String, dynamic> m) => Borrower(
        id: id,
        businessId: m['businessId'] as String? ?? '',
        name: m['name'] as String? ?? '',
        phone: m['phone'] as String? ?? '',
        address: m['address'] as String? ?? '',
        notes: m['notes'] as String? ?? '',
        photoUrls: (m['photoUrls'] as List<dynamic>?)?.cast<String>() ?? const [],
        pinned: m['pinned'] as bool? ?? false,
        reminderUpdates: m['reminderUpdates'] as bool? ?? true,
        reminderDues: m['reminderDues'] as bool? ?? true,
        customFields:
            (m['customFields'] as Map<String, dynamic>?)?.cast<String, String>() ??
                const {},
        createdBy: m['createdBy'] as String? ?? '',
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'businessId': businessId,
        'name': name,
        'phone': phone,
        'address': address,
        'notes': notes,
        'photoUrls': photoUrls,
        'pinned': pinned,
        'reminderUpdates': reminderUpdates,
        'reminderDues': reminderDues,
        'customFields': customFields,
        'createdBy': createdBy,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class Customer {
  Customer({
    required this.id,
    required this.businessId,
    required this.name,
    this.phone = '',
    this.notes = '',
    this.customFields = const {},
    this.createdBy = '',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  final String businessId;
  String name;
  String phone;
  String notes;
  Map<String, String> customFields;
  String createdBy;
  DateTime createdAt;

  factory Customer.fromMap(String id, Map<String, dynamic> m) => Customer(
        id: id,
        businessId: m['businessId'] as String? ?? '',
        name: m['name'] as String? ?? '',
        phone: m['phone'] as String? ?? '',
        notes: m['notes'] as String? ?? '',
        customFields:
            (m['customFields'] as Map<String, dynamic>?)?.cast<String, String>() ??
                const {},
        createdBy: m['createdBy'] as String? ?? '',
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'businessId': businessId,
        'name': name,
        'phone': phone,
        'notes': notes,
        'customFields': customFields,
        'createdBy': createdBy,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

/// One give/take row in a customer's khata ledger.
class KhataEntry {
  KhataEntry({
    required this.id,
    required this.customerId,
    required this.direction,
    required this.amount,
    required this.date,
    this.note = '',
    this.addedBy = '',
    this.source = '',
  });

  final String id;
  final String customerId;
  LedgerDirection direction;
  double amount;
  DateTime date;
  String note;
  String addedBy;
  String source;

  factory KhataEntry.fromMap(String id, Map<String, dynamic> m) => KhataEntry(
        id: id,
        customerId: m['customerId'] as String? ?? '',
        direction: LedgerDirectionX.fromString(m['direction'] as String?),
        amount: (m['amount'] as num?)?.toDouble() ?? 0,
        date: _dt(m['date']),
        note: m['note'] as String? ?? '',
        addedBy: m['addedBy'] as String? ?? '',
        source: m['source'] as String? ?? '',
      );

  Map<String, dynamic> toMap() => _clean({
        'customerId': customerId,
        'direction': direction.name,
        'amount': amount,
        'date': date,
        'note': note,
        'addedBy': addedBy,
        'source': source,
      });
}

// ---------------------------------------------------------------------------

class Loan {
  Loan({
    required this.id,
    required this.businessId,
    required this.borrowerId,
    required this.borrowerName,
    this.category = LoanCategory.interest,
    this.interestType = InterestType.flat,
    this.cycle = PaymentCycle.monthly,
    this.everyNMonths = 1,
    this.principal = 0,
    this.rate = 0,
    this.emiCount = 0,
    this.emiAmount = 0,
    this.totalPayable = 0,
    this.totalPaid = 0,
    this.processingFee = 0,
    this.lateFeePerCycle = 0,
    required this.startDate,
    this.status = LoanStatus.active,
    this.billNumber = '',
    this.disbursementMode = '',
    this.notes = '',
    this.voiceNoteUrl = '',
    this.guarantorName = '',
    this.guarantorPhone = '',
    this.collateralNote = '',
    this.collateralValue = 0,
    this.collateralCurrentValue = 0,
    this.collateralReturnBy,
    this.collateralPhotoUrls = const [],
    this.groupMemberPhones = const [],
    this.createdBy = '',
    this.staffId = '',
    this.muted = false,
    this.upfrontInterest = false,
    this.openEnded = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  final String businessId;
  final String borrowerId;
  final String borrowerName;
  LoanCategory category;
  InterestType interestType;
  PaymentCycle cycle;
  int everyNMonths;
  double principal;
  double rate;
  int emiCount;
  double emiAmount;
  double totalPayable;
  double totalPaid;
  double processingFee;
  double lateFeePerCycle;
  DateTime startDate;
  LoanStatus status;
  String billNumber;
  String disbursementMode;
  String notes;
  String voiceNoteUrl;
  String guarantorName;
  String guarantorPhone;
  String collateralNote;
  double collateralValue;
  double collateralCurrentValue;
  DateTime? collateralReturnBy;
  List<String> collateralPhotoUrls;
  List<String> groupMemberPhones;
  String createdBy;
  String staffId;
  bool muted;
  bool upfrontInterest;
  bool openEnded;
  DateTime createdAt;

  double get balanceDue {
    final v = totalPayable - totalPaid;
    return v < 0 ? 0 : v;
  }

  bool get isActive => status == LoanStatus.active;

  factory Loan.fromMap(String id, Map<String, dynamic> m) => Loan(
        id: id,
        businessId: m['businessId'] as String? ?? '',
        borrowerId: m['borrowerId'] as String? ?? '',
        borrowerName: m['borrowerName'] as String? ?? '',
        category: LoanCategoryX.fromString(m['category'] as String?),
        interestType: InterestTypeX.fromString(m['interestType'] as String?),
        cycle: PaymentCycleX.fromString(m['cycle'] as String?),
        everyNMonths: (m['everyNMonths'] as num?)?.toInt() ?? 1,
        principal: (m['principal'] as num?)?.toDouble() ?? 0,
        rate: (m['rate'] as num?)?.toDouble() ?? 0,
        emiCount: (m['emiCount'] as num?)?.toInt() ?? 0,
        emiAmount: (m['emiAmount'] as num?)?.toDouble() ?? 0,
        totalPayable: (m['totalPayable'] as num?)?.toDouble() ?? 0,
        totalPaid: (m['totalPaid'] as num?)?.toDouble() ?? 0,
        processingFee: (m['processingFee'] as num?)?.toDouble() ?? 0,
        lateFeePerCycle: (m['lateFeePerCycle'] as num?)?.toDouble() ?? 0,
        startDate: _dt(m['startDate']),
        status: LoanStatusX.fromString(m['status'] as String?),
        billNumber: m['billNumber'] as String? ?? '',
        disbursementMode: m['disbursementMode'] as String? ?? '',
        notes: m['notes'] as String? ?? '',
        voiceNoteUrl: m['voiceNoteUrl'] as String? ?? '',
        guarantorName: m['guarantorName'] as String? ?? '',
        guarantorPhone: m['guarantorPhone'] as String? ?? '',
        collateralNote: m['collateralNote'] as String? ?? '',
        collateralValue: (m['collateralValue'] as num?)?.toDouble() ?? 0,
        collateralCurrentValue:
            (m['collateralCurrentValue'] as num?)?.toDouble() ?? 0,
        collateralReturnBy: m['collateralReturnBy'] == null
            ? null
            : _dt(m['collateralReturnBy']),
        collateralPhotoUrls:
            (m['collateralPhotoUrls'] as List<dynamic>?)?.cast<String>() ??
                const [],
        groupMemberPhones:
            (m['groupMemberPhones'] as List<dynamic>?)?.cast<String>() ?? const [],
        createdBy: m['createdBy'] as String? ?? '',
        staffId: m['staffId'] as String? ?? '',
        muted: m['muted'] as bool? ?? false,
        upfrontInterest: m['upfrontInterest'] as bool? ?? false,
        openEnded: m['openEnded'] as bool? ?? false,
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'businessId': businessId,
        'borrowerId': borrowerId,
        'borrowerName': borrowerName,
        'category': category.name,
        'interestType': interestType.name,
        'cycle': cycle.name,
        'everyNMonths': everyNMonths,
        'principal': principal,
        'rate': rate,
        'emiCount': emiCount,
        'emiAmount': emiAmount,
        'totalPayable': totalPayable,
        'totalPaid': totalPaid,
        'processingFee': processingFee,
        'lateFeePerCycle': lateFeePerCycle,
        'startDate': startDate,
        'status': status.name,
        'billNumber': billNumber,
        'disbursementMode': disbursementMode,
        'notes': notes,
        'voiceNoteUrl': voiceNoteUrl,
        'guarantorName': guarantorName,
        'guarantorPhone': guarantorPhone,
        'collateralNote': collateralNote,
        'collateralValue': collateralValue,
        'collateralCurrentValue': collateralCurrentValue,
        'collateralReturnBy': collateralReturnBy,
        'collateralPhotoUrls': collateralPhotoUrls,
        'groupMemberPhones': groupMemberPhones,
        'createdBy': createdBy,
        'staffId': staffId,
        'muted': muted,
        'upfrontInterest': upfrontInterest,
        'openEnded': openEnded,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

/// A single computed row of the EMI schedule.
class EmiRow {
  EmiRow({
    required this.no,
    required this.dueDate,
    required this.due,
    this.paid = 0,
    this.isInterestOnly = false,
  });

  final int no;
  final DateTime dueDate;
  final double due;
  double paid;
  final bool isInterestOnly;

  double get remaining {
    final v = due - paid;
    return v < 0 ? 0 : v;
  }
  bool get isPaid => remaining <= 0.5;
  bool get isOverdue =>
      !isPaid && dueDate.isBefore(DateTime.now());
}

// ---------------------------------------------------------------------------

class Payment {
  Payment({
    required this.id,
    required this.businessId,
    required this.loanId,
    required this.borrowerId,
    required this.amount,
    required this.date,
    this.method = '',
    this.note = '',
    this.lateFee = 0,
    this.addedBy = '',
    this.addedByName = '',
    this.voiceNoteUrl = '',
  });

  final String id;
  final String businessId;
  final String loanId;
  final String borrowerId;
  double amount;
  double lateFee;
  DateTime date;
  String method;
  String note;
  String addedBy;
  String addedByName;
  String voiceNoteUrl;

  factory Payment.fromMap(String id, Map<String, dynamic> m) => Payment(
        id: id,
        businessId: m['businessId'] as String? ?? '',
        loanId: m['loanId'] as String? ?? '',
        borrowerId: m['borrowerId'] as String? ?? '',
        amount: (m['amount'] as num?)?.toDouble() ?? 0,
        lateFee: (m['lateFee'] as num?)?.toDouble() ?? 0,
        date: _dt(m['date']),
        method: m['method'] as String? ?? '',
        note: m['note'] as String? ?? '',
        addedBy: m['addedBy'] as String? ?? '',
        addedByName: m['addedByName'] as String? ?? '',
        voiceNoteUrl: m['voiceNoteUrl'] as String? ?? '',
      );

  Map<String, dynamic> toMap() => _clean({
        'businessId': businessId,
        'loanId': loanId,
        'borrowerId': borrowerId,
        'amount': amount,
        'lateFee': lateFee,
        'date': date,
        'method': method,
        'note': note,
        'addedBy': addedBy,
        'addedByName': addedByName,
        'voiceNoteUrl': voiceNoteUrl,
      });
}

// ---------------------------------------------------------------------------

class LockerDoc {
  LockerDoc({
    required this.id,
    required this.businessId,
    required this.ownerType,
    required this.ownerId,
    required this.title,
    required this.url,
    required this.uploadedAt,
    this.tag = '',
  });

  final String id;
  final String businessId;
  final String ownerType; // 'borrower' | 'loan' | 'customer'
  final String ownerId;
  final String title;
  final String url;
  final String tag;
  final DateTime uploadedAt;

  factory LockerDoc.fromMap(String id, Map<String, dynamic> m) => LockerDoc(
        id: id,
        businessId: m['businessId'] as String? ?? '',
        ownerType: m['ownerType'] as String? ?? '',
        ownerId: m['ownerId'] as String? ?? '',
        title: m['title'] as String? ?? 'Document',
        url: m['url'] as String? ?? '',
        tag: m['tag'] as String? ?? '',
        uploadedAt: _dt(m['uploadedAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'businessId': businessId,
        'ownerType': ownerType,
        'ownerId': ownerId,
        'title': title,
        'url': url,
        'tag': tag,
        'uploadedAt': uploadedAt,
      });
}

// ---------------------------------------------------------------------------

class ReminderLog {
  ReminderLog({
    required this.id,
    required this.loanId,
    required this.borrowerId,
    required this.channel,
    required this.sentAt,
    this.type = 'due',
  });

  final String id;
  final String loanId;
  final String borrowerId;
  final String channel; // whatsapp | sms
  final DateTime sentAt;
  final String type; // due | recordUpdate

  factory ReminderLog.fromMap(String id, Map<String, dynamic> m) => ReminderLog(
        id: id,
        loanId: m['loanId'] as String? ?? '',
        borrowerId: m['borrowerId'] as String? ?? '',
        channel: m['channel'] as String? ?? 'whatsapp',
        sentAt: _dt(m['sentAt']),
        type: m['type'] as String? ?? 'due',
      );

  Map<String, dynamic> toMap() => _clean({
        'loanId': loanId,
        'borrowerId': borrowerId,
        'channel': channel,
        'sentAt': sentAt,
        'type': type,
      });
}

// ---------------------------------------------------------------------------

class Task {
  Task({
    required this.id,
    required this.title,
    required this.dueAt,
    this.done = false,
    this.note = '',
    this.reminder = true,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  String title;
  String note;
  DateTime dueAt;
  bool done;
  bool reminder;
  DateTime createdAt;

  factory Task.fromMap(String id, Map<String, dynamic> m) => Task(
        id: id,
        title: m['title'] as String? ?? '',
        note: m['note'] as String? ?? '',
        dueAt: _dt(m['dueAt']),
        done: m['done'] as bool? ?? false,
        reminder: m['reminder'] as bool? ?? true,
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'title': title,
        'note': note,
        'dueAt': dueAt,
        'done': done,
        'reminder': reminder,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class Expense {
  Expense({
    required this.id,
    required this.category,
    required this.amount,
    required this.date,
    this.note = '',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  String category;
  double amount;
  DateTime date;
  String note;
  DateTime createdAt;

  factory Expense.fromMap(String id, Map<String, dynamic> m) => Expense(
        id: id,
        category: m['category'] as String? ?? 'General',
        amount: (m['amount'] as num?)?.toDouble() ?? 0,
        date: _dt(m['date']),
        note: m['note'] as String? ?? '',
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'category': category,
        'amount': amount,
        'date': date,
        'note': note,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class AuditEntry {
  AuditEntry({
    required this.id,
    required this.action,
    required this.entity,
    required this.entityId,
    required this.byUid,
    required this.byName,
    required this.at,
    this.detail = '',
  });

  final String id;
  final String action; // create | update | delete | payment | login...
  final String entity; // loan | borrower | customer | payment ...
  final String entityId;
  final String byUid;
  final String byName;
  final DateTime at;
  final String detail;

  factory AuditEntry.fromMap(String id, Map<String, dynamic> m) => AuditEntry(
        id: id,
        action: m['action'] as String? ?? '',
        entity: m['entity'] as String? ?? '',
        entityId: m['entityId'] as String? ?? '',
        byUid: m['byUid'] as String? ?? '',
        byName: m['byName'] as String? ?? '',
        at: _dt(m['at']),
        detail: m['detail'] as String? ?? '',
      );

  Map<String, dynamic> toMap() => _clean({
        'action': action,
        'entity': entity,
        'entityId': entityId,
        'byUid': byUid,
        'byName': byName,
        'at': at,
        'detail': detail,
      });
}

// ---------------------------------------------------------------------------

class LoanTemplate {
  LoanTemplate({
    required this.id,
    required this.name,
    this.interestType = InterestType.flat,
    this.cycle = PaymentCycle.monthly,
    this.everyNMonths = 1,
    this.rate = 0,
    this.emiCount = 0,
    this.processingFee = 0,
    this.lateFeePerCycle = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  final String name;
  InterestType interestType;
  PaymentCycle cycle;
  int everyNMonths;
  double rate;
  int emiCount;
  double processingFee;
  double lateFeePerCycle;
  DateTime createdAt;

  factory LoanTemplate.fromMap(String id, Map<String, dynamic> m) =>
      LoanTemplate(
        id: id,
        name: m['name'] as String? ?? 'Template',
        interestType: InterestTypeX.fromString(m['interestType'] as String?),
        cycle: PaymentCycleX.fromString(m['cycle'] as String?),
        everyNMonths: (m['everyNMonths'] as num?)?.toInt() ?? 1,
        rate: (m['rate'] as num?)?.toDouble() ?? 0,
        emiCount: (m['emiCount'] as num?)?.toInt() ?? 0,
        processingFee: (m['processingFee'] as num?)?.toDouble() ?? 0,
        lateFeePerCycle: (m['lateFeePerCycle'] as num?)?.toDouble() ?? 0,
        createdAt: _dt(m['createdAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'name': name,
        'interestType': interestType.name,
        'cycle': cycle.name,
        'everyNMonths': everyNMonths,
        'rate': rate,
        'emiCount': emiCount,
        'processingFee': processingFee,
        'lateFeePerCycle': lateFeePerCycle,
        'createdAt': createdAt,
      });
}

// ---------------------------------------------------------------------------

class StaffMember {
  StaffMember({
    required this.id,
    required this.name,
    required this.phone,
    this.role = StaffRole.staff,
    DateTime? addedAt,
  }) : addedAt = addedAt ?? DateTime.now();

  final String id;
  String name;
  String phone;
  StaffRole role;
  DateTime addedAt;

  factory StaffMember.fromMap(String id, Map<String, dynamic> m) =>
      StaffMember(
        id: id,
        name: m['name'] as String? ?? '',
        phone: m['phone'] as String? ?? '',
        role: StaffRoleX.fromString(m['role'] as String?),
        addedAt: _dt(m['addedAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'name': name,
        'phone': phone,
        'role': role.name,
        'addedAt': addedAt,
      });
}

// ---------------------------------------------------------------------------

/// Peer-to-peer ledger sync invite between two phone numbers.
class SyncRequest {
  SyncRequest({
    required this.id,
    required this.fromPhoneKey,
    required this.toPhoneKey,
    required this.entityType,
    required this.entityId,
    required this.fullHistory,
    required this.status,
    required this.requestedAt,
    this.fromName = '',
  });

  final String id;
  final String fromPhoneKey;
  final String toPhoneKey;
  final String entityType; // loan | khata
  final String entityId;
  final bool fullHistory;
  final String status; // pending | accepted | rejected
  final String fromName;
  final DateTime requestedAt;

  factory SyncRequest.fromMap(String id, Map<String, dynamic> m) =>
      SyncRequest(
        id: id,
        fromPhoneKey: m['fromPhoneKey'] as String? ?? '',
        toPhoneKey: m['toPhoneKey'] as String? ?? '',
        entityType: m['entityType'] as String? ?? '',
        entityId: m['entityId'] as String? ?? '',
        fullHistory: m['fullHistory'] as bool? ?? false,
        status: m['status'] as String? ?? 'pending',
        fromName: m['fromName'] as String? ?? '',
        requestedAt: _dt(m['requestedAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'fromPhoneKey': fromPhoneKey,
        'toPhoneKey': toPhoneKey,
        'entityType': entityType,
        'entityId': entityId,
        'fullHistory': fullHistory,
        'status': status,
        'fromName': fromName,
        'requestedAt': requestedAt,
      });
}

// ---------------------------------------------------------------------------

class CalcHistoryItem {
  CalcHistoryItem({
    required this.id,
    required this.summary,
    required this.savedAt,
  });

  final String id;
  final String summary;
  final DateTime savedAt;

  factory CalcHistoryItem.fromMap(String id, Map<String, dynamic> m) =>
      CalcHistoryItem(
        id: id,
        summary: m['summary'] as String? ?? '',
        savedAt: _dt(m['savedAt']),
      );

  Map<String, dynamic> toMap() => _clean({
        'summary': summary,
        'savedAt': savedAt,
      });
}

// ---------------------------------------------------------------------------

/// User-defined extra field for borrowers/customers.
class CustomFieldDef {
  CustomFieldDef({
    required this.id,
    required this.name,
    this.forType = 'borrower',
  });

  final String id;
  final String name;
  final String forType; // borrower | customer

  factory CustomFieldDef.fromMap(String id, Map<String, dynamic> m) =>
      CustomFieldDef(
        id: id,
        name: m['name'] as String? ?? '',
        forType: m['forType'] as String? ?? 'borrower',
      );

  Map<String, dynamic> toMap() => _clean({
        'name': name,
        'forType': forType,
      });
}

// ---------------------------------------------------------------------------

/// One parsed draft produced by the OCR scan flow.
class ScanDraft {
  ScanDraft({
    required this.id,
    required this.kind,
    required this.name,
    required this.amount,
    required this.date,
    this.confirmed = false,
  });

  final String id;
  final String kind; // loan | khata
  final String name;
  final double amount;
  final DateTime date;
  bool confirmed;

  Map<String, dynamic> toMap() => {
        'kind': kind,
        'name': name,
        'amount': amount,
        'date': date.toIso8601String(),
        'confirmed': confirmed,
      };

  factory ScanDraft.fromMap(Map<String, dynamic> m) => ScanDraft(
        id: '${m['name']}-${m['amount']}',
        kind: m['kind'] as String? ?? 'khata',
        name: m['name'] as String? ?? '',
        amount: (m['amount'] as num?)?.toDouble() ?? 0,
        date: DateTime.tryParse(m['date'] as String? ?? '') ?? DateTime.now(),
      );
}
