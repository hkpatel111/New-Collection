import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'enums.dart';

/// Formatting + parsing helpers used across the app.
class Utils {
  Utils._();

  // ---------- Money ----------
  static String money(num v, {String symbol = '₹'}) {
    final f = NumberFormat.currency(locale: 'en_IN', symbol: symbol, decimalDigits: 0);
    return f.format(v);
  }

  static String compact(num v) {
    if (v.abs() >= 10000000) return '${(v / 10000000).toStringAsFixed(2)} Cr';
    if (v.abs() >= 100000) return '${(v / 100000).toStringAsFixed(2)} L';
    if (v.abs() >= 1000) return '${(v / 1000).toStringAsFixed(1)} K';
    return v.toStringAsFixed(v == v.roundToDouble() ? 0 : 2);
  }

  /// Parses user input like "1,20,000" or "5000.50" into a double.
  static double parseAmount(String raw) {
    final cleaned = raw.replaceAll(RegExp(r'[^\d.\-]'), '');
    return double.tryParse(cleaned) ?? 0;
  }

  // ---------- Dates ----------
  static String date(DateTime d) => DateFormat('dd MMM yyyy').format(d);

  static String dateShort(DateTime d) => DateFormat('dd MMM').format(d);

  static String dateTime(DateTime d) => DateFormat('dd MMM yyyy, hh:mm a').format(d);

  static String monthName(DateTime d) => DateFormat('MMMM yyyy').format(d);

  /// Normalizes any date to local midnight for day comparisons.
  static DateTime dayStart(DateTime d) => DateTime(d.year, d.month, d.day);

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  /// Adds one cycle period to [d]. [everyNMonths] applies to custom cycles.
  static DateTime addCycle(DateTime d, PaymentCycle cycle, int everyNMonths) {
    switch (cycle) {
      case PaymentCycle.daily:
        return d.add(const Duration(days: 1));
      case PaymentCycle.weekly:
        return d.add(const Duration(days: 7));
      case PaymentCycle.monthly:
      case PaymentCycle.custom:
        return DateTime(d.year, d.month + everyNMonths, d.day);
    }
  }

  // ---------- Phones ----------
  /// Strips formatting and adds default country code if missing.
  static String normalizePhone(String raw, {String defaultCountry = '+91'}) {
    var digits = raw.replaceAll(RegExp(r'[^0-9+]'), '');
    if (digits.isEmpty) return '';
    if (digits.startsWith('0')) digits = digits.substring(1);
    if (!digits.startsWith('+')) digits = '$defaultCountry$digits';
    return digits;
  }

  /// Last 10 digits as a stable cross-app identity key for ledger sync.
  static String phoneKey(String normalized) {
    final digits = normalized.replaceAll(RegExp(r'[^0-9]'), '');
    return digits.length >= 10 ? digits.substring(digits.length - 10) : digits;
  }

  // ---------- Search ----------
  static bool matchesQuery(Map<String, dynamic> data, String query) {
    if (query.isEmpty) return true;
    final q = query.toLowerCase();
    return data.values.any((v) => v.toString().toLowerCase().contains(q));
  }

  // ---------- Misc ----------
  static Future<bool?> confirmDialog(BuildContext context, String message) {
    return showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dCtx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dCtx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  static void showError(BuildContext context, Object error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Error: $error'),
        backgroundColor: const Color(0xFFC62828),
      ),
    );
  }

  static void toast(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}
