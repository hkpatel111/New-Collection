import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'enums.dart';

/// Lightweight app localization (no codegen needed).
///
/// To add a string: add the key under `en`, then translate under `hi`/`gu`.
/// Hindi/Gujarati fall back to English for any missing key.
class AppLocalizations {
  AppLocalizations(this.locale);

  final Locale locale;

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static const supportedLocales = [Locale('en'), Locale('hi'), Locale('gu')];

  static AppLocalizations of(BuildContext context) =>
      Localizations.of<AppLocalizations>(context, AppLocalizations) ??
      AppLocalizations(const Locale('en'));

  AppLanguage get language => AppLanguageX.fromCode(locale.languageCode);

  // --------------------------------------------------------------------

  static const Map<String, Map<String, String>> _values = {
    // ---- Common ----
    'appName': {
      'en': 'LendMate',
      'hi': 'लेंडमेट',
      'gu': 'લેન્ડમેટ',
    },
    'save': {'en': 'Save', 'hi': 'सेव करें', 'gu': 'સેવ કરો'},
    'cancel': {'en': 'Cancel', 'hi': 'रद्द करें', 'gu': 'રદ કરો'},
    'delete': {'en': 'Delete', 'hi': 'हटाएं', 'gu': 'ડિલીટ કરો'},
    'edit': {'en': 'Edit', 'hi': 'संपादित करें', 'gu': 'એડિટ કરો'},
    'add': {'en': 'Add', 'hi': 'जोड़ें', 'gu': 'ઉમેરો'},
    'search': {'en': 'Search', 'hi': 'खोजें', 'gu': 'શોધો'},
    'share': {'en': 'Share', 'hi': 'शेयर करें', 'gu': 'શેર કરો'},
    'export': {'en': 'Export', 'hi': 'एक्सपोर्ट', 'gu': 'એક્સપોર્ટ'},
    'settings': {'en': 'Settings', 'hi': 'सेटिंग्स', 'gu': 'સેટિંગ્સ'},
    'total': {'en': 'Total', 'hi': 'कुल', 'gu': 'કુલ'},
    'date': {'en': 'Date', 'hi': 'तारीख', 'gu': 'તારીખ'},
    'amount': {'en': 'Amount', 'hi': 'रकम', 'gu': 'રકમ'},
    'notes': {'en': 'Notes', 'hi': 'नोट्स', 'gu': 'નોંધ'},
    'optional': {'en': 'optional', 'hi': 'वैकल्पिक', 'gu': 'વૈકલ્પિક'},
    'required': {'en': 'Required', 'hi': 'आवश्यक', 'gu': 'જરૂરી'},
    'emptyList': {
      'en': 'Nothing here yet',
      'hi': 'अभी कुछ नहीं है',
      'gu': 'અત્યારે કંઈ નથી',
    },
    'today': {'en': 'Today', 'hi': 'आज', 'gu': 'આજે'},
    'thisWeek': {'en': 'This Week', 'hi': 'इस हफ्ते', 'gu': 'આ સપ્તાહે'},
    'thisMonth': {'en': 'This Month', 'hi': 'इस महीने', 'gu': 'આ મહિને'},
    'confirmDelete': {
      'en': 'Delete this? This cannot be undone.',
      'hi': 'हटाना है? इसे वापस नहीं किया जा सकता।',
      'gu': 'ડિલીટ કરવું છે? આ પાછું નથી આવશે.',
    },

    // ---- Auth ----
    'login': {'en': 'Login', 'hi': 'लॉगिन', 'gu': 'લોગિન'},
    'logout': {'en': 'Sign Out', 'hi': 'साइन आउट', 'gu': 'સાઇન આઉટ'},
    'phoneLogin': {
      'en': 'Login with Phone',
      'hi': 'फोन से लॉगिन करें',
      'gu': 'ફોનથી લોગિન કરો',
    },
    'googleSignIn': {
      'en': 'Continue with Google',
      'hi': 'Google से जारी रखें',
      'gu': 'Google થી ચાલુ રાખો',
    },
    'phoneHint': {'en': 'Phone number', 'hi': 'फोन नंबर', 'gu': 'ફોન નંબર'},
    'otpHint': {'en': '6-digit OTP', 'hi': '6 अंक का OTP', 'gu': '6 અંકનો OTP'},
    'sendOtp': {'en': 'Send OTP', 'hi': 'OTP भेजें', 'gu': 'OTP મોકલો'},
    'verifyOtp': {'en': 'Verify OTP', 'hi': 'OTP सत्यापित करें', 'gu': 'OTP ચકાસો'},
    'deleteAccount': {
      'en': 'Delete Account',
      'hi': 'अकाउंट हटाएं',
      'gu': 'એકાઉન્ટ ડિલીટ કરો',
    },
    'deleteAccountWarn': {
      'en': 'All your data will be permanently removed. Re-login required to confirm.',
      'hi': 'आपका सारा डेटा हमेशा के लिए हट जाएगा। पुष्टि के लिए दोबारा लॉगिन करें।',
      'gu': 'તમારો આખો ડેટા કાયમ માટે ડિલીટ થશે. પુષ્ટિ માટે ફરી લોગિન કરો.',
    },
    // ---- Business ----
    'businessProfile': {
      'en': 'Business Profile',
      'hi': 'बिज़नेस प्रोफ़ाइल',
      'gu': 'બિઝનેસ પ્રોફાઇલ',
    },
    'businessName': {
      'en': 'Business Name',
      'hi': 'बिज़नेस का नाम',
      'gu': 'બિઝનેસનું નામ',
    },
    'myBusinesses': {
      'en': 'My Businesses',
      'hi': 'मेरे बिज़नेस',
      'gu': 'મારા બિઝનેસ',
    },
    'switchBusiness': {
      'en': 'Switch Business',
      'hi': 'बिज़नेस बदलें',
      'gu': 'બિઝનેસ બદલો',
    },
    'addBusiness': {
      'en': 'Add Business',
      'hi': 'बिज़नेस जोड़ें',
      'gu': 'બિઝનેસ ઉમેરો',
    },
    'address': {'en': 'Address', 'hi': 'पता', 'gu': 'સરનામું'},

    // ---- Borrowers ----
    'borrowers': {'en': 'Borrowers', 'hi': 'उधारदार', 'gu': 'ઉધાર લેનાર'},
    'addBorrower': {
      'en': 'Add Borrower',
      'hi': 'उधारदार जोड़ें',
      'gu': 'ઉધાર લેનાર ઉમેરો',
    },
    'pin': {'en': 'Pin', 'hi': 'पिन करें', 'gu': 'પિન કરો'},
    'unpin': {'en': 'Unpin', 'hi': 'अनपिन', 'gu': 'અનપિન'},
    'pinned': {'en': 'Pinned', 'hi': 'पिन किए', 'gu': 'પિન કરેલા'},
    'guarantor': {'en': 'Guarantor', 'hi': 'गारंटर', 'gu': 'ગેરંટીદાર'},

    // ---- Customers / Khata ----
    'customers': {'en': 'Customers', 'hi': 'ग्राहक', 'gu': 'ગ્રાહકો'},
    'addCustomer': {
      'en': 'Add Customer',
      'hi': 'ग्राहक जोड़ें',
      'gu': 'ગ્રાહક ઉમેરો',
    },
    'gave': {'en': 'You Gave', 'hi': 'आपने दिया', 'gu': 'તમે આપ્યું'},
    'got': {'en': 'You Got', 'hi': 'आपने लिया', 'gu': 'તમે લીધું'},
    'balance': {'en': 'Balance', 'hi': 'बैलेंस', 'gu': 'બેલેન્સ'},
    'khataStatement': {
      'en': 'Khata Statement',
      'hi': 'खाता स्टेटमेंट',
      'gu': 'ખાતાનું સ્ટેટમેન્ટ',
    },

    // ---- Loans ----
    'loans': {'en': 'Loans', 'hi': 'लोन', 'gu': 'લોન'},
    'newLoan': {'en': 'New Loan', 'hi': 'नया लोन', 'gu': 'નવી લોન'},
    'loanDetails': {
      'en': 'Loan Details',
      'hi': 'लोन विवरण',
      'gu': 'લોન વિગતો',
    },
    'principal': {'en': 'Principal', 'hi': 'मूलधन', 'gu': 'મૂળ રકમ'},
    'interestRate': {
      'en': 'Interest Rate (% per month)',
      'hi': 'ब्याज दर (% प्रति माह)',
      'gu': 'વ્યાજ દર (% માસિક)',
    },
    'interestType': {
      'en': 'Interest Type',
      'hi': 'ब्याज प्रकार',
      'gu': 'વ્યાજ પ્રકાર',
    },
    'flat': {'en': 'Flat', 'hi': 'फ्लैट', 'gu': 'ફ્લેટ'},
    'reducing': {'en': 'Reducing', 'hi': 'रिड्यूसिंग', 'gu': 'રિડ્યુસિંગ'},
    'interestOnly': {
      'en': 'Interest Only',
      'hi': 'केवल ब्याज',
      'gu': 'ફક્ત વ્યાજ',
    },
    'cycle': {'en': 'Cycle', 'hi': 'साइकिल', 'gu': 'સાયકલ'},
    'daily': {'en': 'Daily', 'hi': 'दैनिक', 'gu': 'દૈનિક'},
    'weekly': {'en': 'Weekly', 'hi': 'साप्ताहिक', 'gu': 'સાપ્તાહિક'},
    'monthly': {'en': 'Monthly', 'hi': 'मासिक', 'gu': 'માસિક'},
    'custom': {'en': 'Custom', 'hi': 'कस्टम', 'gu': 'કસ્ટમ'},
    'numberOfEmis': {
      'en': 'Number of EMIs',
      'hi': 'EMI संख्या',
      'gu': 'EMI સંખ્યા',
    },
    'startDate': {
      'en': 'Start Date',
      'hi': 'शुरुआत तारीख',
      'gu': 'શરૂ તારીખ',
    },
    'emiAmount': {'en': 'EMI Amount', 'hi': 'EMI राशि', 'gu': 'EMI રકમ'},
    'totalPayable': {
      'en': 'Total Payable',
      'hi': 'कुल देय',
      'gu': 'કુલ ચૂકવવાના',
    },
    'paid': {'en': 'Paid', 'hi': 'चुकाया', 'gu': 'ચૂકવ્યું'},
    'pending': {'en': 'Pending', 'hi': 'बाकी', 'gu': 'બાકી'},
    'overdue': {'en': 'Overdue', 'hi': 'ओवरड्यू', 'gu': 'ઓવરડ્યુ'},
    'recordPayment': {
      'en': 'Record Payment',
      'hi': 'पेमेंट दर्ज करें',
      'gu': 'પેમેન્ટ નોંધો',
    },
    'settleLoan': {
      'en': 'Settle / Close Loan',
      'hi': 'लोन सेटल / बंद करें',
      'gu': 'લોન સેટલ / બંધ કરો',
    },
    'muteLoan': {'en': 'Mute Loan', 'hi': 'लोन म्यूट करें', 'gu': 'લોન મ્યૂટ કરો'},
    'unmuteLoan': {
      'en': 'Unmute Loan',
      'hi': 'अनम्यूट करें',
      'gu': 'અનમ્યૂટ કરો',
    },
    'collateral': {'en': 'Collateral', 'hi': 'संपार्श्विक', 'gu': 'જામીનગીરી'},
    'lateFee': {'en': 'Late Fee', 'hi': 'लेट फीस', 'gu': 'લેટ ફી'},
    'processingFee': {
      'en': 'Processing Fee',
      'hi': 'प्रोसेसिंग फीस',
      'gu': 'પ્રોસેસિંગ ફી',
    },
    'loanSchedule': {
      'en': 'EMI Schedule',
      'hi': 'EMI अनुसूची',
      'gu': 'EMI શેડ્યૂલ',
    },
    'activeLoans': {
      'en': 'Active Loans',
      'hi': 'सक्रिय लोन',
      'gu': 'સક્રિય લોન',
    },

    // ---- Dashboard ----
    'dashboard': {'en': 'Dashboard', 'hi': 'डैशबोर्ड', 'gu': 'ડેશબોર્ડ'},
    'home': {'en': 'Home', 'hi': 'होम', 'gu': 'હોમ'},
    'collection': {
      'en': 'Collection',
      'hi': 'कलेक्शन',
      'gu': 'કલેક્શન',
    },
    'profitLoss': {
      'en': 'Profit & Loss',
      'hi': 'मुनाफ़ा-नुकसान',
      'gu': 'નફો-ખોટ',
    },
    'dueCalendar': {
      'en': 'Due Calendar',
      'hi': 'ड्यू कैलेंडर',
      'gu': 'ડ્યુ કેલેન્ડર',
    },
    'quickActions': {
      'en': 'Quick Actions',
      'hi': 'क्विक एक्शन',
      'gu': 'ક્વિક એક્શન',
    },
    'calculator': {
      'en': 'Calculator',
      'hi': 'कैलकुलेटर',
      'gu': 'કેલ્ક્યુલેટર',
    },
    'locker': {'en': 'Document Locker', 'hi': 'डॉक्यूमेंट लॉकर', 'gu': 'ડોક્યુમેન્ટ લોકર'},
    'reports': {'en': 'Reports', 'hi': 'रिपोर्ट्स', 'gu': 'રિપોર્ટ્સ'},
    'staff': {'en': 'Staff', 'hi': 'स्टाफ', 'gu': 'સ્ટાફ'},
    'tasks': {'en': 'Tasks', 'hi': 'टास्क', 'gu': 'ટાસ્ક'},
    'expenses': {'en': 'Expenses', 'hi': 'खर्च', 'gu': 'ખર્ચ'},

    // ---- Scan ----
    'scan': {'en': 'AI Scan', 'hi': 'AI स्कैन', 'gu': 'AI સ્કેન'},
    'scanHint': {
      'en': 'Photo lo — app numbers pehchan kar draft entry banayegi.',
      'hi': 'फोटो लो — ऐप नंबर पहचान कर ड्राफ्ट एंट्री बनाएगा।',
      'gu': 'ફોટો લો — એપ નંબર ઓળખીને ડ્રાફ્ટ એન્ટ્રી બનાવશે.',
    },
    'scanDrafts': {
      'en': 'Draft Entries',
      'hi': 'ड्राफ्ट एंट्री',
      'gu': 'ડ્રાફ્ટ એન્ટ્રી',
    },

    // ---- Lock ----
    'appLock': {'en': 'App Lock', 'hi': 'ऐप लॉक', 'gu': 'એપ લોક'},
    'enterPin': {'en': 'Enter PIN', 'hi': 'PIN डालें', 'gu': 'PIN નાખો'},
    'setPin': {'en': 'Set PIN', 'hi': 'PIN सेट करें', 'gu': 'PIN સેટ કરો'},
    'biometricUnlock': {
      'en': 'Unlock with Fingerprint',
      'hi': 'फिंगरप्रिंट से अनलॉक',
      'gu': 'ફિંગરપ્રિન્ટથી અનલોક',
    },
    'wrongPin': {
      'en': 'Wrong PIN, try again',
      'hi': 'गलत PIN, फिर कोशिश करें',
      'gu': 'ખોટો PIN, ફરી પ્રયત્ન કરો',
    },

    // ---- Settings ----
    'language': {'en': 'Language', 'hi': 'भाषा', 'gu': 'ભાષા'},
    'appearance': {'en': 'Appearance', 'hi': 'दिखावट', 'gu': 'દેખાવ'},
    'light': {'en': 'Light', 'hi': 'लाइट', 'gu': 'લાઇટ'},
    'dark': {'en': 'Dark', 'hi': 'डार्क', 'gu': 'ડાર્ક'},
    'system': {'en': 'System', 'hi': 'सिस्टम', 'gu': 'સિસ્ટમ'},
    'auditLog': {'en': 'Audit Log', 'hi': 'ऑडिट लॉग', 'gu': 'ઑડિટ લોગ'},
    'notifications': {
      'en': 'Notifications',
      'hi': 'सूचनाएं',
      'gu': 'નોટિફિકેશન્સ',
    },
    'about': {'en': 'About', 'hi': 'ऐप के बारे में', 'gu': 'એપ વિશે'},
    'account': {'en': 'Account', 'hi': 'अकाउंट', 'gu': 'એકાઉન્ટ'},
    'offlineMode': {
      'en': 'Offline mode — data stays on this device',
      'hi': 'ऑफलाइन मोड — डेटा इसी डिवाइस पर रहता है',
      'gu': 'ઑફલાઇન મોડ — ડેટા આ જ ઉપકરણ પર રહે છે',
    },

    // ---- Sync ----
    'syncLedger': {
      'en': 'Sync Ledger',
      'hi': 'लेजर सिंक करें',
      'gu': 'લેજર સિંક કરો',
    },
    'syncRequestSent': {
      'en': 'Sync request sent',
      'hi': 'सिंक रिक्वेस्ट भेजी गई',
      'gu': 'સિંક રિક્વેસ્ટ મોકલાઈ',
    },
    'accept': {'en': 'Accept', 'hi': 'स्वीकारें', 'gu': 'સ્વીકારો'},
    'reject': {'en': 'Reject', 'hi': 'अस्वीकारें', 'gu': 'નકારો'},

    // ---- Templates / Bulk ----
    'templates': {
      'en': 'Loan Templates',
      'hi': 'लोन टेम्पलेट',
      'gu': 'લોન ટેમ્પલેટ',
    },
    'saveAsTemplate': {
      'en': 'Save as Template',
      'hi': 'टेम्पलेट के रूप में सेव करें',
      'gu': 'ટેમ્પલેટ તરીકે સેવ કરો',
    },
    'bulkPayment': {
      'en': 'Bulk Payment',
      'hi': 'बल्क पेमेंट',
      'gu': 'બલ્ક પેમેન્ટ',
    },
  };

  String _lookup(String key) {
    final lang = locale.languageCode;
    String? v = _values[key]?[lang];
    if (v == null && lang != 'en') v = _values[key]?['en'];
    return v ?? _resolveNested(key) ?? key;
  }

  /// Allows keys like 'tabs.borrowers' where 'tabs' is a group prefix in the
  /// flat map (e.g. key 'tabs.borrowers' -> stored key 'borrowers').
  static String? _resolveNested(String key) {
    if (!key.contains('.')) return null;
    final leaf = key.split('.').last;
    return _values[leaf]?['en'];
  }

  String t(String key) => _lookup(key);
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      ['en', 'hi', 'gu'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) =>
      SynchronousFuture<AppLocalizations>(AppLocalizations(locale));

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
