import 'package:flutter/material.dart';

/// Languages supported by the app.
enum AppLanguage { english, hindi, gujarati }

extension AppLanguageX on AppLanguage {
  String get code => switch (this) {
        AppLanguage.english => 'en',
        AppLanguage.hindi => 'hi',
        AppLanguage.gujarati => 'gu',
      };

  String get displayName => switch (this) {
        AppLanguage.english => 'English',
        AppLanguage.hindi => 'हिन्दी',
        AppLanguage.gujarati => 'ગુજરાતી',
      };

  static AppLanguage fromCode(String? code) => switch (code) {
        'hi' => AppLanguage.hindi,
        'gu' => AppLanguage.gujarati,
        _ => AppLanguage.english,
      };
}

/// Interest calculation method.
enum InterestType { flat, reducing, interestOnly }

extension InterestTypeX on InterestType {
  String get label => switch (this) {
        InterestType.flat => 'Flat Rate',
        InterestType.reducing => 'Reducing Balance',
        InterestType.interestOnly => 'Interest Only',
      };

  IconData get icon => switch (this) {
        InterestType.flat => Icons.percent,
        InterestType.reducing => Icons.trending_down,
        InterestType.interestOnly => Icons.attach_money,
      };

  static InterestType fromString(String? s) => switch (s) {
        'reducing' => InterestType.reducing,
        'interestOnly' => InterestType.interestOnly,
        _ => InterestType.flat,
      };
}

/// Repayment cycle.
enum PaymentCycle { daily, weekly, monthly, custom }

extension PaymentCycleX on PaymentCycle {
  String get label => switch (this) {
        PaymentCycle.daily => 'Daily',
        PaymentCycle.weekly => 'Weekly',
        PaymentCycle.monthly => 'Monthly',
        PaymentCycle.custom => 'Custom',
      };

  static PaymentCycle fromString(String? s) => switch (s) {
        'weekly' => PaymentCycle.weekly,
        'monthly' => PaymentCycle.monthly,
        'custom' => PaymentCycle.custom,
        _ => PaymentCycle.daily,
      };
}

/// Loan lifecycle status.
enum LoanStatus { active, settled, closed, muted }

extension LoanStatusX on LoanStatus {
  String get label => switch (this) {
        LoanStatus.active => 'Active',
        LoanStatus.settled => 'Settled',
        LoanStatus.closed => 'Closed',
        LoanStatus.muted => 'Muted',
      };

  Color get color => switch (this) {
        LoanStatus.active => const Color(0xFF2E7D32),
        LoanStatus.settled => Colors.blueGrey,
        LoanStatus.closed => Colors.grey,
        LoanStatus.muted => Colors.deepOrange,
      };

  static LoanStatus fromString(String? s) => switch (s) {
        'settled' => LoanStatus.settled,
        'closed' => LoanStatus.closed,
        'muted' => LoanStatus.muted,
        _ => LoanStatus.active,
      };
}

/// Loan product category.
enum LoanCategory { interest, dailyCollection }

extension LoanCategoryX on LoanCategory {
  String get label => switch (this) {
        LoanCategory.interest => 'Interest Loan',
        LoanCategory.dailyCollection => 'Daily Collection',
      };

  static LoanCategory fromString(String? s) =>
      s == 'dailyCollection' ? LoanCategory.dailyCollection : LoanCategory.interest;
}

/// Staff roles.
enum StaffRole { owner, manager, staff }

extension StaffRoleX on StaffRole {
  String get label => switch (this) {
        StaffRole.owner => 'Owner',
        StaffRole.manager => 'Manager',
        StaffRole.staff => 'Staff',
      };

  static StaffRole fromString(String? s) => switch (s) {
        'manager' => StaffRole.manager,
        'staff' => StaffRole.staff,
        _ => StaffRole.owner,
      };
}

/// Payment direction for khata (non-interest customers).
enum LedgerDirection { gave, got }

extension LedgerDirectionX on LedgerDirection {
  String get label => this == LedgerDirection.gave ? 'Gave' : 'Got';

  static LedgerDirection fromString(String? s) =>
      s == 'got' ? LedgerDirection.got : LedgerDirection.gave;
}
