/// App-wide constants.
class AppConstants {
  AppConstants._();

  static const String appName = 'LendMate';

  /// Firestore root collections.
  static const String usersCol = 'users';
  static const String businessesCol = 'businesses';
  static const String borrowersCol = 'borrowers';
  static const String customersCol = 'customers';
  static const String loansCol = 'loans';
  static const String paymentsCol = 'payments';
  static const String documentsCol = 'documents';
  static const String remindersCol = 'reminders';
  static const String tasksCol = 'tasks';
  static const String expensesCol = 'expenses';
  static const String auditLogCol = 'auditLog';
  static const String templatesCol = 'loanTemplates';
  static const String staffCol = 'staff';
  static const String syncRequestsCol = 'syncRequests';
  static const String calcsCol = 'calcHistory';
  static const String customFieldsCol = 'customFields';

  /// Shared prefs keys (local-only settings like theme, language, lock).
  static const String prefThemeMode = 'theme_mode';
  static const String prefLanguage = 'language';
  static const String prefLockEnabled = 'lock_enabled';
  static const String prefLockPin = 'lock_pin';
  static const String prefActiveBusiness = 'active_business';
  static const String prefReminderChannel = 'reminder_channel';

  /// Max photos per loan / borrower document set.
  static const int maxPhotos = 12;
}
