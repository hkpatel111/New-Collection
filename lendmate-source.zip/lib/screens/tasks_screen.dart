import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../services/firestore_service.dart';
import '../services/notification_service.dart';

class TasksScreen extends StatelessWidget {
  const TasksScreen();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('tasks'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addTask(context, t),
        icon: const Icon(Icons.add),
        label: Text(t.t('add')),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirestoreService.instance.tasksStream,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final tasks = snap.data!.docs
              .map((d) => Task.fromMap(d.id, d.data()))
              .toList()
            ..sort((a, b) {
              if (a.done != b.done) return a.done ? 1 : -1;
              return a.dueAt.compareTo(b.dueAt);
            });
          if (tasks.isEmpty) {
            return Center(child: Text(t.t('emptyList')));
          }
          return ListView(
            children: tasks
                .map((task) => CheckboxListTile(
                      value: task.done,
                      onChanged: (v) {
                        final updated = Task(
                          id: task.id,
                          title: task.title,
                          note: task.note,
                          dueAt: task.dueAt,
                          done: v ?? false,
                          reminder: task.reminder,
                          createdAt: task.createdAt,
                        );
                        FirestoreService.instance.saveTask(updated);
                      },
                      title: Text(
                        task.title,
                        style: TextStyle(
                          decoration: task.done
                              ? TextDecoration.lineThrough
                              : null,
                        ),
                      ),
                      subtitle: Text(Utils.dateTime(task.dueAt)),
                      secondary: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          final ok = await Utils.confirmDialog(
                              context, t.t('confirmDelete'));
                          if (ok == true) {
                            await FirestoreService.instance.deleteTask(task.id);
                          }
                        },
                      ),
                    ))
                .toList(),
          );
        },
      ),
    );
  }

  Future<void> _addTask(BuildContext context, AppLocalizations t) async {
    final titleCtrl = TextEditingController();
    DateTime due = DateTime.now().add(const Duration(hours: 1));
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: titleCtrl,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Task'),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.alarm_outlined),
              title: const Text('Remind me at'),
              subtitle: Text(Utils.dateTime(due)),
              onTap: () async {
                final d = await showDatePicker(
                  context: sheetCtx,
                  initialDate: due,
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                );
                if (d == null) return;
                if (!sheetCtx.mounted) return;
                final time = await showTimePicker(
                  context: sheetCtx,
                  initialTime: TimeOfDay.fromDateTime(due),
                );
                if (time != null) {
                  due = DateTime(d.year, d.month, d.day, time.hour, time.minute);
                }
              },
            ),
            FilledButton(
              onPressed: () => Navigator.pop(sheetCtx, true),
              child: Text(t.t('save')),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    final task = Task(
      id: const Uuid().v4(),
      title: titleCtrl.text.trim(),
      dueAt: due,
    );
    await FirestoreService.instance.saveTask(task);
    if (task.reminder && task.dueAt.isAfter(DateTime.now())) {
      await NotificationService.instance.scheduleTaskReminder(
        id: task.id.hashCode & 0x7fffffff,
        title: 'LendMate Task',
        body: task.title,
        at: task.dueAt,
      );
    }
  }
}
