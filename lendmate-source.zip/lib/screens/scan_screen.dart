import 'package:flutter/material.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../services/ocr_service.dart';

/// AI/OCR scan: photo → draft entries for review. Requires a real OCR engine
/// (ML Kit / Cloud Vision) to fill in recognized lines; UI is ready.
class ScanScreen extends StatefulWidget {
  const ScanScreen();

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  List<ScanDraft> _drafts = [];
  bool _busy = false;

  Future<void> _scan({required bool camera}) async {
    setState(() => _busy = true);
    try {
      final drafts = camera
          ? await OcrService.instance.scanFromCamera()
          : await OcrService.instance.scanFromGallery();
      setState(() => _drafts = [..._drafts, ...drafts]);
      if (drafts.isEmpty && mounted) {
        Utils.toast(context,
            'Koi entry nahi mili. OCR engine connect hone ke baad yahan drafts aayenge.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('scan'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            t.t('scanHint'),
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _busy ? null : () => _scan(camera: true),
                  icon: const Icon(Icons.camera_alt_outlined),
                  label: const Text('Camera'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _busy ? null : () => _scan(camera: false),
                  icon: const Icon(Icons.photo_outlined),
                  label: const Text('Gallery'),
                ),
              ),
            ],
          ),
          if (_busy) const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          ),
          const SizedBox(height: 16),
          if (_drafts.isNotEmpty)
            Text(t.t('scanDrafts'),
                style: Theme.of(context).textTheme.titleMedium),
          ..._drafts.map((d) => Card(
                child: CheckboxListTile(
                  value: d.confirmed,
                  onChanged: (v) =>
                      setState(() => d.confirmed = v ?? false),
                  title: Text(d.name),
                  subtitle: Text(
                      '${d.kind == 'loan' ? 'Loan' : 'Khata'} • ${Utils.money(d.amount)}'),
                ),
              )),
        ],
      ),
    );
  }
}
