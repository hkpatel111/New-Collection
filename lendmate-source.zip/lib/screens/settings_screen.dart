import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../providers/app_settings_provider.dart';
import '../providers/auth_provider.dart';
import '../models/models.dart';
import '../services/app_lock_service.dart';
import '../services/firestore_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen();

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final settings = context.watch<AppSettingsProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(t.t('settings'))),
      body: ListView(
        children: [
          // ---- Account ----
          ListTile(
            leading: const Icon(Icons.account_circle_outlined),
            title: Text(auth.user?.displayName ??
                auth.user?.phoneNumber ??
                t.t('account')),
            subtitle: Text(auth.user?.email ?? auth.user?.phoneNumber ?? ''),
          ),
          const Divider(),

          // ---- Business profile ----
          ListTile(
            leading: const Icon(Icons.storefront_outlined),
            title: Text(t.t('businessProfile')),
            subtitle: Text(auth.activeBusiness?.name ?? ''),
            onTap: () => _editBusiness(context, auth, t),
          ),
          ListTile(
            leading: const Icon(Icons.swap_horiz_rounded),
            title: Text(t.t('switchBusiness')),
            subtitle: Text('${auth.businesses.length} businesses'),
            onTap: () => _switchBusinessSheet(context, auth, t),
          ),
          const Divider(),

          // ---- Appearance ----
          ListTile(
            leading: const Icon(Icons.brightness_6_outlined),
            title: Text(t.t('appearance')),
            trailing: SegmentedButton<ThemeMode>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: ThemeMode.light, icon: Icon(Icons.light_mode, size: 18)),
                ButtonSegment(value: ThemeMode.system, icon: Icon(Icons.settings_suggest, size: 18)),
                ButtonSegment(value: ThemeMode.dark, icon: Icon(Icons.dark_mode, size: 18)),
              ],
              selected: {settings.themeMode},
              onSelectionChanged: (s) =>
                  settings.setThemeMode(s.first),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(t.t('language')),
            trailing: DropdownButton<AppLanguage>(
              value: settings.language,
              underline: const SizedBox.shrink(),
              items: AppLanguage.values
                  .map((l) => DropdownMenuItem(
                        value: l,
                        child: Text(l.displayName),
                      ))
                  .toList(),
              onChanged: (l) {
                if (l != null) settings.setLanguage(l);
              },
            ),
          ),
          const Divider(),

          // ---- App lock ----
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(t.t('appLock')),
            subtitle: const Text('PIN + Biometric'),
            trailing: FutureBuilder<bool>(
              future: AppLockService.instance.isEnabled(),
              builder: (context, snap) => Switch(
                value: snap.data ?? false,
                onChanged: (v) => _toggleLock(context, v, t),
              ),
            ),
          ),
          const Divider(),

          // ---- Audit log ----
          ListTile(
            leading: const Icon(Icons.history_edu_outlined),
            title: Text(t.t('auditLog')),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AuditLogScreen()),
            ),
          ),

          // ---- About ----
          const AboutListTile(
            icon: Icon(Icons.info_outline),
            applicationName: 'LendMate',
            applicationVersion: '1.0.0',
            applicationLegalese: 'Loan & Khata Management',
          ),
          const Divider(),

          // ---- Account actions ----
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(t.t('logout')),
            onTap: () async {
              final ok = await Utils.confirmDialog(context, 'Sign out?');
              if (ok == true && context.mounted) {
                await auth.signOut();
              }
            },
          ),
          ListTile(
            leading: Icon(Icons.delete_forever,
                color: Theme.of(context).colorScheme.error),
            title: Text(t.t('deleteAccount'),
                style: TextStyle(color: Theme.of(context).colorScheme.error)),
            onTap: () => _deleteAccount(context, auth, t),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleLock(
      BuildContext context, bool enable, AppLocalizations t) async {
    final service = AppLockService.instance;
    if (enable) {
      final ctrl = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (dCtx) => AlertDialog(
          title: Text(t.t('setPin')),
          content: TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            maxLength: 4,
            obscureText: true,
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(dCtx, false),
                child: Text(t.t('cancel'))),
            FilledButton(
                onPressed: () => Navigator.pop(dCtx, true),
                child: Text(t.t('save'))),
          ],
        ),
      );
      if (ok == true && ctrl.text.length == 4) {
        await service.setPin(ctrl.text);
        await service.setEnabled(true);
      }
    } else {
      await service.setEnabled(false);
    }
    if (mounted) setState(() {});
  }

  Future<void> _editBusiness(
      BuildContext context, AuthProvider auth, AppLocalizations t) async {
    final b = auth.activeBusiness;
    if (b == null) return;
    final nameCtrl = TextEditingController(text: b.name);
    final addrCtrl = TextEditingController(text: b.address);
    final phoneCtrl = TextEditingController(text: b.phone);
    final ok = await showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: Text(t.t('businessProfile')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
                controller: nameCtrl,
                decoration: InputDecoration(labelText: t.t('businessName'))),
            TextField(
                controller: addrCtrl,
                decoration: InputDecoration(labelText: t.t('address'))),
            TextField(
                controller: phoneCtrl,
                decoration:
                    const InputDecoration(labelText: 'Contact phone')),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dCtx, false),
              child: Text(t.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(dCtx, true),
              child: Text(t.t('save'))),
        ],
      ),
    );
    if (ok != true) return;
    final updated = Business(
      id: b.id,
      ownerId: b.ownerId,
      name: nameCtrl.text.trim(),
      address: addrCtrl.text.trim(),
      phone: phoneCtrl.text.trim(),
      logoUrl: b.logoUrl,
      staffIds: b.staffIds,
      createdAt: b.createdAt,
    );
    await FirestoreService.instance.updateBusiness(updated);
  }

  Future<void> _switchBusinessSheet(
      BuildContext context, AuthProvider auth, AppLocalizations t) async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: auth.businesses
              .map((b) => ListTile(
                    leading: const Icon(Icons.storefront_rounded),
                    title: Text(b.name),
                    trailing: b.id == auth.activeBusiness?.id
                        ? const Icon(Icons.check_circle)
                        : null,
                    onTap: () {
                      auth.switchBusiness(b.id);
                      Navigator.pop(sheetCtx);
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  Future<void> _deleteAccount(
      BuildContext context, AuthProvider auth, AppLocalizations t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: Text(t.t('deleteAccount')),
        content: Text(t.t('deleteAccountWarn')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dCtx, false),
              child: Text(t.t('cancel'))),
          FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.error),
              onPressed: () => Navigator.pop(dCtx, true),
              child: Text(t.t('deleteAccount'))),
        ],
      ),
    );
    if (ok != true) return;
    await auth.deleteAccount((msg) {
      if (mounted) Utils.toast(context, msg);
    });
  }
}

class AuditLogScreen extends StatelessWidget {
  const AuditLogScreen();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('auditLog'))),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirestoreService.instance.auditStream,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = snap.data!.docs
              .map((d) => AuditEntry.fromMap(d.id, d.data()))
              .toList();
          if (entries.isEmpty) {
            return Center(child: Text(t.t('emptyList')));
          }
          return ListView(
            children: entries
                .map((e) => ListTile(
                      dense: true,
                      leading: Icon(_iconFor(e.action)),
                      title: Text(
                          '${e.byName}: ${e.action} ${e.entity} ${e.detail}'),
                      subtitle: Text(Utils.dateTime(e.at)),
                    ))
                .toList(),
          );
        },
      ),
    );
  }

  IconData _iconFor(String action) => switch (action) {
        'create' => Icons.add_circle_outline,
        'delete' => Icons.remove_circle_outline,
        'payment' => Icons.payments_outlined,
        _ => Icons.edit_outlined,
      };
}

