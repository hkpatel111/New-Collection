import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../services/repository.dart';

class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('expenses'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addExpense(context, t),
        icon: const Icon(Icons.add),
        label: Text(t.t('add')),
      ),
      body: StreamBuilder<List<Expense>>(
        stream: Repository.instance.expensesStream,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final expenses = [...snap.data!]
            ..sort((a, b) => b.date.compareTo(a.date));

          final now = DateTime.now();
          final thisMonth = expenses
              .where((e) =>
                  e.date.year == now.year && e.date.month == now.month)
              .fold<double>(0, (s, e) => s + e.amount);

          return Column(
            children: [
              Card(
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('This month',
                          style: Theme.of(context).textTheme.titleMedium),
                      Text(Utils.money(thisMonth),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18)),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: expenses.isEmpty
                    ? Center(child: Text(t.t('emptyList')))
                    : ListView(
                        children: expenses
                            .map((e) => ListTile(
                                  leading: const Icon(Icons.receipt_outlined),
                                  title: Text(e.category),
                                  subtitle: Text(
                                      '${Utils.date(e.date)} ${e.note.isEmpty ? '' : '• ${e.note}'}'),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(Utils.money(e.amount)),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline,
                                            size: 20),
                                        onPressed: () =>
                                            Repository.instance
                                                .deleteExpense(e.id),
                                      ),
                                    ],
                                  ),
                                ))
                            .toList(),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _addExpense(BuildContext context, AppLocalizations t) async {
    final amountCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    var category = 'General';
    final categories = [
      'General', 'Travel', 'Rent', 'Salary', 'Food', 'Utilities', 'Other'
    ];
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Category'),
                items: categories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setSheetState(() => category = v ?? 'General'),
              ),
              TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: t.t('amount')),
              ),
              TextField(
                controller: noteCtrl,
                decoration: InputDecoration(labelText: t.t('notes')),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => Navigator.pop(sheetCtx, true),
                child: Text(t.t('save')),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
    if (ok != true) return;
    final amount = Utils.parseAmount(amountCtrl.text);
    if (amount <= 0) return;
    await Repository.instance.saveExpense(Expense(
      id: const Uuid().v4(),
      category: category,
      amount: amount,
      date: DateTime.now(),
      note: noteCtrl.text.trim(),
    ));
  }
}
