import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../providers/data_provider.dart';
import 'loan_detail_screen.dart';
import 'loan_form_screen.dart';

class LoansListScreen extends StatefulWidget {
  const LoansListScreen();

  @override
  State<LoansListScreen> createState() => _LoansListScreenState();
}

class _LoansListScreenState extends State<LoansListScreen> {
  String _query = '';
  String _filter = 'All';
  static const _filters = ['All', 'Active', 'Settled', 'Closed', 'Muted'];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final loans = data.loans.where((l) {
      final statusOk = switch (_filter) {
        'Active' => l.isActive,
        'Settled' => l.status.name == 'settled',
        'Closed' => l.status.name == 'closed',
        'Muted' => l.muted,
        _ => true,
      };
      final queryOk = _query.isEmpty ||
          l.borrowerName.toLowerCase().contains(_query.toLowerCase());
      return statusOk && queryOk;
    }).toList()
      ..sort((a, b) => b.startDate.compareTo(a.startDate));

    return Scaffold(
      appBar: AppBar(title: Text(t.t('loans'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const LoanFormScreen()),
        ),
        icon: const Icon(Icons.add),
        label: Text(t.t('newLoan')),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: t.t('search'),
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Wrap(
            spacing: 8,
            children: _filters
                .map((f) => ChoiceChip(
                      label: Text(f),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                    ))
                .toList(),
          ),
          Expanded(
            child: loans.isEmpty
                ? Center(child: Text(t.t('emptyList')))
                : ListView.builder(
                    itemCount: loans.length,
                    itemBuilder: (context, i) {
                      final l = loans[i];
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: l.status.color.withValues(alpha: 0.15),
                            foregroundColor: l.status.color,
                            child: Text(l.borrowerName.isEmpty
                                ? '?'
                                : l.borrowerName[0].toUpperCase()),
                          ),
                          title: Text(l.borrowerName),
                          subtitle: Text(
                              '${Utils.money(l.principal)} • ${l.status.label}'),
                          trailing: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(Utils.money(l.balanceDue),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold)),
                              Text(l.cycle.label,
                                  style:
                                      Theme.of(context).textTheme.bodySmall),
                            ],
                          ),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => LoanDetailScreen(loanId: l.id)),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
