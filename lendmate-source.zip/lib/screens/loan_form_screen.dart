import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/data_provider.dart';
import '../services/emi_engine.dart';
import '../services/repository.dart';

class LoanFormScreen extends StatefulWidget {
  const LoanFormScreen({
    this.presetBorrowerId,
    this.presetBorrowerName,
  });

  final String? presetBorrowerId;
  final String? presetBorrowerName;

  @override
  State<LoanFormScreen> createState() => _LoanFormScreenState();
}

class _LoanFormScreenState extends State<LoanFormScreen> {
  final _formKey = GlobalKey<FormState>();

  final _principal = TextEditingController();
  final _rate = TextEditingController();
  final _emiCount = TextEditingController();
  final _processingFee = TextEditingController();
  final _lateFee = TextEditingController();
  final _billNumber = TextEditingController();
  final _guarantorName = TextEditingController();
  final _guarantorPhone = TextEditingController();
  final _collateralNote = TextEditingController();
  final _collateralValue = TextEditingController();
  final _notes = TextEditingController();
  final _everyNMonths = TextEditingController(text: '1');

  String? _borrowerId;
  String _borrowerName = '';

  LoanCategory _category = LoanCategory.interest;
  InterestType _interestType = InterestType.flat;
  PaymentCycle _cycle = PaymentCycle.monthly;
  bool _openEnded = false;
  bool _upfrontInterest = false;
  DateTime _startDate = DateTime.now();
  DateTime? _collateralReturnBy;

  @override
  void dispose() {
    for (final c in [
      _principal, _rate, _emiCount, _processingFee, _lateFee,
      _billNumber, _guarantorName, _guarantorPhone, _collateralNote,
      _collateralValue, _notes, _everyNMonths,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Loan get _previewLoan => Loan(
        id: '',
        businessId: '',
        borrowerId: '',
        borrowerName: '',
        category: _category,
        interestType: _interestType,
        cycle: _cycle,
        everyNMonths: int.tryParse(_everyNMonths.text) ?? 1,
        principal: Utils.parseAmount(_principal.text),
        rate: Utils.parseAmount(_rate.text),
        emiCount: int.tryParse(_emiCount.text) ?? 0,
        processingFee: Utils.parseAmount(_processingFee.text),
        lateFeePerCycle: Utils.parseAmount(_lateFee.text),
        startDate: _startDate,
        openEnded: _openEnded,
        upfrontInterest: _upfrontInterest,
      );

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final summary = EmiEngine.summarize(
      principal: _previewLoan.principal,
      ratePctPerMonth: _previewLoan.rate,
      interestType: _interestType,
      cycle: _cycle,
      everyNMonths: _previewLoan.everyNMonths,
      installments: _openEnded ? 12 : (_previewLoan.emiCount <= 0 ? 1 : _previewLoan.emiCount),
    );

    return Scaffold(
      appBar: AppBar(title: Text(t.t('newLoan'))),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ---- Category ----
            SegmentedButton<LoanCategory>(
              segments: [
                ButtonSegment(
                  value: LoanCategory.interest,
                  label: Text(LoanCategory.interest.label),
                ),
                ButtonSegment(
                  value: LoanCategory.dailyCollection,
                  label: const Text('Daily Collection'),
                ),
              ],
              selected: {_category},
              onSelectionChanged: (s) =>
                  setState(() => _category = s.first),
            ),
            const SizedBox(height: 16),

            // ---- Borrower ----
            DropdownButtonFormField<String>(
              value: _borrowerId ?? widget.presetBorrowerId,
              decoration: const InputDecoration(labelText: 'Borrower'),
              items: data.borrowers
                  .map((b) => DropdownMenuItem(
                        value: b.id,
                        child: Text(b.name),
                      ))
                  .toList(),
              validator: (v) =>
                  (v == null || v.isEmpty) ? t.t('required') : null,
              onChanged: (v) {
                setState(() {
                  _borrowerId = v;
                  _borrowerName = data.borrowers
                      .firstWhere((b) => b.id == v,
                          orElse: () => Borrower(id: '', businessId: '', name: ''))
                      .name;
                });
              },
            ),
            const SizedBox(height: 12),

            // ---- Money fields ----
            TextFormField(
              controller: _principal,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: t.t('principal')),
              validator: (v) => Utils.parseAmount(v ?? '') <= 0
                  ? t.t('required')
                  : null,
              onChanged: (_) => setState(() {}),
            ),
            if (_category == LoanCategory.interest) ...[
              const SizedBox(height: 12),
              TextFormField(
                controller: _rate,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration:
                    InputDecoration(labelText: t.t('interestRate')),
                onChanged: (_) => setState(() {}),
              ),
            ],
            const SizedBox(height: 12),
            TextFormField(
              controller: _emiCount,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  labelText: _category == LoanCategory.dailyCollection
                      ? 'Number of Days'
                      : t.t('numberOfEmis')),
              onChanged: (_) => setState(() {}),
            ),
            SwitchListTile(
              title: const Text('Open-ended (no fixed EMIs)'),
              value: _openEnded,
              onChanged: (v) => setState(() => _openEnded = v),
            ),

            if (_category == LoanCategory.interest) ...[
              const SizedBox(height: 8),
              // ---- Interest type ----
              DropdownButtonFormField<InterestType>(
                value: _interestType,
                decoration: InputDecoration(labelText: t.t('interestType')),
                items: InterestType.values
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.label),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _interestType = v ?? InterestType.flat),
              ),
              const SizedBox(height: 12),
              // ---- Cycle ----
              SegmentedButton<PaymentCycle>(
                segments: PaymentCycle.values
                    .map((c) => ButtonSegment(value: c, label: Text(c.label)))
                    .toList(),
                selected: {_cycle},
                onSelectionChanged: (s) =>
                    setState(() => _cycle = s.first),
              ),
              if (_cycle == PaymentCycle.custom) ...[
                const SizedBox(height: 12),
                TextFormField(
                  controller: _everyNMonths,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'Every X months'),
                  onChanged: (_) => setState(() {}),
                ),
              ],
              SwitchListTile(
                title: const Text('Upfront interest (deduct at disbursal)'),
                value: _upfrontInterest,
                onChanged: (v) => setState(() => _upfrontInterest = v),
              ),
            ],

            const SizedBox(height: 8),
            TextFormField(
              controller: _processingFee,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: t.t('processingFee')),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _lateFee,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: '${t.t('lateFee')} (per cycle, optional)'),
            ),
            const SizedBox(height: 12),

            // ---- Start date ----
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_outlined),
              title: Text(t.t('startDate')),
              subtitle: Text(Utils.date(_startDate)),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _startDate,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2100),
                );
                if (d != null) setState(() => _startDate = d);
              },
            ),

            TextFormField(
              controller: _billNumber,
              decoration: const InputDecoration(labelText: 'Bill Number'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _guarantorName,
              decoration: InputDecoration(labelText: '${t.t('guarantor')} name'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _guarantorPhone,
              keyboardType: TextInputType.phone,
              decoration:
                  const InputDecoration(labelText: 'Guarantor phone'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _collateralNote,
              decoration:
                  InputDecoration(labelText: '${t.t('collateral')} note'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _collateralValue,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration:
                  const InputDecoration(labelText: 'Collateral value'),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_repeat_outlined),
              title: const Text('Collateral return by'),
              subtitle: Text(_collateralReturnBy == null
                  ? t.t('optional')
                  : Utils.date(_collateralReturnBy!)),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _collateralReturnBy ?? DateTime.now(),
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2100),
                );
                if (d != null) setState(() => _collateralReturnBy = d);
              },
            ),
            TextFormField(
              controller: _notes,
              decoration: InputDecoration(labelText: t.t('notes')),
              maxLines: 2,
            ),

            // ---- Live preview ----
            const SizedBox(height: 16),
            Card(
              color: Theme.of(context).colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _row(t.t('emiAmount'), Utils.money(summary.emi)),
                    _row(t.t('totalPayable'),
                        Utils.money(summary.totalPayable)),
                    _row('Total Interest',
                        Utils.money(summary.totalInterest)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _save,
              child: Text(t.t('save')),
            ),
            TextButton(
              onPressed: _saveAsTemplate,
              child: Text(t.t('saveAsTemplate')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final selectedId = _borrowerId ?? widget.presetBorrowerId ?? '';
    final selectedName = _borrowerName.isNotEmpty
        ? _borrowerName
        : (widget.presetBorrowerName ?? '');
    var n = int.tryParse(_emiCount.text) ?? 0;
    if (_category == LoanCategory.interest && n <= 0) n = 12;
    final summary = EmiEngine.summarize(
      principal: _previewLoan.principal,
      ratePctPerMonth: _previewLoan.rate,
      interestType: _interestType,
      cycle: _cycle,
      everyNMonths: _previewLoan.everyNMonths,
      installments: _openEnded ? 0 : n,
    );

    final loan = Loan(
      id: '',
      businessId: '',
      borrowerId: selectedId,
      borrowerName: selectedName,
      category: _category,
      interestType: _interestType,
      cycle: _cycle,
      everyNMonths: int.tryParse(_everyNMonths.text) ?? 1,
      principal: Utils.parseAmount(_principal.text),
      rate: Utils.parseAmount(_rate.text),
      emiCount: n,
      emiAmount: summary.emi,
      totalPayable: summary.totalPayable,
      processingFee: Utils.parseAmount(_processingFee.text),
      lateFeePerCycle: Utils.parseAmount(_lateFee.text),
      startDate: _startDate,
      openEnded: _openEnded,
      upfrontInterest: _upfrontInterest,
      billNumber: _billNumber.text.trim(),
      guarantorName: _guarantorName.text.trim(),
      guarantorPhone: Utils.normalizePhone(_guarantorPhone.text),
      collateralNote: _collateralNote.text.trim(),
      collateralValue: Utils.parseAmount(_collateralValue.text),
      collateralReturnBy: _collateralReturnBy,
      notes: _notes.text.trim(),
    );
    try {
      await Repository.instance.saveLoan(loan);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
  }

  Future<void> _saveAsTemplate() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: Text(AppLocalizations.of(context).t('saveAsTemplate')),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'Template name'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dCtx, false),
              child: Text(AppLocalizations.of(context).t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(dCtx, true),
              child: Text(AppLocalizations.of(context).t('save'))),
        ],
      ),
    );
    if (ok != true || ctrl.text.trim().isEmpty) return;
    await Repository.instance.saveTemplate(LoanTemplate(
      id: '',
      name: ctrl.text.trim(),
      interestType: _interestType,
      cycle: _cycle,
      everyNMonths: int.tryParse(_everyNMonths.text) ?? 1,
      rate: Utils.parseAmount(_rate.text),
      emiCount: int.tryParse(_emiCount.text) ?? 0,
      processingFee: Utils.parseAmount(_processingFee.text),
      lateFeePerCycle: Utils.parseAmount(_lateFee.text),
    ));
    if (mounted) Utils.toast(context, 'Template saved');
  }
}
