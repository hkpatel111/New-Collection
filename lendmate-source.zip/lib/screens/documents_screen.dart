import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:uuid/uuid.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../services/repository.dart';
import '../services/storage_service.dart';

/// Document Locker: photos of ID, agreements, collateral — organized by owner.
class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({this.filterOwnerType, this.filterOwnerId});

  final String? filterOwnerType;
  final String? filterOwnerId;

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('locker'))),
      floatingActionButton: _busy
          ? null
          : FloatingActionButton.extended(
              onPressed: () => _upload(context, t),
              icon: const Icon(Icons.add_a_photo_outlined),
              label: const Text('Upload'),
            ),
      body: StreamBuilder<List<LockerDoc>>(
        stream: Repository.instance.lockerStream(
          ownerType: widget.filterOwnerType,
          ownerId: widget.filterOwnerId,
        ),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = [...snap.data!]
            ..sort((a, b) => b.uploadedAt.compareTo(a.uploadedAt));
          if (docs.isEmpty) {
            return Center(child: Text(t.t('emptyList')));
          }
          return GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 6,
              mainAxisSpacing: 6,
            ),
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final doc = docs[i];
              return GestureDetector(
                onTap: () => _preview(context, doc),
                onLongPress: () => _delete(context, doc, t),
                onSecondaryTap: () {},
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      StorageService.isRemoteUrl(doc.url)
                          ? Image.network(
                              doc.url,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                  Icons.insert_drive_file_outlined,
                                  size: 40),
                              loadingBuilder: (context, child, progress) =>
                                  progress == null
                                      ? child
                                      : const Center(
                                          child: CircularProgressIndicator(
                                              strokeWidth: 2)),
                            )
                          : Image.file(
                              File(doc.url),
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                  Icons.insert_drive_file_outlined,
                                  size: 40),
                            ),
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          color: Colors.black45,
                          padding: const EdgeInsets.all(4),
                          child: Text(
                            doc.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 11),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _upload(BuildContext context, AppLocalizations t) async {
    final source = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Camera'),
              onTap: () => Navigator.pop(sheetCtx, 'camera'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_outlined),
              title: const Text('Gallery'),
              onTap: () => Navigator.pop(sheetCtx, 'gallery'),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;

    final xfile = await StorageService.instance
        .pickImage(fromCamera: source == 'camera')
        .onError((_, __) => null);
    if (xfile == null) return;

    setState(() => _busy = true);
    try {
      final url = await StorageService.instance.uploadFile(
        xfile.path,
        folder: 'locker',
      );
      final titleCtrl = TextEditingController(text: xfile.name);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dCtx) => AlertDialog(
          title: const Text('Document details'),
          content: TextField(
            controller: titleCtrl,
            decoration: const InputDecoration(labelText: 'Title'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dCtx),
              child: Text(t.t('cancel')),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dCtx),
              child: Text(t.t('save')),
            ),
          ],
        ),
      );
      await Repository.instance.saveLockerDoc(LockerDoc(
        id: const Uuid().v4(),
        businessId: '',
        ownerType: widget.filterOwnerType ?? 'general',
        ownerId: widget.filterOwnerId ?? '',
        title: titleCtrl.text.trim().isEmpty
            ? xfile.name
            : titleCtrl.text.trim(),
        url: url,
        uploadedAt: DateTime.now(),
      ));
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _preview(BuildContext context, LockerDoc doc) async {
    final file = StorageService.isRemoteUrl(doc.url)
        ? await DefaultCacheManager().getSingleFile(doc.url)
        : File(doc.url);
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(doc.title)),
          body: Center(
            child: InteractiveViewer(child: Image.file(file)),
          ),
        ),
      ),
    );
  }

  Future<void> _delete(
      BuildContext context, LockerDoc doc, AppLocalizations t) async {
    final ok = await Utils.confirmDialog(context, t.t('confirmDelete'));
    if (ok != true) return;
    await Repository.instance.deleteLockerDoc(doc);
    await StorageService.instance.deleteFile(doc.url);
  }
}
