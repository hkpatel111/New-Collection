import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../providers/auth_provider.dart';
import '../providers/data_provider.dart';
import 'borrowers_list_screen.dart';
import 'bulk_payment_screen.dart';
import 'calculator_screen.dart';
import 'customers_list_screen.dart';
import 'documents_screen.dart';
import 'expenses_screen.dart';
import 'loan_detail_screen.dart';
import 'loan_form_screen.dart';
import 'loans_list_screen.dart';
import 'reports_screen.dart';
import 'scan_screen.dart';
import 'settings_screen.dart';
import 'staff_screen.dart';
import 'tasks_screen.dart';

/// Bottom-nav shell: Home / Borrowers / Khata / More.
class HomeShell extends StatefulWidget {
  const HomeShell();

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeDashboard(),
      const BorrowersListScreen(),
      const CustomersListScreen(),
      const MorePage(onNavigate: _push),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: 'Borrowers',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Khata',
          ),
          NavigationDestination(
            icon: Icon(Icons.apps_rounded),
            selectedIcon: Icon(Icons.apps),
            label: 'More',
          ),
        ],
      ),
    );
  }

  void _push(Widget screen) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
}

// ===========================================================================
// Dashboard
// ===========================================================================

class HomeDashboard extends StatefulWidget {
  const HomeDashboard();

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  String _query = '';
  String _filter = 'Active';
  static const _filters = ['Active', 'Settled', 'Closed', 'Muted', 'All'];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final auth = context.watch<AuthProvider>();
    final collection = data.collectionTotals();
    final pl = data.profitLossSummary();

    final loans = data.loans.where((l) {
      final statusOk = switch (_filter) {
        'Active' => l.isActive,
        'Settled' => l.status.name == 'settled',
        'Closed' => l.status.name == 'closed',
        'Muted' => l.muted,
        _ => true,
      };
      final queryOk = _query.isEmpty ||
          l.borrowerName.toLowerCase().contains(_query.toLowerCase());
      return statusOk && queryOk;
    }).toList();

    final calendar = data.dueCalendar(days: 31);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(auth.activeBusiness?.name ?? t.t('appName'),
                overflow: TextOverflow.ellipsis),
            Text(
              'Outstanding: ${Utils.money(data.totalPrincipalOutstanding)}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.switch_account),
            tooltip: t.t('switchBusiness'),
            onPressed: () => _switchBusiness(context, auth, t),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => _push(context, const SettingsScreen()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  title: t.t('today'),
                  value: Utils.money(collection['today'] ?? 0),
                  icon: Icons.today_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StatCard(
                  title: t.t('thisWeek'),
                  value: Utils.money(collection['week'] ?? 0),
                  icon: Icons.date_range_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StatCard(
                  title: t.t('thisMonth'),
                  value: Utils.money(collection['month'] ?? 0),
                  icon: Icons.calendar_month_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  title: t.t('activeLoans'),
                  value: '${data.activeLoans.length}',
                  icon: Icons.handshake_outlined,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StatCard(
                  title: t.t('profitLoss'),
                  value: Utils.money(pl['interestEarned'] ?? 0),
                  icon: Icons.trending_up_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StatCard(
                  title: t.t('overdue'),
                  value: Utils.money(pl['overdue'] ?? 0),
                  icon: Icons.warning_amber_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(t.t('quickActions'),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 0.95,
            mainAxisSpacing: 6,
            crossAxisSpacing: 6,
            children: [
              _QuickAction(
                icon: Icons.calculate_outlined,
                label: t.t('calculator'),
                onTap: () => _push(context, const CalculatorScreen()),
              ),
              _QuickAction(
                icon: Icons.camera_alt_outlined,
                label: t.t('scan'),
                onTap: () => _push(context, const ScanScreen()),
              ),
              _QuickAction(
                icon: Icons.folder_shared_outlined,
                label: t.t('locker'),
                onTap: () => _push(context, const DocumentsScreen()),
              ),
              _QuickAction(
                icon: Icons.assessment_outlined,
                label: t.t('reports'),
                onTap: () => _push(context, const ReportsScreen()),
              ),
              _QuickAction(
                icon: Icons.payments_rounded,
                label: t.t('bulkPayment'),
                onTap: () => _push(context, const BulkPaymentScreen()),
              ),
              _QuickAction(
                icon: Icons.task_alt_rounded,
                label: t.t('tasks'),
                onTap: () => _push(context, const TasksScreen()),
              ),
              _QuickAction(
                icon: Icons.money_off_rounded,
                label: t.t('expenses'),
                onTap: () => _push(context, const ExpensesScreen()),
              ),
              _QuickAction(
                icon: Icons.support_agent_rounded,
                label: t.t('staff'),
                onTap: () => _push(context, const StaffScreen()),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(t.t('dueCalendar'),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _DueCalendarStrip(map: calendar),
          const SizedBox(height: 16),
          TextField(
            decoration: InputDecoration(
              hintText: t.t('search'),
              prefixIcon: const Icon(Icons.search),
            ),
            onChanged: (v) => setState(() => _query = v),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: _filters
                .map((f) => ChoiceChip(
                      label: Text(f),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                    ))
                .toList(),
          ),
          const SizedBox(height: 8),
          if (loans.isEmpty)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Center(child: Text(t.t('emptyList'))),
            )
          else
            ...loans.take(10).map((l) => Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text(l.borrowerName.isEmpty
                          ? '?'
                          : l.borrowerName[0].toUpperCase()),
                    ),
                    title: Text(l.borrowerName),
                    subtitle: Text(
                        '${Utils.money(l.principal)} • ${l.status.label}'),
                    trailing: Text(Utils.money(l.balanceDue)),
                    onTap: () => _push(context, LoanDetailScreen(loanId: l.id)),
                  ),
                )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const LoanFormScreen()),
        icon: const Icon(Icons.add),
        label: Text(t.t('newLoan')),
      ),
    );
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Future<void> _switchBusiness(
      BuildContext context, AuthProvider auth, AppLocalizations t) async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...auth.businesses.map(
              (b) => ListTile(
                leading: const Icon(Icons.storefront_rounded),
                title: Text(b.name),
                trailing: b.id == auth.activeBusiness?.id
                    ? const Icon(Icons.check_circle)
                    : null,
                onTap: () {
                  Navigator.pop(sheetCtx);
                  auth.switchBusiness(b.id);
                },
              ),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.add_business_rounded),
              title: Text(t.t('addBusiness')),
              onTap: () {
                Navigator.pop(sheetCtx);
                _addBusinessDialog(context, auth);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _addBusinessDialog(BuildContext context, AuthProvider auth) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dCtx) => AlertDialog(
        title: Text(AppLocalizations.of(context).t('addBusiness')),
        content: TextField(
          controller: ctrl,
          decoration:
              InputDecoration(labelText: AppLocalizations.of(context).t('businessName')),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dCtx, false),
            child: Text(AppLocalizations.of(context).t('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dCtx, true),
            child: Text(AppLocalizations.of(context).t('save')),
          ),
        ],
      ),
    );
    if (ok == true && ctrl.text.trim().isNotEmpty) {
      await auth.createBusiness(name: ctrl.text.trim());
    }
  }
}

// ===========================================================================
// Widgets
// ===========================================================================

class _StatCard extends StatelessWidget {
  const _StatCard({required this.title, required this.value, required this.icon});

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 6),
            FittedBox(
              child: Text(
                value,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
            ),
            Text(title,
                style: Theme.of(context).textTheme.bodySmall,
                overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 4),
              Text(label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _DueCalendarStrip extends StatelessWidget {
  const _DueCalendarStrip({required this.map});

  final Map<DateTime, double> map;

  @override
  Widget build(BuildContext context) {
    final today = Utils.dayStart(DateTime.now());
    final days = List.generate(14, (i) => today.add(Duration(days: i)));
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: days.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (context, i) {
          final d = days[i];
          final due = map[Utils.dayStart(d)] ?? 0;
          final hasDue = due > 0;
          final overdue = hasDue && d.isBefore(today);
          return Container(
            width: 64,
            decoration: BoxDecoration(
              color: overdue
                  ? Theme.of(context).colorScheme.errorContainer
                  : hasDue
                      ? Theme.of(context).colorScheme.secondaryContainer
                      : Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(10),
            ),
            padding: const EdgeInsets.all(6),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(Utils.dateShort(d),
                    style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 4),
                Text(
                  hasDue ? Utils.compact(due) : '—',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: overdue ? Theme.of(context).colorScheme.error : null,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ===========================================================================
// More page
// ===========================================================================

class MorePage extends StatelessWidget {
  const MorePage({required this.onNavigate});

  final ValueChanged<Widget> onNavigate;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final tiles = [
      (Icons.credit_score_rounded, t.t('loans'),
          const LoansListScreen()),
      (Icons.calculate_outlined, t.t('calculator'), const CalculatorScreen()),
      (Icons.camera_alt_outlined, t.t('scan'), const ScanScreen()),
      (Icons.folder_shared_outlined, t.t('locker'), const DocumentsScreen()),
      (Icons.assessment_outlined, t.t('reports'), const ReportsScreen()),
      (Icons.support_agent_rounded, t.t('staff'), const StaffScreen()),
      (Icons.task_alt_rounded, t.t('tasks'), const TasksScreen()),
      (Icons.money_off_rounded, t.t('expenses'), const ExpensesScreen()),
      (Icons.settings_outlined, t.t('settings'), const SettingsScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        children: tiles
            .map((e) => ListTile(
                  leading: Icon(e.$1),
                  title: Text(e.$2),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => onNavigate(e.$3),
                ))
            .toList(),
      ),
    );
  }
}
