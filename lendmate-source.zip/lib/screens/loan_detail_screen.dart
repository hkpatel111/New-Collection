import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/data_provider.dart';
import '../services/emi_engine.dart';
import '../services/export_service.dart';
import '../services/firestore_service.dart';
import 'payment_form_screen.dart';

class LoanDetailScreen extends StatelessWidget {
  const LoanDetailScreen({required this.loanId});

  final String loanId;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final loan = data.loans.firstWhere(
      (l) => l.id == loanId,
      orElse: () => Loan(
        id: loanId,
        businessId: '',
        borrowerId: '',
        borrowerName: '?',
        startDate: DateTime.now(),
      ),
    );
    final service = FirestoreService.instance;

    final schedule =
        EmiEngine.buildSchedule(loan, payments: _paymentsFor(data, loan));
    final overdue = schedule.fold<double>(
        0, (s, r) => s + (r.isOverdue ? r.remaining : 0));

    return Scaffold(
      appBar: AppBar(
        title: Text(loan.borrowerName),
        actions: [
          IconButton(
            icon: Icon(loan.muted ? Icons.notifications_off : Icons.notifications_active_outlined),
            tooltip: loan.muted ? t.t('unmuteLoan') : t.t('muteLoan'),
            onPressed: () async {
              final updated = _copyLoan(loan)..muted = !loan.muted;
              await service.saveLoan(updated);
            },
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              switch (v) {
                case 'pdf':
                  await ExportService.instance.shareLoanStatement(
                    loan: loan,
                    payments: _paymentsFor(data, loan),
                    schedule: schedule,
                    business: null,
                    asPdf: true,
                  );
                case 'whatsapp':
                  final unpaid = schedule.where((r) => !r.isPaid).toList();
                  final nextEmi = unpaid.isEmpty ? 0.0 : unpaid.first.due;
                  await ExportService.instance.shareTextOnWhatsApp(
                    phone: _borrowerPhone(data, loan),
                    message:
                        'Loan reminder for ${loan.borrowerName}: '
                        'balance due ${Utils.money(loan.balanceDue)}, '
                        'next EMI ${Utils.money(nextEmi)}',
                  );
                case 'settle':
                  final ok = await _confirm(context);
                  if (ok == true) {
                    final updated = _copyLoan(loan)
                      ..status = LoanStatus.settled;
                    await service.saveLoan(updated);
                  }
                case 'close':
                  final ok = await _confirm(context);
                  if (ok == true) {
                    final updated = _copyLoan(loan)..status = LoanStatus.closed;
                    await service.saveLoan(updated);
                  }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'pdf', child: Text('Share PDF Statement')),
              PopupMenuItem(value: 'whatsapp', child: Text('WhatsApp Reminder')),
              PopupMenuItem(value: 'settle', child: Text('Settle Loan')),
              PopupMenuItem(value: 'close', child: Text('Close Loan')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _kv(t.t('principal'), Utils.money(loan.principal)),
                  _kv('Interest', '${loan.rate}%/mo • ${loan.interestType.label}'),
                  _kv(t.t('totalPayable'), Utils.money(loan.totalPayable)),
                  _kv(t.t('paid'), Utils.money(loan.totalPaid)),
                  _kv(t.t('overdue'), Utils.money(overdue),
                      color: overdue > 0 ? Colors.red : null),
                  _kv(t.t('balance'), Utils.money(loan.balanceDue),
                      color: Theme.of(context).colorScheme.primary),
                  if (loan.guarantorName.isNotEmpty)
                    _kv(t.t('guarantor'), loan.guarantorName),
                  if (loan.collateralNote.isNotEmpty) ...[
                    _kv(t.t('collateral'), loan.collateralNote),
                    _kv('Collateral value',
                        '${Utils.money(loan.collateralValue)} (now ${Utils.money(loan.collateralCurrentValue)})'),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PaymentFormScreen(loanId: loan.id),
              ),
            ),
            icon: const Icon(Icons.payments_outlined),
            label: Text(t.t('recordPayment')),
          ),
          const SizedBox(height: 20),
          Text(t.t('loanSchedule'),
              style: Theme.of(context).textTheme.titleMedium),
          ...schedule.map((r) => ListTile(
                dense: true,
                leading: Text('#${r.no}'),
                title: Text(Utils.date(r.dueDate)),
                subtitle: r.isInterestOnly ? const Text('Interest only') : null,
                trailing: Text(
                  r.isPaid
                      ? t.t('paid')
                      : '${Utils.money(r.remaining)}',
                  style: TextStyle(
                    color: r.isOverdue ? Colors.red : null,
                    fontWeight: r.isOverdue ? FontWeight.bold : null,
                  ),
                ),
              )),
          const SizedBox(height: 20),
          Text('Payment History', style: Theme.of(context).textTheme.titleMedium),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: service.paymentsStream(loan.id),
            builder: (context, snap) {
              final payments = (snap.data?.docs ?? const [])
                  .map((d) => Payment.fromMap(d.id, d.data()))
                  .toList()
                ..sort((a, b) => b.date.compareTo(a.date));
              if (payments.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('No payments yet'),
                );
              }
              return Column(
                children: payments
                    .map((p) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.payments_rounded),
                          title: Text(
                              '${Utils.money(p.amount)} ${p.lateFee > 0 ? ' (+${Utils.money(p.lateFee)} late)' : ''}'),
                          subtitle: Text(
                              '${Utils.date(p.date)} ${p.note.isEmpty ? '' : '• ${p.note}'}'),
                        ))
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  List<Payment> _paymentsFor(DataProvider data, Loan loan) =>
      data.payments.where((p) => p.loanId == loan.id).toList();

  String _borrowerPhone(DataProvider data, Loan loan) {
    for (final b in data.borrowers) {
      if (b.id == loan.borrowerId) return b.phone;
    }
    return '';
  }

  Loan _copyLoan(Loan l) => Loan(
        id: l.id,
        businessId: l.businessId,
        borrowerId: l.borrowerId,
        borrowerName: l.borrowerName,
        category: l.category,
        interestType: l.interestType,
        cycle: l.cycle,
        everyNMonths: l.everyNMonths,
        principal: l.principal,
        rate: l.rate,
        emiCount: l.emiCount,
        emiAmount: l.emiAmount,
        totalPayable: l.totalPayable,
        totalPaid: l.totalPaid,
        processingFee: l.processingFee,
        lateFeePerCycle: l.lateFeePerCycle,
        startDate: l.startDate,
        status: l.status,
        billNumber: l.billNumber,
        disbursementMode: l.disbursementMode,
        notes: l.notes,
        voiceNoteUrl: l.voiceNoteUrl,
        guarantorName: l.guarantorName,
        guarantorPhone: l.guarantorPhone,
        collateralNote: l.collateralNote,
        collateralValue: l.collateralValue,
        collateralCurrentValue: l.collateralCurrentValue,
        collateralReturnBy: l.collateralReturnBy,
        collateralPhotoUrls: l.collateralPhotoUrls,
        groupMemberPhones: l.groupMemberPhones,
        createdBy: l.createdBy,
        staffId: l.staffId,
        muted: l.muted,
        upfrontInterest: l.upfrontInterest,
        openEnded: l.openEnded,
        createdAt: l.createdAt,
      );

  Future<bool?> _confirm(BuildContext context) =>
      Utils.confirmDialog(context, 'Confirm this action?');

  Widget _kv(String k, String v, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(k),
            Text(v,
                style: TextStyle(fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      );
}
