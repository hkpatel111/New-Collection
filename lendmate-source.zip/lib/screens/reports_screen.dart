import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../providers/data_provider.dart';
import '../services/export_service.dart';

/// Reports: borrower-wise summary, khata summary, CSV export.
class ReportsScreen extends StatelessWidget {
  const ReportsScreen();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();

    final byBorrower = <String, Map<String, double>>{};
    for (final l in data.loans) {
      final m = byBorrower.putIfAbsent(l.borrowerName, () => {});
      m['principal'] = (m['principal'] ?? 0) + l.principal;
      m['paid'] = (m['paid'] ?? 0) + l.totalPaid;
      m['balance'] = (m['balance'] ?? 0) + l.balanceDue;
    }
    final names = byBorrower.keys.toList()..sort();

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('reports')),
        actions: [
          IconButton(
            tooltip: 'Export CSV',
            icon: const Icon(Icons.table_view_rounded),
            onPressed: () async {
              try {
                await ExportService.instance.exportCsv(
                  loans: data.loans,
                  payments: data.payments,
                  borrowers: data.borrowers,
                  customers: data.customers,
                );
              } catch (e) {
                if (context.mounted) Utils.showError(context, e);
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _row('Total Loans', '${data.loans.length}'),
                  _row('Active', '${data.activeLoans.length}'),
                  _row('Total Given', Utils.money(data.totalPrincipalGiven)),
                  _row('Recovered', Utils.money(data.totalPrincipalRecovered)),
                  _row('Outstanding', Utils.money(data.totalPrincipalOutstanding)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text('Borrower-wise', style: Theme.of(context).textTheme.titleMedium),
          ...names.map((name) {
            final m = byBorrower[name]!;
            return Card(
              child: ListTile(
                title: Text(name),
                subtitle: Text(
                    'Given ${Utils.compact(m['principal'] ?? 0)} • Paid ${Utils.compact(m['paid'] ?? 0)}'),
                trailing: Text(
                  Utils.money(m['balance'] ?? 0),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            );
          }),
          const SizedBox(height: 12),
          Text('Khata (Customers)',
              style: Theme.of(context).textTheme.titleMedium),
          ...data.customers.map((c) => Card(
                child: ListTile(
                  leading: const Icon(Icons.receipt_long_outlined),
                  title: Text(c.name),
                ),
              )),
        ],
      ),
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(k), Text(v, style: const TextStyle(fontWeight: FontWeight.bold))],
        ),
      );
}
