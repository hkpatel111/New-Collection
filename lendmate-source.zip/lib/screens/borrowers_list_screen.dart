import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/data_provider.dart';
import '../services/repository.dart';
import '../services/storage_service.dart';
import 'loan_form_screen.dart';
import 'loan_detail_screen.dart';
import 'documents_screen.dart';

class BorrowersListScreen extends StatefulWidget {
  const BorrowersListScreen();

  @override
  State<BorrowersListScreen> createState() => _BorrowersListScreenState();
}

class _BorrowersListScreenState extends State<BorrowersListScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final borrowers = data.borrowers
        .where((b) => _query.isEmpty || b.name.toLowerCase().contains(_query))
        .toList()
      ..sort((a, b) {
        if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('borrowers')),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () => _push(context, const BorrowerFormScreen()),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const BorrowerFormScreen()),
        icon: const Icon(Icons.person_add_alt_1),
        label: Text(t.t('addBorrower')),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: t.t('search'),
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: borrowers.isEmpty
                ? Center(child: Text(t.t('emptyList')))
                : ListView.builder(
                    itemCount: borrowers.length,
                    itemBuilder: (context, i) {
                      final b = borrowers[i];
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(b.name.isEmpty
                                ? '?'
                                : b.name[0].toUpperCase()),
                          ),
                          title: Row(
                            children: [
                              Expanded(child: Text(b.name)),
                              if (b.pinned)
                                Icon(Icons.push_pin,
                                    size: 16,
                                    color:
                                        Theme.of(context).colorScheme.primary),
                            ],
                          ),
                          subtitle: Text(b.phone.isEmpty
                              ? t.t('optional')
                              : b.phone),
                          onTap: () => _push(
                              context, BorrowerDetailScreen(borrower: b)),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }
}

// ===========================================================================
// Borrower form
// ===========================================================================

class BorrowerFormScreen extends StatefulWidget {
  const BorrowerFormScreen({this.borrower});

  final Borrower? borrower;

  @override
  State<BorrowerFormScreen> createState() => _BorrowerFormScreenState();
}

class _BorrowerFormScreenState extends State<BorrowerFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name =
      TextEditingController(text: widget.borrower?.name ?? '');
  late final TextEditingController _phone =
      TextEditingController(text: widget.borrower?.phone ?? '');
  late final TextEditingController _addr =
      TextEditingController(text: widget.borrower?.address ?? '');
  late final TextEditingController _notes =
      TextEditingController(text: widget.borrower?.notes ?? '');
  bool _pinned = false;
  final _extraFields = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    _pinned = widget.borrower?.pinned ?? false;
    widget.borrower?.customFields.forEach((k, v) {
      _extraFields[k] = TextEditingController(text: v);
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _addr.dispose();
    _notes.dispose();
    for (final c in _extraFields.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(widget.borrower == null
          ? t.t('addBorrower')
          : t.t('edit'))),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _name,
              decoration: InputDecoration(labelText: t.t('required')),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? t.t('required') : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration:
                  const InputDecoration(labelText: 'Phone (for reminders)'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _addr,
              decoration: InputDecoration(labelText: t.t('address')),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              decoration: InputDecoration(labelText: t.t('notes')),
              maxLines: 2,
            ),
            SwitchListTile(
              title: Text(t.t('pin')),
              value: _pinned,
              onChanged: (v) => setState(() => _pinned = v),
            ),
            const Divider(height: 32),
            ..._extraFields.entries.map((e) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextFormField(
                    controller: e.value,
                    decoration: InputDecoration(labelText: e.key),
                  ),
                )),
            OutlinedButton.icon(
              onPressed: _addField,
              icon: const Icon(Icons.add),
              label: const Text('Add Custom Field'),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _save,
              child: Text(t.t('save')),
            ),
          ],
        ),
      ),
    );
  }

  void _addField() {
    showDialog<void>(
      context: context,
      builder: (dCtx) {
        final ctrl = TextEditingController();
        return AlertDialog(
          title: const Text('Custom Field'),
          content: TextField(controller: ctrl),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(dCtx),
                child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                if (ctrl.text.trim().isNotEmpty) {
                  setState(() => _extraFields[ctrl.text.trim()] =
                      TextEditingController());
                }
                Navigator.pop(dCtx);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final fields = <String, String>{};
    _extraFields.forEach((k, c) {
      if (c.text.trim().isNotEmpty) fields[k] = c.text.trim();
    });
    final b = Borrower(
      id: widget.borrower?.id ?? '',
      businessId: '',
      name: _name.text.trim(),
      phone: Utils.normalizePhone(_phone.text),
      address: _addr.text.trim(),
      notes: _notes.text.trim(),
      pinned: _pinned,
      customFields: fields,
    );
    try {
      await Repository.instance.saveBorrower(b);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
  }
}

// ===========================================================================
// Borrower detail
// ===========================================================================

class BorrowerDetailScreen extends StatelessWidget {
  const BorrowerDetailScreen({required this.borrower});

  final Borrower borrower;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final loans = data.loans.where((l) => l.borrowerId == borrower.id).toList();
    final service = Repository.instance;

    return Scaffold(
      appBar: AppBar(
        title: Text(borrower.name),
        actions: [
          IconButton(
            icon: Icon(borrower.pinned ? Icons.push_pin : Icons.push_pin_outlined),
            onPressed: () async {
              final updated = Borrower(
                id: borrower.id,
                businessId: borrower.businessId,
                name: borrower.name,
                phone: borrower.phone,
                address: borrower.address,
                notes: borrower.notes,
                photoUrls: borrower.photoUrls,
                pinned: !borrower.pinned,
                reminderUpdates: borrower.reminderUpdates,
                reminderDues: borrower.reminderDues,
                customFields: borrower.customFields,
                createdBy: borrower.createdBy,
                createdAt: borrower.createdAt,
              );
              await service.saveBorrower(updated);
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await Utils.confirmDialog(
                context,
                AppLocalizations.of(context).t('confirmDelete'),
              );
              if (ok == true) {
                await service.deleteBorrower(borrower.id);
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _infoTile(context, Icons.phone, borrower.phone),
          _infoTile(context, Icons.location_on_outlined, borrower.address),
          if (borrower.notes.isNotEmpty)
            _infoTile(context, Icons.notes, borrower.notes),
          ...borrower.customFields.entries.map(
            (e) => _infoTile(context, Icons.label_outline,
                '${e.key}: ${e.value}'),
          ),
          const Divider(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(t.t('loans'), style: Theme.of(context).textTheme.titleMedium),
              FilledButton.tonalIcon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LoanFormScreen(
                      presetBorrowerId: borrower.id,
                      presetBorrowerName: borrower.name,
                    ),
                  ),
                ),
                icon: const Icon(Icons.add),
                label: Text(t.t('newLoan')),
              ),
            ],
          ),
          ...loans.map((l) => Card(
                child: ListTile(
                  title: Text('${Utils.money(l.principal)} • ${l.status.label}'),
                  subtitle: Text('Balance: ${Utils.money(l.balanceDue)}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => LoanDetailScreen(loanId: l.id)),
                  ),
                ),
              )),
          const Divider(height: 32),
          ListTile(
            leading: const Icon(Icons.folder_shared_outlined),
            title: Text(t.t('locker')),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => DocumentsScreen(
                  filterOwnerType: 'borrower',
                  filterOwnerId: borrower.id,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoTile(BuildContext context, IconData icon, String text) {
    if (text.isEmpty) return const SizedBox.shrink();
    return ListTile(
      dense: true,
      leading: Icon(icon, size: 20),
      title: Text(text),
    );
  }
}
