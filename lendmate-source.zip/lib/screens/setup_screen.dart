import 'package:flutter/material.dart';

/// Shown when firebase_options.dart is still the placeholder.
class SetupScreen extends StatelessWidget {
  const SetupScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.cloud_off_rounded,
                    size: 72, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 24),
                Text(
                  'Firebase setup required',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 12),
                const Text(
                  '1. Firebase console me ek project banao\n'
                  '2. Android app add karo (package: com.lendmate.app)\n'
                  '3. Neeche wala command chalao:\n',
                  textAlign: TextAlign.center,
                ),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'dart run flutterfire configure',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'monospace'),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  '4. google-services.json ko android/app/ me copy karo\n'
                  '5. App dobara run karo',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
