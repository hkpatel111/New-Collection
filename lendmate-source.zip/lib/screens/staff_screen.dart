import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../services/firestore_service.dart';

class StaffScreen extends StatelessWidget {
  const StaffScreen();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('staff'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addStaff(context, t),
        icon: const Icon(Icons.person_add_alt),
        label: const Text('Add Staff'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirestoreService.instance.staffStream,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final staff = snap.data!.docs
              .map((d) => StaffMember.fromMap(d.id, d.data()))
              .toList();
          if (staff.isEmpty) {
            return Center(child: Text(t.t('emptyList')));
          }
          return ListView(
            children: staff
                .map((s) => Card(
                      child: ListTile(
                        leading: CircleAvatar(child: Text(s.name.isEmpty
                            ? '?'
                            : s.name[0].toUpperCase())),
                        title: Text(s.name),
                        subtitle: Text('${s.phone} • ${s.role.label}'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            final ok = await Utils.confirmDialog(
                                context, t.t('confirmDelete'));
                            if (ok == true) {
                              await FirestoreService.instance
                                  .deleteStaff(s.id);
                            }
                          },
                        ),
                      ),
                    ))
                .toList(),
          );
        },
      ),
    );
  }

  Future<void> _addStaff(BuildContext context, AppLocalizations t) async {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    var role = StaffRole.staff;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<StaffRole>(
                value: StaffRole.staff,
                decoration: const InputDecoration(labelText: 'Role'),
                items: StaffRole.values
                    .where((r) => r != StaffRole.owner)
                    .map((r) => DropdownMenuItem(value: r, child: Text(r.label)))
                    .toList(),
                onChanged: (v) => setSheetState(() => role = v ?? StaffRole.staff),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => Navigator.pop(sheetCtx, true),
                child: Text(t.t('save')),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
    if (ok != true || nameCtrl.text.trim().isEmpty) return;
    await FirestoreService.instance.saveStaff(StaffMember(
      id: '',
      name: nameCtrl.text.trim(),
      phone: Utils.normalizePhone(phoneCtrl.text),
      role: role,
    ));
  }
}
