import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/data_provider.dart';
import '../services/firestore_service.dart';

class PaymentFormScreen extends StatefulWidget {
  const PaymentFormScreen({required this.loanId});

  final String loanId;

  @override
  State<PaymentFormScreen> createState() => _PaymentFormScreenState();
}

class _PaymentFormScreenState extends State<PaymentFormScreen> {
  final _amount = TextEditingController();
  final _lateFee = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final auth = context.watch<AuthProvider>();
    final loan = data.loans.firstWhere(
      (l) => l.id == widget.loanId,
      orElse: () => Loan(
        id: '',
        businessId: '',
        borrowerId: '',
        borrowerName: '',
        startDate: DateTime.now(),
      ),
    );

    return Scaffold(
      appBar: AppBar(title: Text(t.t('recordPayment'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Text(loan.borrowerName,
                        style: Theme.of(context).textTheme.titleMedium),
                  ),
                  Text(Utils.money(loan.balanceDue),
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _amount,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: t.t('amount')),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _lateFee,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: '${t.t('lateFee')} (optional)'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _note,
            decoration: InputDecoration(labelText: t.t('notes')),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event_outlined),
            title: Text(t.t('date')),
            subtitle: Text(Utils.date(_date)),
            onTap: () async {
              final d = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2000),
                lastDate: DateTime(2100),
              );
              if (d != null) setState(() => _date = d);
            },
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () => _save(context, loan, auth),
            child: Text(t.t('save')),
          ),
        ],
      ),
    );
  }

  Future<void> _save(BuildContext context, Loan loan, AuthProvider auth) async {
    final amount = Utils.parseAmount(_amount.text);
    if (amount <= 0) {
      Utils.toast(context, 'Enter an amount');
      return;
    }
    final user = auth.user;
    final name = user?.displayName ?? user?.phoneNumber ?? 'Staff';
    final p = Payment(
      id: '',
      businessId: loan.businessId,
      loanId: loan.id,
      borrowerId: loan.borrowerId,
      amount: amount,
      lateFee: Utils.parseAmount(_lateFee.text),
      date: _date,
      note: _note.text.trim(),
      addedBy: user?.uid ?? '',
      addedByName: name,
    );
    try {
      await FirestoreService.instance.addPayment(loan, p);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
  }
}
