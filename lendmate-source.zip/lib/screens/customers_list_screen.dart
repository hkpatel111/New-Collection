import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/data_provider.dart';
import '../services/export_service.dart';
import '../services/repository.dart';

class CustomersListScreen extends StatefulWidget {
  const CustomersListScreen();

  @override
  State<CustomersListScreen> createState() => _CustomersListScreenState();
}

class _CustomersListScreenState extends State<CustomersListScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final list = data.customers
        .where((c) => _query.isEmpty || c.name.toLowerCase().contains(_query))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    return Scaffold(
      appBar: AppBar(title: Text(t.t('customers'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const CustomerFormScreen()),
        icon: const Icon(Icons.add),
        label: Text(t.t('addCustomer')),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: t.t('search'),
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(child: Text(t.t('emptyList')))
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (context, i) {
                      final c = list[i];
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(
                                c.name.isEmpty ? '?' : c.name[0].toUpperCase()),
                          ),
                          title: Text(c.name),
                          subtitle: Text(c.phone.isEmpty
                              ? t.t('optional')
                              : c.phone),
                          onTap: () =>
                              _push(context, KhataScreen(customer: c)),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }
}

// ===========================================================================
// Customer form
// ===========================================================================

class CustomerFormScreen extends StatefulWidget {
  const CustomerFormScreen();

  @override
  State<CustomerFormScreen> createState() => _CustomerFormScreenState();
}

class _CustomerFormScreenState extends State<CustomerFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  final _extraFields = <String, TextEditingController>{};

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _notes.dispose();
    for (final c in _extraFields.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('addCustomer'))),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _name,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? t.t('required') : null,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              decoration: InputDecoration(labelText: t.t('notes')),
            ),
            const Divider(height: 32),
            ..._extraFields.entries.map((e) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextFormField(
                    controller: e.value,
                    decoration: InputDecoration(labelText: e.key),
                  ),
                )),
            OutlinedButton.icon(
              onPressed: () {
                showDialog<void>(
                  context: context,
                  builder: (dCtx) {
                    final ctrl = TextEditingController();
                    return AlertDialog(
                      title: const Text('Custom Field'),
                      content: TextField(controller: ctrl),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(dCtx),
                          child: Text(t.t('cancel')),
                        ),
                        FilledButton(
                          onPressed: () {
                            if (ctrl.text.trim().isNotEmpty) {
                              setState(() => _extraFields[ctrl.text.trim()] =
                                  TextEditingController());
                            }
                            Navigator.pop(dCtx);
                          },
                          child: Text(t.t('add')),
                        ),
                      ],
                    );
                  },
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Custom Field'),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _save,
              child: Text(t.t('save')),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final fields = <String, String>{};
    _extraFields.forEach((k, c) {
      if (c.text.trim().isNotEmpty) fields[k] = c.text.trim();
    });
    final c = Customer(
      id: '',
      businessId: '',
      name: _name.text.trim(),
      phone: Utils.normalizePhone(_phone.text),
      notes: _notes.text.trim(),
      customFields: fields,
    );
    try {
      await Repository.instance.saveCustomer(c);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
  }
}

// ===========================================================================
// Khata ledger
// ===========================================================================

class KhataScreen extends StatefulWidget {
  const KhataScreen({required this.customer});

  final Customer customer;

  @override
  State<KhataScreen> createState() => _KhataScreenState();
}

class _KhataScreenState extends State<KhataScreen> {
  List<KhataEntry> _entriesCache = const [];
  double _balanceCache = 0;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final service = Repository.instance;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.customer.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf_outlined),
            tooltip: t.t('khataStatement'),
            onPressed: () async {
              try {
                await ExportService.instance.shareKhataStatement(
                  customer: widget.customer,
                  entries: _entriesCache,
                  balance: _balanceCache,
                  business: null,
                  asPdf: true,
                );
              } catch (e) {
                if (context.mounted) Utils.showError(context, e);
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () async {
              await ExportService.instance.shareTextOnWhatsApp(
                phone: widget.customer.phone,
                message:
                    'Khata balance for ${widget.customer.name}: ₹$_balanceCache',
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<List<KhataEntry>>(
        stream: service.khataStream(widget.customer.id),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final entries = [...snap.data!]
            ..sort((a, b) => b.date.compareTo(a.date));
          _entriesCache = entries;
          final gave = entries
              .where((e) => e.direction == LedgerDirection.gave)
              .fold<double>(0, (s, e) => s + e.amount);
          final got = entries
              .where((e) => e.direction == LedgerDirection.got)
              .fold<double>(0, (s, e) => s + e.amount);
          _balanceCache = gave - got;

          return Column(
            children: [
              Card(
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _col(context, t.t('gave'), gave, Colors.red),
                      _col(context, t.t('got'), got, Colors.green),
                      _col(context, t.t('balance'), _balanceCache,
                          _balanceCache >= 0 ? Colors.red : Colors.green),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: entries.isEmpty
                    ? Center(child: Text(t.t('emptyList')))
                    : ListView.builder(
                        itemCount: entries.length,
                        itemBuilder: (context, i) {
                          final e = entries[i];
                          final isGave =
                              e.direction == LedgerDirection.gave;
                          return ListTile(
                            leading: Icon(
                              isGave ? Icons.arrow_upward : Icons.arrow_downward,
                              color: isGave ? Colors.red : Colors.green,
                            ),
                            title: Text(Utils.money(e.amount)),
                            subtitle: Text(
                                '${Utils.date(e.date)} ${e.note.isEmpty ? '' : '• ${e.note}'}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20),
                              onPressed: () => service.deleteKhataEntry(
                                  widget.customer.id, e.id),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addEntry(context, service, t),
        icon: const Icon(Icons.add),
        label: Text(t.t('add')),
      ),
    );
  }

  Widget _col(BuildContext context, String label, double v, Color c) {
    return Column(
      children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Text(
          Utils.money(v),
          style: TextStyle(
              color: c, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Future<void> _addEntry(
      BuildContext context, Repository service, AppLocalizations t) async {
    final amountCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    var gave = true;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SegmentedButton<bool>(
                segments: [
                  ButtonSegment(value: true, label: Text(t.t('gave'))),
                  ButtonSegment(value: false, label: Text(t.t('got'))),
                ],
                selected: {gave},
                onSelectionChanged: (s) =>
                    setSheetState(() => gave = s.first),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: t.t('amount')),
              ),
              TextField(
                controller: noteCtrl,
                decoration: InputDecoration(labelText: t.t('notes')),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () {
                  final amt = Utils.parseAmount(amountCtrl.text);
                  if (amt <= 0) {
                    Utils.toast(sheetCtx, 'Enter an amount');
                    return;
                  }
                  Navigator.pop(sheetCtx, true);
                },
                child: Text(t.t('save')),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
    if (ok != true) return;
    try {
      await service.addKhataEntry(
        widget.customer.id,
        KhataEntry(
          id: '',
          customerId: widget.customer.id,
          direction:
              gave ? LedgerDirection.gave : LedgerDirection.got,
          amount: Utils.parseAmount(amountCtrl.text),
          date: DateTime.now(),
          note: noteCtrl.text.trim(),
        ),
      );
    } catch (e) {
      if (mounted) Utils.showError(context, e);
    }
  }
}
