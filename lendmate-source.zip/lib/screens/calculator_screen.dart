import 'package:flutter/material.dart';

import '../core/app_localizations.dart';
import '../core/enums.dart';
import '../core/utils.dart';
import '../services/emi_engine.dart';
import '../services/repository.dart';

/// Standalone interest calculator with cycle-by-cycle breakdown + history.
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen();

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final _principal = TextEditingController(text: '50000');
  final _rate = TextEditingController(text: '2');
  final _months = TextEditingController(text: '12');
  InterestType _type = InterestType.flat;
  PaymentCycle _cycle = PaymentCycle.monthly;
  LoanScheduleSummary? _result;

  @override
  void dispose() {
    _principal.dispose();
    _rate.dispose();
    _months.dispose();
    super.dispose();
  }

  void _calc() {
    final p = Utils.parseAmount(_principal.text);
    final r = Utils.parseAmount(_rate.text);
    final n = int.tryParse(_months.text) ?? 0;
    if (p <= 0 || n <= 0) {
      setState(() => _result = null);
      return;
    }
    setState(() {
      _result = EmiEngine.summarize(
        principal: p,
        ratePctPerMonth: r,
        interestType: _type,
        cycle: _cycle,
        installments: n,
      );
    });
    Repository.instance.saveCalcSummary(
      'P=${Utils.compact(p)} r=$r% n=$n ${_type.label} → EMI ${Utils.compact(_result!.emi)}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(t.t('calculator'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _principal,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(labelText: t.t('principal')),
                  onChanged: (_) => _calc(),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _rate,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration:
                      const InputDecoration(labelText: 'Rate %/month'),
                  onChanged: (_) => _calc(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _months,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Installments'),
            onChanged: (_) => _calc(),
          ),
          const SizedBox(height: 12),
          SegmentedButton<InterestType>(
            segments: InterestType.values
                .map((e) => ButtonSegment(value: e, label: Text(e.label)))
                .toList(),
            selected: {_type},
            onSelectionChanged: (s) {
              setState(() => _type = s.first);
              _calc();
            },
          ),
          const SizedBox(height: 12),
          SegmentedButton<PaymentCycle>(
            segments: PaymentCycle.values
                .map((c) => ButtonSegment(value: c, label: Text(c.label)))
                .toList(),
            selected: {_cycle},
            onSelectionChanged: (s) {
              setState(() => _cycle = s.first);
              _calc();
            },
          ),
          const SizedBox(height: 16),
          if (_result != null) ...[
            Card(
              color: Theme.of(context).colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _row('Per Installment', Utils.money(_result!.emi)),
                    _row('Total Payable', Utils.money(_result!.totalPayable)),
                    _row('Total Interest', Utils.money(_result!.totalInterest)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text('Breakdown', style: Theme.of(context).textTheme.titleMedium),
            ..._result!.rows.take(12).map((r) => ListTile(
                  dense: true,
                  leading: Text('#${r.no}'),
                  title: Text(Utils.date(r.dueDate)),
                  trailing: Text(Utils.money(r.due)),
                )),
          ],
          const SizedBox(height: 12),
          Text('Calculation History',
              style: Theme.of(context).textTheme.titleMedium),
          StreamBuilder<List<Map<String, dynamic>>>(
            stream: Repository.instance.calcHistoryStream,
            builder: (context, snap) {
              final items = snap.data ?? const <Map<String, dynamic>>[];
              if (items.isEmpty) return const SizedBox.shrink();
              return Column(
                children: items
                    .map((d) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.history),
                          title: Text(
                            d['summary'] as String? ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ))
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}
