import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../models/models.dart';
import '../providers/auth_provider.dart';
import '../providers/data_provider.dart';
import '../services/firestore_service.dart';

/// Record payments for many active loans in one scroll of entries.
class BulkPaymentScreen extends StatefulWidget {
  const BulkPaymentScreen();

  @override
  State<BulkPaymentScreen> createState() => _BulkPaymentScreenState();
}

class _BulkPaymentScreenState extends State<BulkPaymentScreen> {
  final _amounts = <String, TextEditingController>{};

  @override
  void dispose() {
    for (final c in _amounts.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<DataProvider>();
    final auth = context.watch<AuthProvider>();
    final loans = data.activeLoans
      ..sort((a, b) => a.borrowerName.compareTo(b.borrowerName));
    final user = auth.user;
    final byName = user?.displayName ?? user?.phoneNumber ?? 'Staff';

    return Scaffold(
      appBar: AppBar(title: Text(t.t('bulkPayment'))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Text(
            'Aaj sab borrowers ki payment ek saath record karo.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          ...loans.map((l) {
            _amounts.putIfAbsent(l.id, () => TextEditingController());
            return Card(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(l.borrowerName,
                              overflow: TextOverflow.ellipsis),
                          Text(
                            'EMI ${Utils.money(l.emiAmount)} • bal ${Utils.compact(l.balanceDue)}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _amounts[l.id],
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        decoration: const InputDecoration(
                          hintText: 'Amount',
                          isDense: true,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: loans.isEmpty ? null : () => _saveAll(loans, user?.uid ?? '', byName),
            icon: const Icon(Icons.done_all_rounded),
            label: Text('Save All Payments'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveAll(List<Loan> loans, String uid, String byName) async {
    final service = FirestoreService.instance;
    var saved = 0;
    for (final l in loans) {
      final raw = _amounts[l.id]?.text ?? '';
      final amt = Utils.parseAmount(raw);
      if (amt <= 0) continue;
      await service.addPayment(
        l,
        Payment(
          id: '',
          businessId: l.businessId,
          loanId: l.id,
          borrowerId: l.borrowerId,
          amount: amt,
          date: DateTime.now(),
          addedBy: uid,
          addedByName: byName,
          note: 'Bulk entry',
        ),
      );
      saved++;
    }
    if (mounted) {
      Utils.toast(context, '$saved payments recorded');
      Navigator.pop(context);
    }
  }
}
