import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_localizations.dart';
import '../core/utils.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen();

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _otpCtrl = TextEditingController();
  bool _otpSent = false;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.account_balance_wallet_rounded,
                    size: 64, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 8),
                Text(
                  t.t('appName'),
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 32),
                if (!_otpSent) ...[
                  TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone number',
                      prefixText: '+91 ',
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : () => _sendOtp(auth),
                    child: Text(t.t('sendOtp')),
                  ),
                ] else ...[
                  TextField(
                    controller: _otpCtrl,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24, letterSpacing: 12),
                    decoration: InputDecoration(labelText: t.t('otpHint')),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : () => _verify(auth),
                    child: Text(t.t('verifyOtp')),
                  ),
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() => _otpSent = false),
                    child: Text(t.t('phoneHint')),
                  ),
                ],
                const SizedBox(height: 24),
                Row(children: [
                  const Expanded(child: Divider()),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text('OR',
                        style: Theme.of(context).textTheme.bodySmall),
                  ),
                  const Expanded(child: Divider()),
                ]),
                const SizedBox(height: 24),
                OutlinedButton.icon(
                  onPressed: _busy ? null : () => _google(auth),
                  icon: const Icon(Icons.login_rounded),
                  label: Text(t.t('googleSignIn')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _sendOtp(AuthProvider auth) async {
    final phone = Utils.normalizePhone(_phoneCtrl.text);
    if (phone.length < 12) {
      Utils.toast(context, 'Enter a valid phone number');
      return;
    }
    setState(() => _busy = true);
    await auth.sendOtp(
      phone: phone,
      onSent: () {
        if (mounted) setState(() {
          _otpSent = true;
          _busy = false;
        });
      },
      onError: (msg) {
        if (mounted) {
          setState(() => _busy = false);
          Utils.toast(context, msg);
        }
      },
    );
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _verify(AuthProvider auth) async {
    setState(() => _busy = true);
    try {
      await auth.verifyOtp(_otpCtrl.text.trim());
    } catch (e) {
      if (mounted) Utils.toast(context, 'Invalid OTP');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _google(AuthProvider auth) async {
    setState(() => _busy = true);
    try {
      await auth.signInWithGoogle();
    } catch (e) {
      if (mounted) Utils.toast(context, 'Google sign-in failed');
    }
    if (mounted) setState(() => _busy = false);
  }
}
