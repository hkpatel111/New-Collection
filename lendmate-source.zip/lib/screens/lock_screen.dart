import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_localizations.dart';
import '../services/app_lock_service.dart';

/// PIN + biometric unlock gate.
class LockScreen extends StatefulWidget {
  const LockScreen({required this.onUnlocked});

  final VoidCallback onUnlocked;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _tryBiometric();
  }

  Future<void> _tryBiometric() async {
    final service = AppLockService.instance;
    if (await service.deviceHasBiometrics()) {
      final ok = await service.authenticateBiometric();
      if (ok && mounted) widget.onUnlocked();
    }
  }

  Future<void> _onKey(String digit) async {
    if (_pin.length >= 4) return;
    final next = _pin + digit;
    setState(() => _pin = next);
    if (next.length == 4) {
      final ok = await AppLockService.instance.verifyPin(next);
      if (ok) {
        widget.onUnlocked();
      } else {
        await Future.delayed(const Duration(milliseconds: 250));
        if (mounted) {
          HapticFeedback.heavyImpact();
          setState(() {
            _pin = '';
            _error = true;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_rounded, size: 56),
              const SizedBox(height: 16),
              Text(t.t('enterPin'), style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text(
                _error ? t.t('wrongPin') : '',
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) {
                  final filled = i < _pin.length;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context)
                              .colorScheme
                              .surfaceContainerHighest,
                    ),
                  );
                }),
              ),
              const SizedBox(height: 32),
              ...[
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '9'],
                ['', '0', '⌫'],
              ].map(_buildRow),

            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: keys.map((k) {
        if (k.isEmpty) return const SizedBox(width: 72, height: 72);
        return Padding(
          padding: const EdgeInsets.all(6),
          child: SizedBox(
            width: 72,
            height: 60,
            child: k == '⌫'
                ? IconButton(
                    onPressed: () =>
                        setState(() => _pin = _pin.isEmpty ? '' : _pin.substring(0, _pin.length - 1)),
                    icon: const Icon(Icons.backspace_outlined),
                  )
                : FilledButton.tonal(
                    onPressed: () => _onKey(k),
                    child: Text(k, style: const TextStyle(fontSize: 20)),
                  ),
          ),
        );
      }).toList(),
    );
  }
}
