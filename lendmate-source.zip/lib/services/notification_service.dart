import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../core/constants.dart';

/// Local notifications (task alarms + demo due reminders) and FCM push setup.
class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tzdata.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(
      const InitializationSettings(android: android),
    );
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  Future<void> scheduleTaskReminder({
    required int id,
    required String title,
    required String body,
    required DateTime at,
  }) async {
    if (at.isBefore(DateTime.now())) return;
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(at, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'lendmate_tasks',
          'Task Alarms',
          channelDescription: 'Reminders for your to-do items',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  Future<void> cancelTaskReminder(int id) => _plugin.cancel(id);

  /// Registers the device for push notifications and stores the FCM token on
  /// the user's Firestore doc + session list (active devices).
  Future<void> registerPush({required String uid}) async {
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission();

    // A Cloud Function / scheduled job uses these tokens server-side.
    final token = await messaging.getToken();
    if (token != null) {
      await FirebaseFirestore.instance
          .collection(AppConstants.usersCol)
          .doc(uid)
          .collection('sessions')
          .doc(token.hashCode.toString())
          .set({
        'fcmToken': token,
        'platform': defaultTargetPlatform.name,
        'lastActiveAt': FieldValue.serverTimestamp(),
      });
    }
    messaging.onTokenRefresh.listen((t) {
      FirebaseFirestore.instance
          .collection(AppConstants.usersCol)
          .doc(uid)
          .update({'fcmToken': t});
    });
  }
}
