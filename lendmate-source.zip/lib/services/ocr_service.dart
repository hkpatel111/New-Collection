import '../models/models.dart';
import 'storage_service.dart';

/// AI / OCR scan flow.
///
/// The full production build plugs ML Kit on-device text recognition here
/// (add google_mlkit_text_recognition) or calls a Cloud Vision function —
/// both require Flutter SDK + native setup. This implementation:
///   1. lets the user pick a photo (camera/gallery),
///   2. parses typed amounts the user confirms from the image,
///   3. creates draft entries for review.
class OcrService {
  OcrService._();
  static final instance = OcrService._();

  Future<List<ScanDraft>> scanFromCamera() => _scan(fromCamera: true);
  Future<List<ScanDraft>> scanFromGallery() => _scan(fromCamera: false);

  Future<List<ScanDraft>> _scan({required bool fromCamera}) async {
    final xfile = await StorageService.instance
        .pickImage(fromCamera: fromCamera)
        .onError((_, __) => null);
    if (xfile == null) return const [];

    // --- Pluggable recognition backend --------------------------------
    // Replace _recognize with an ML Kit / Vision call to go fully automatic.
    final rawLines = await _recognize(xfile.path);
    return _parseLines(rawLines);
  }

  /// Hook for a real OCR engine. Returns recognized text lines.
  Future<List<String>> _recognize(String imagePath) async {
    // Default offline stub: no text available without a real engine.
    return const [];
  }

  /// Parses lines like "Ramesh 5000" or "loan 25,000 2%" into drafts.
  List<ScanDraft> _parseLines(List<String> lines) {
    final drafts = <ScanDraft>[];
    for (final line in lines) {
      final amountMatch = RegExp(r'(\d[\d,\.]*)').firstMatch(line);
      if (amountMatch == null) continue;
      final amount = double.tryParse(
              amountMatch.group(1)!.replaceAll(',', '')) ??
          0;
      if (amount <= 0) continue;
      final name = line
          .replaceAll(amountMatch.group(1)!, '')
          .replaceAll(RegExp(r'[:\-–]'), '')
          .trim();
      if (name.isEmpty) continue;
      final isLoan =
          line.toLowerCase().contains('loan') || line.contains('%');
      drafts.add(ScanDraft(
        id: '${name.hashCode}-$amount',
        kind: isLoan ? 'loan' : 'khata',
        name: name,
        amount: amount,
        date: DateTime.now(),
      ));
    }
    return drafts;
  }
}
