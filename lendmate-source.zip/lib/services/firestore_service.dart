import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants.dart';
import '../core/utils.dart';
import '../models/models.dart';

/// Central Firestore data access for every module. Paths are scoped by
/// business so staff can be granted per-business access.
class FirestoreService {
  FirestoreService._();
  static final instance = FirestoreService._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  String _bid = '';
  String _uidReal = '';
  String _userName = '';

  bool get hasContext => _uidReal.isNotEmpty && _bid.isNotEmpty;

  void setContext(String uid, String businessId, String userName) {
    _uidReal = uid;
    _bid = businessId;
    _userName = userName;
  }

  void clearContext() {
    _uidReal = '';
    _bid = '';
  }

  // ---------------- Businesses ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> businessesStream(String uid) =>
      _db
          .collection(AppConstants.businessesCol)
          .where('ownerId', isEqualTo: uid)
          .snapshots();

  Future<DocumentReference<Map<String, dynamic>>> addBusiness(Business b) =>
      _db.collection(AppConstants.businessesCol).add(b.toMap());

  Future<void> updateBusiness(Business b) => _db
      .collection(AppConstants.businessesCol)
      .doc(b.id)
      .update(b.toMap());

  // ---------------- Borrowers ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> borrowersStream() => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.borrowersCol)
      .snapshots();

  Future<void> saveBorrower(Borrower b) async {
    final col = _borrowers;
    if (b.id.isEmpty) {
      await col.add(b.toMap());
    } else {
      await col.doc(b.id).update(b.toMap());
    }
    await _audit(b.id.isEmpty ? 'create' : 'update', 'borrower', b.id, b.name);
  }

  Future<void> deleteBorrower(String id) async {
    await _borrowers.doc(id).delete();
    await _audit('delete', 'borrower', id, '');
  }

  CollectionReference<Map<String, dynamic>> get _borrowers => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.borrowersCol);

  // ---------------- Customers & khata ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> customersStream() => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.customersCol)
      .snapshots();

  Future<void> saveCustomer(Customer c) async {
    final col = _customers;
    if (c.id.isEmpty) {
      await col.add(c.toMap());
    } else {
      await col.doc(c.id).update(c.toMap());
    }
    await _audit(c.id.isEmpty ? 'create' : 'update', 'customer', c.id, c.name);
  }

  Future<void> deleteCustomer(String id) async {
    await _customers.doc(id).delete();
    await _audit('delete', 'customer', id, '');
  }

  CollectionReference<Map<String, dynamic>> get _customers => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.customersCol);

  Stream<QuerySnapshot<Map<String, dynamic>>> khataStream(String customerId) =>
      _customers.doc(customerId).collection('entries').snapshots();

  Future<void> addKhataEntry(String customerId, KhataEntry e) async {
    await _customers.doc(customerId).collection('entries').add(e.toMap());
    await _audit('create', 'khataEntry', customerId, '${e.direction.name} ${e.amount}');
  }

  Future<void> deleteKhataEntry(String customerId, String entryId) async {
    await _customers.doc(customerId).collection('entries').doc(entryId).delete();
  }

  // ---------------- Loans ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> loansStream() => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.loansCol)
      .snapshots();

  Future<String> saveLoan(Loan l) async {
    if (l.id.isEmpty) {
      final ref = await _loans.add(l.toMap());
      await _audit('create', 'loan', ref.id, l.borrowerName);
      return ref.id;
    }
    await _loans.doc(l.id).update(l.toMap());
    await _audit('update', 'loan', l.id, l.borrowerName);
    return l.id;
  }

  Future<void> deleteLoan(String id) async {
    await _loans.doc(id).delete();
    await _audit('delete', 'loan', id, '');
  }

  CollectionReference<Map<String, dynamic>> get _loans => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.loansCol);

  Stream<QuerySnapshot<Map<String, dynamic>>> paymentsStream(String loanId) =>
      _loans.doc(loanId).collection(AppConstants.paymentsCol).snapshots();

  /// All payments for this business (bulk entry + reports).
  Stream<QuerySnapshot<Map<String, dynamic>>> allPaymentsStream() => _db
      .collectionGroup(AppConstants.paymentsCol)
      .where('businessId', isEqualTo: _bid)
      .snapshots();

  Future<void> addPayment(Loan loan, Payment p) async {
    await _loans.doc(loan.id).collection(AppConstants.paymentsCol).add(p.toMap());
    await _loans.doc(loan.id).update({
      'totalPaid': FieldValue.increment(p.amount),
      'status': loan.status.name,
    });
    await _audit('payment', 'loan', loan.id,
        '${p.addedByName} recorded ${p.amount}');
  }

  // ---------------- Locker ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> lockerStream({String? ownerType, String? ownerId}) {
    Query<Map<String, dynamic>> q = _docsCol as Query<Map<String, dynamic>>;
    if (ownerType != null && ownerType.isNotEmpty) {
      q = q.where('ownerType', isEqualTo: ownerType);
    }
    if (ownerId != null && ownerId.isNotEmpty) {
      q = q.where('ownerId', isEqualTo: ownerId);
    }
    return q.snapshots();
  }

  CollectionReference<Map<String, dynamic>> get _docsCol => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.documentsCol);

  Future<void> saveLockerDoc(LockerDoc d) async {
    if (d.id.isEmpty) {
      await _docsCol.add(d.toMap());
    } else {
      await _docsCol.doc(d.id).set(d.toMap());
    }
  }

  Future<void> deleteLockerDoc(LockerDoc d) async {
    await _docsCol.doc(d.id).delete();
  }

  // ---------------- Tasks / Expenses / Templates / Staff ----------------

  Stream<QuerySnapshot<Map<String, dynamic>>> get tasksStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.tasksCol)
      .snapshots();

  Future<void> saveTask(Task t) async {
    final col = _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.tasksCol);
    if (t.id.isEmpty) {
      await col.add(t.toMap());
    } else {
      await col.doc(t.id).update(t.toMap());
    }
  }

  Future<void> deleteTask(String id) async {
    await _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.tasksCol)
        .doc(id)
        .delete();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> get expensesStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.expensesCol)
      .snapshots();

  Future<void> saveExpense(Expense e) async {
    final col = _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.expensesCol);
    if (e.id.isEmpty) {
      await col.add(e.toMap());
    } else {
      await col.doc(e.id).update(e.toMap());
    }
  }

  Future<void> deleteExpense(String id) async {
    await _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.expensesCol)
        .doc(id)
        .delete();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> get templatesStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.templatesCol)
      .snapshots();

  Future<void> saveTemplate(LoanTemplate t) async {
    final col = _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.templatesCol);
    if (t.id.isEmpty) {
      await col.add(t.toMap());
    } else {
      await col.doc(t.id).set(t.toMap());
    }
  }

  Future<void> deleteTemplate(String id) => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.templatesCol)
      .doc(id)
      .delete();

  Stream<QuerySnapshot<Map<String, dynamic>>> get staffStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.staffCol)
      .snapshots();

  Future<void> saveStaff(StaffMember s) async {
    final col = _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.staffCol);
    if (s.id.isEmpty) {
      await col.add(s.toMap());
    } else {
      await col.doc(s.id).set(s.toMap());
    }
  }

  Future<void> deleteStaff(String id) => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.staffCol)
      .doc(id)
      .delete();

  // ---------------- Audit log ----------------

  Future<void> _audit(String action, String entity, String entityId, String detail) async {
    if (!hasContext) return;
    await _db
        .collection(AppConstants.businessesCol)
        .doc(_bid)
        .collection(AppConstants.auditLogCol)
        .add({
      'action': action,
      'entity': entity,
      'entityId': entityId,
      'byUid': _uidReal,
      'byName': _userName,
      'at': FieldValue.serverTimestamp(),
      'detail': detail,
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> get auditStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.auditLogCol)
      .orderBy('at', descending: true)
      .limit(200)
      .snapshots();

  // ---------------- Sync requests ----------------

  CollectionReference<Map<String, dynamic>> get _syncCol =>
      _db.collection(AppConstants.syncRequestsCol);

  Future<void> sendSyncRequest({
    required String fromPhone,
    required String toPhone,
    required String entityType,
    required String entityId,
    required bool fullHistory,
    required String fromName,
  }) async {
    await _syncCol.add({
      'fromPhoneKey': Utils.phoneKey(fromPhone),
      'toPhoneKey': Utils.phoneKey(toPhone),
      'entityType': entityType,
      'entityId': entityId,
      'fullHistory': fullHistory,
      'status': 'pending',
      'fromName': fromName,
      'requestedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> incomingSyncRequests(String myPhone) =>
      _syncCol
          .where('toPhoneKey', isEqualTo: Utils.phoneKey(myPhone))
          .where('status', isEqualTo: 'pending')
          .snapshots();

  Future<void> respondSyncRequest(String id, bool accept) =>
      _syncCol.doc(id).update({'status': accept ? 'accepted' : 'rejected'});

  // ---------------- Reminder history ----------------

  Future<void> logReminder(ReminderLog r) => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.remindersCol)
      .add(r.toMap());

  Stream<QuerySnapshot<Map<String, dynamic>>> reminderHistoryStream(String loanId) =>
      _db
          .collection(AppConstants.businessesCol)
          .doc(_bid)
          .collection(AppConstants.remindersCol)
          .where('loanId', isEqualTo: loanId)
          .snapshots();

  // ---------------- Calc history ----------------

  Future<void> saveCalcSummary(String summary) => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.calcsCol)
      .add({'summary': summary, 'savedAt': FieldValue.serverTimestamp()});

  Stream<QuerySnapshot<Map<String, dynamic>>> get calcHistoryStream => _db
      .collection(AppConstants.businessesCol)
      .doc(_bid)
      .collection(AppConstants.calcsCol)
      .orderBy('savedAt', descending: true)
      .limit(50)
      .snapshots();
}
