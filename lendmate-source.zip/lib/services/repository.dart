import '../core/constants.dart';
import '../models/models.dart';
import 'local_store.dart';

// ===========================================================================
// Repository — the app's single data access layer, backed by LocalStore.
//
// This replaces the old Firebase Repository: same method names and
// call-sites, but streams expose typed domain models instead of Firestore
// QuerySnapshots, and everything lives on-device (SharedPreferences JSON).
// ===========================================================================

class Repository {
  Repository._();
  static final instance = Repository._();

  final LocalStore _store = LocalStore.instance;

  String _bid = '';
  String _uidReal = '';
  String _userName = '';

  bool get hasContext => _uidReal.isNotEmpty && _bid.isNotEmpty;

  void setContext(String uid, String businessId, String userName) {
    _uidReal = uid;
    _bid = businessId;
    _userName = userName;
  }

  void clearContext() {
    _uidReal = '';
    _bid = '';
    _userName = '';
  }

  String get _bizPath => '${AppConstants.businessesCol}/$_bid';

  /// Watches one collection and maps raw docs to domain models.
  Stream<List<T>> _stream<T>(
    String path, {
    required T Function(String id, Map<String, dynamic> data) from,
    bool Function(Map<String, dynamic> data)? where,
    int Function(T a, T b)? sort,
    int limit = 0,
  }) {
    return _store.watch(path).map((col) {
      final items = <T>[];
      col.forEach((id, data) {
        if (where == null || where(data)) items.add(from(id, data));
      });
      if (sort != null) items.sort(sort);
      if (limit > 0 && items.length > limit) {
        return items.sublist(items.length - limit);
      }
      return items;
    });
  }

  // ---------------- Businesses ----------------

  Stream<List<Business>> businessesStream(String uid) => _stream(
        AppConstants.businessesCol,
        from: Business.fromMap,
        where: (m) => m['ownerId'] == uid,
        sort: (a, b) => a.createdAt.compareTo(b.createdAt),
      );

  Future<String> addBusiness(Business b) =>
      _store.add(AppConstants.businessesCol, b.toMap());

  Future<void> updateBusiness(Business b) =>
      _store.set(AppConstants.businessesCol, b.id, b.toMap());

  // ---------------- Borrowers ----------------

  Stream<List<Borrower>> borrowersStream() =>
      _stream('$_bizPath/${AppConstants.borrowersCol}', from: Borrower.fromMap);

  Future<void> saveBorrower(Borrower b) async {
    final path = '$_bizPath/${AppConstants.borrowersCol}';
    if (b.id.isEmpty) {
      await _store.add(path, b.toMap());
    } else {
      await _store.update(path, b.id, b.toMap());
    }
    await _audit(b.id.isEmpty ? 'create' : 'update', 'borrower', b.id, b.name);
  }

  Future<void> deleteBorrower(String id) async {
    await _store.delete('$_bizPath/${AppConstants.borrowersCol}', id);
    await _audit('delete', 'borrower', id, '');
  }

  // ---------------- Customers & khata ----------------

  Stream<List<Customer>> customersStream() =>
      _stream('$_bizPath/${AppConstants.customersCol}', from: Customer.fromMap);

  Future<void> saveCustomer(Customer c) async {
    final path = '$_bizPath/${AppConstants.customersCol}';
    if (c.id.isEmpty) {
      await _store.add(path, c.toMap());
    } else {
      await _store.update(path, c.id, c.toMap());
    }
    await _audit(c.id.isEmpty ? 'create' : 'update', 'customer', c.id, c.name);
  }

  Future<void> deleteCustomer(String id) async {
    await _store.delete('$_bizPath/${AppConstants.customersCol}', id);
    await _audit('delete', 'customer', id, '');
  }

  String _entriesPath(String customerId) =>
      '$_bizPath/${AppConstants.customersCol}/$customerId/entries';

  Stream<List<KhataEntry>> khataStream(String customerId) =>
      _stream(_entriesPath(customerId), from: KhataEntry.fromMap);

  Future<void> addKhataEntry(String customerId, KhataEntry e) async {
    await _store.add(_entriesPath(customerId), e.toMap());
    await _audit(
        'create', 'khataEntry', customerId, '${e.direction.name} ${e.amount}');
  }

  Future<void> deleteKhataEntry(String customerId, String entryId) async {
    await _store.delete(_entriesPath(customerId), entryId);
  }

  // ---------------- Loans ----------------

  String get _loansPath => '$_bizPath/${AppConstants.loansCol}';

  Stream<List<Loan>> loansStream() => _stream(_loansPath, from: Loan.fromMap);

  Future<String> saveLoan(Loan l) async {
    if (l.id.isEmpty) {
      final id = await _store.add(_loansPath, l.toMap());
      await _audit('create', 'loan', id, l.borrowerName);
      return id;
    }
    await _store.update(_loansPath, l.id, l.toMap());
    await _audit('update', 'loan', l.id, l.borrowerName);
    return l.id;
  }

  Future<void> deleteLoan(String id) async {
    await _store.delete(_loansPath, id);
    await _audit('delete', 'loan', id, '');
  }

  String _paymentsPath(String loanId) =>
      '$_loansPath/$loanId/${AppConstants.paymentsCol}';

  Stream<List<Payment>> paymentsStream(String loanId) =>
      _stream(_paymentsPath(loanId), from: Payment.fromMap);

  /// All payments for this business. Watches the loans collection: every
  /// payment write also updates its parent loan doc, so loan-level changes
  /// re-emit this stream, and payments are re-read from the store then.
  Stream<List<Payment>> allPaymentsStream() {
    return _store.watch(_loansPath).map((loans) {
      final items = <Payment>[];
      loans.forEach((loanId, _) {
        final col = _store.snapshot(_paymentsPath(loanId));
        col.forEach((id, data) => items.add(Payment.fromMap(id, data)));
      });
      return items;
    });
  }

  Future<void> addPayment(Loan loan, Payment p) async {
    await _store.add(_paymentsPath(loan.id), p.toMap());
    final doc = _store.snapshot(_loansPath)[loan.id] ?? const {};
    final current = (doc['totalPaid'] as num?) ?? 0;
    await _store.update(_loansPath, loan.id, {
      'totalPaid': current.toDouble() + p.amount,
      'status': loan.status.name,
    });
    await _audit('payment', 'loan', loan.id,
        '${p.addedByName} recorded ${p.amount}');
  }

  // ---------------- Locker ----------------

  Stream<List<LockerDoc>> lockerStream({String? ownerType, String? ownerId}) {
    return _stream(
      '$_bizPath/${AppConstants.documentsCol}',
      from: LockerDoc.fromMap,
      where: (m) {
        if (ownerType != null &&
            ownerType.isNotEmpty &&
            m['ownerType'] != ownerType) {
          return false;
        }
        if (ownerId != null &&
            ownerId.isNotEmpty &&
            m['ownerId'] != ownerId) {
          return false;
        }
        return true;
      },
    );
  }

  Future<void> saveLockerDoc(LockerDoc d) async {
    final path = '$_bizPath/${AppConstants.documentsCol}';
    if (d.id.isEmpty) {
      await _store.add(path, d.toMap());
    } else {
      await _store.set(path, d.id, d.toMap());
    }
  }

  Future<void> deleteLockerDoc(LockerDoc d) async {
    await _store.delete('$_bizPath/${AppConstants.documentsCol}', d.id);
  }

  // ---------------- Tasks / Expenses / Templates / Staff ----------------

  Stream<List<Task>> get tasksStream =>
      _stream('$_bizPath/${AppConstants.tasksCol}', from: Task.fromMap);

  Future<void> saveTask(Task t) async {
    final path = '$_bizPath/${AppConstants.tasksCol}';
    if (t.id.isEmpty) {
      await _store.add(path, t.toMap());
    } else {
      await _store.update(path, t.id, t.toMap());
    }
  }

  Future<void> deleteTask(String id) async {
    await _store.delete('$_bizPath/${AppConstants.tasksCol}', id);
  }

  Stream<List<Expense>> get expensesStream =>
      _stream('$_bizPath/${AppConstants.expensesCol}', from: Expense.fromMap);

  Future<void> saveExpense(Expense e) async {
    final path = '$_bizPath/${AppConstants.expensesCol}';
    if (e.id.isEmpty) {
      await _store.add(path, e.toMap());
    } else {
      await _store.update(path, e.id, e.toMap());
    }
  }

  Future<void> deleteExpense(String id) async {
    await _store.delete('$_bizPath/${AppConstants.expensesCol}', id);
  }

  Stream<List<LoanTemplate>> get templatesStream => _stream(
        '$_bizPath/${AppConstants.templatesCol}',
        from: LoanTemplate.fromMap,
      );

  Future<void> saveTemplate(LoanTemplate t) async {
    final path = '$_bizPath/${AppConstants.templatesCol}';
    if (t.id.isEmpty) {
      await _store.add(path, t.toMap());
    } else {
      await _store.set(path, t.id, t.toMap());
    }
  }

  Future<void> deleteTemplate(String id) async {
    await _store.delete('$_bizPath/${AppConstants.templatesCol}', id);
  }

  Stream<List<StaffMember>> get staffStream =>
      _stream('$_bizPath/${AppConstants.staffCol}', from: StaffMember.fromMap);

  Future<void> saveStaff(StaffMember s) async {
    final path = '$_bizPath/${AppConstants.staffCol}';
    if (s.id.isEmpty) {
      await _store.add(path, s.toMap());
    } else {
      await _store.set(path, s.id, s.toMap());
    }
  }

  Future<void> deleteStaff(String id) async {
    await _store.delete('$_bizPath/${AppConstants.staffCol}', id);
  }

  // ---------------- Audit log ----------------

  Future<void> _audit(
      String action, String entity, String entityId, String detail) async {
    if (!hasContext) return;
    // 'at' is stored as an ISO string so ordering survives JSON reloads.
    await _store.add('$_bizPath/${AppConstants.auditLogCol}', {
      'action': action,
      'entity': entity,
      'entityId': entityId,
      'byUid': _uidReal,
      'byName': _userName,
      'at': DateTime.now().toIso8601String(),
      'detail': detail,
    });
  }

  Stream<List<AuditEntry>> get auditStream => _stream(
        '$_bizPath/${AppConstants.auditLogCol}',
        from: AuditEntry.fromMap,
        sort: (a, b) =>
            _key(b.at).compareTo(_key(a.at)),
        limit: 200,
      );

  // ---------------- Calc history ----------------

  Future<void> saveCalcSummary(String summary) =>
      _store.add('$_bizPath/${AppConstants.calcsCol}', {
        'summary': summary,
        'savedAt': DateTime.now().toIso8601String(),
      });

  /// Raw maps: the calculator screen only reads the 'summary' key.
  Stream<List<Map<String, dynamic>>> get calcHistoryStream {
    return _store
        .watch('$_bizPath/${AppConstants.calcsCol}')
        .map((col) {
      final items = col.entries.map((e) => {
            'id': e.key,
            ...e.value,
          }).toList()
        ..sort((a, b) => _key(b['savedAt']).compareTo(_key(a['savedAt'])));
      if (items.length > 50) return items.sublist(0, 50);
      return items;
    });
  }

  static String _key(dynamic v) {
    if (v is DateTime) return v.toIso8601String();
    if (v is String) return v;
    return '';
  }
}
