import '../core/enums.dart';
import '../core/utils.dart';
import '../models/models.dart';

/// Pure interest/EMI calculation engine — no Flutter or Firebase dependency.
///
/// Supports the spec's three interest types across daily / weekly / monthly /
/// custom (every N months) cycles, fixed EMI counts or open-ended loans, and
/// upfront (deducted at disbursal) interest.
class EmiEngine {
  EmiEngine._();

  /// Full computed schedule for a loan. For open-ended loans returns at most
  /// 24 projected rows.
  static List<EmiRow> buildSchedule(Loan loan, {List<Payment>? payments}) {
    final rows = <EmiRow>[];
    final count = loan.openEnded || loan.emiCount <= 0 ? 24 : loan.emiCount;

    for (var i = 1; i <= count; i++) {
      final due = emiDue(loan, i);
      final dueDate = _dueDateFor(loan, i);
      rows.add(EmiRow(
        no: i,
        dueDate: dueDate,
        due: due,
        isInterestOnly: loan.interestType == InterestType.interestOnly,
      ));
    }

    // Distribute payments across the earliest unpaid rows (FIFO).
    if (payments != null) {
      final sorted = [...payments]..sort((a, b) => a.date.compareTo(b.date));
      var pool = sorted.fold<double>(0, (s, p) => s + p.amount);
      for (final row in rows) {
        if (pool <= 0) break;
        final applied = pool < row.due ? pool : row.due;
        row.paid += applied;
        pool -= applied;
      }
    }
    return rows;
  }

  /// The EMI amount for installment [no] (1-based).
  static double emiDue(Loan loan, int no) {
    switch (loan.category) {
      case LoanCategory.dailyCollection:
        // Fixed daily amount = principal spread over expected days, or the
        // stored emiAmount when the user set one explicitly.
        if (loan.emiAmount > 0) return loan.emiAmount;
        final n = loan.emiCount > 0 ? loan.emiCount : 30;
        return loan.principal * (1 + loan.rate / 100 * n / 30) / n;

      case LoanCategory.interest:
        switch (loan.interestType) {
          case InterestType.reducing:
            return _reducingEmi(loan);
          case InterestType.flat:
          case InterestType.interestOnly:
            return _flatEmi(loan, no);
        }
    }
  }

  /// Flat: equal installments of (principal + total interest) / n.
  /// Interest-only pays interest each cycle, principal in the last one.
  static double _flatEmi(Loan loan, int no) {
    final n = loan.emiCount > 0 ? loan.emiCount : 1;
    final perCycleMonths = cycleMonths(loan);
    if (loan.interestType == InterestType.interestOnly) {
      final interest = loan.principal * loan.rate / 100 * perCycleMonths;
      return no == n ? loan.principal + interest : interest;
    }
    final totalInterest =
        loan.principal * loan.rate / 100 * perCycleMonths * n;
    return (loan.principal + totalInterest) / n;
  }

  /// Reducing balance: standard amortized EMI on the per-cycle rate.
  static double _reducingEmi(Loan loan) {
    final n = loan.emiCount > 0 ? loan.emiCount : 1;
    final r = loan.rate / 100 / cycleMonths(loan);
    if (r <= 0) return loan.principal / n;
    final f = _pow(1 + r, n);
    return loan.principal * r * f / (f - 1);
  }

  /// Total payable over the loan lifetime (principal + interest + fees).
  static double totalPayable(Loan loan) {
    if (loan.totalPayable > 0) return loan.totalPayable;
    if (loan.emiCount <= 0 && !loan.openEnded) return loan.principal;
    final n = loan.openEnded ? 24 : loan.emiCount;
    var sum = 0.0;
    for (var i = 1; i <= n; i++) {
      sum += emiDue(loan, i);
    }
    return sum + loan.processingFee;
  }

  static int cycleMonths(Loan loan) =>
      loan.cycle == PaymentCycle.monthly || loan.cycle == PaymentCycle.custom
          ? loan.everyNMonths <= 0
              ? 1
              : loan.everyNMonths
          : 1;

  static DateTime _dueDateFor(Loan loan, int installmentNo) {
    var d = loan.startDate;
    for (var i = 0; i < installmentNo; i++) {
      d = Utils.addCycle(d, loan.cycle, loan.everyNMonths);
    }
    return d;
  }

  static double _pow(double x, int n) {
    var result = 1.0;
    for (var i = 0; i < n; i++) {
      result *= x;
    }
    return result;
  }

  // ------------------------------------------------------------------
  // Standalone calculator results (also used by the calculator screen).
  // ------------------------------------------------------------------

  static LoanScheduleSummary summarize({
    required double principal,
    required double ratePctPerMonth,
    required InterestType interestType,
    required PaymentCycle cycle,
    int everyNMonths = 1,
    required int installments,
  }) {
    final loan = Loan(
      id: 'calc',
      businessId: '',
      borrowerId: '',
      borrowerName: '',
      principal: principal,
      rate: ratePctPerMonth,
      interestType: interestType,
      cycle: cycle,
      everyNMonths: everyNMonths,
      emiCount: installments,
      startDate: DateTime.now(),
    );
    final rows = <EmiRow>[];
    var total = 0.0;
    for (var i = 1; i <= installments; i++) {
      final due = emiDue(loan, i);
      total += due;
      rows.add(EmiRow(no: i, dueDate: _dueDateFor(loan, i), due: due));
    }
    return LoanScheduleSummary(
      emi: installments > 0 ? rows.first.due : 0,
      totalPayable: total,
      totalInterest: total - principal,
      rows: rows,
    );
  }
}

/// Result of a calculator run.
class LoanScheduleSummary {
  LoanScheduleSummary({
    required this.emi,
    required this.totalPayable,
    required this.totalInterest,
    required this.rows,
  });

  final double emi;
  final double totalPayable;
  final double totalInterest;
  final List<EmiRow> rows;
}
