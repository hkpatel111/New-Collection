import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

/// Uploads borrower/collateral/locker photos to Firebase Storage and keeps
/// download URLs in Firestore.
class StorageService {
  StorageService._();
  static final instance = StorageService._();

  final ImagePicker _picker = ImagePicker();

  Future<XFile?> pickImage({required bool fromCamera}) async =>
      _picker.pickImage(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 1600,
        imageQuality: 70,
      );

  Future<String> uploadFile(String path, {String? folder}) async {
    final file = File(path);
    final ext = path.contains('.') ? path.split('.').last : 'jpg';
    final ref = FirebaseStorage.instance
        .ref()
        .child(folder ?? 'misc')
        .child('${const Uuid().v4()}.$ext');
    await ref.putFile(file);
    return ref.getDownloadURL();
  }

  Future<void> deleteFile(String url) async {
    try {
      await FirebaseStorage.instance.refFromURL(url).delete();
    } catch (_) {
      // Already gone or URL not a storage URL — safe to ignore.
    }
  }
}
