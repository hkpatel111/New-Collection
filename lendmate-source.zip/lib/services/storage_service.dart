import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

/// Picks borrower/collateral/locker photos and keeps them on-device (app
/// documents directory). Models store the local file path; `isRemoteUrl`
/// tells UI code whether to render with Image.network or Image.file.
class StorageService {
  StorageService._();
  static final instance = StorageService._();

  final ImagePicker _picker = ImagePicker();

  static bool isRemoteUrl(String url) =>
      url.startsWith('http://') || url.startsWith('https://');

  Future<XFile?> pickImage({required bool fromCamera}) async =>
      _picker.pickImage(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 1600,
        imageQuality: 70,
      );

  /// Copies the picked file into app storage and returns its new path.
  Future<String> uploadFile(String path, {String? folder}) async {
    final src = File(path);
    if (!await src.exists()) return path;
    final dir = await getApplicationDocumentsDirectory();
    final target = Directory('${dir.path}/${folder ?? 'misc'}');
    if (!await target.exists()) {
      await target.create(recursive: true);
    }
    final ext = path.contains('.') ? path.split('.').last : 'jpg';
    final dest = File('${target.path}/${const Uuid().v4()}.$ext');
    await src.copy(dest.path);
    return dest.path;
  }

  Future<void> deleteFile(String url) async {
    if (isRemoteUrl(url)) return; // legacy remote URL — nothing local to do
    try {
      final f = File(url);
      if (await f.exists()) await f.delete();
    } catch (_) {
      // Already gone — safe to ignore.
    }
  }
}
