import 'package:crypto/crypto.dart';
import 'dart:convert';

import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';

/// App Lock: locally stored hashed PIN + device biometrics.
class AppLockService {
  AppLockService._();
  static final instance = AppLockService._();

  final LocalAuthentication _auth = LocalAuthentication();

  Future<bool> isEnabled() async =>
      (await SharedPreferences.getInstance()).getBool(AppConstants.prefLockEnabled) ?? false;

  Future<void> setEnabled(bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(AppConstants.prefLockEnabled, v);
  }

  Future<void> setPin(String pin) async {
    final p = await SharedPreferences.getInstance();
    final hash = sha256.convert(utf8.encode('lendmate:$pin')).toString();
    await p.setString(AppConstants.prefLockPin, hash);
  }

  Future<bool> verifyPin(String pin) async {
    final p = await SharedPreferences.getInstance();
    final stored = p.getString(AppConstants.prefLockPin);
    if (stored == null) return false;
    return sha256.convert(utf8.encode('lendmate:$pin')).toString() == stored;
  }

  Future<bool> hasPin() async =>
      (await SharedPreferences.getInstance()).containsKey(AppConstants.prefLockPin);

  Future<bool> deviceHasBiometrics() async =>
      await _auth.isDeviceSupported() && await _auth.canCheckBiometrics;

  Future<bool> authenticateBiometric() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'Unlock LendMate',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}
