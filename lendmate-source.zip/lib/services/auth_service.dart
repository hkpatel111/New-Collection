import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../core/constants.dart';

/// Wraps Firebase Auth: phone OTP login, optional Google sign-in, account
/// deletion with re-authentication and session/device list.
class AuthService {
  AuthService._();
  static final instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  String? _verificationId;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// True when the placeholder firebase_options.dart has not been replaced yet.
  bool get isConfigured =>
      _auth.app.options.apiKey != 'PLACEHOLDER_RUN_FLUTTERFIRE_CONFIGURE';

  // ---------------- Phone OTP ----------------

  Future<void> sendOtp({
    required String phone,
    required VoidSuccess onCodeSent,
    required VoidError onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async {
        await _auth.signInWithCredential(cred);
        await _ensureUserDoc();
        onCodeSent();
      },
      verificationFailed: (e) => onError(e.message ?? 'Verification failed'),
      codeSent: (verificationId, resendToken) {
        _verificationId = verificationId;
        onCodeSent();
      },
      codeAutoRetrievalTimeout: (verificationId) {
        _verificationId = verificationId;
      },
    );
  }

  Future<void> verifyOtp(String otp) async {
    if (_verificationId == null) {
      throw Exception('Request a new OTP first.');
    }
    final cred = PhoneAuthProvider.credential(
      verificationId: _verificationId!,
      smsCode: otp,
    );
    await _auth.signInWithCredential(cred);
    await _ensureUserDoc();
  }

  // ---------------- Google ----------------

  Future<void> signInWithGoogle() async {
    final googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return; // cancelled
    final googleAuth = await googleUser.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    await _auth.signInWithCredential(cred);
    await _ensureUserDoc();
  }

  // ---------------- Account management ----------------

  Future<void> signOut() async {
    await GoogleSignIn().signOut().catchError((_) {});
    await _auth.signOut();
  }

  /// Deletes the Firebase Auth user after re-login (re-authentication).
  Future<void> deleteAccount(String phone, VoidError onError) async {
    final user = _auth.currentUser;
    if (user == null) return;
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phone,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (cred) async {
          await user.reauthenticateWithCredential(cred);
          await _deleteUserData(user.uid);
          await user.delete();
        },
        verificationFailed: (e) => onError(e.message ?? 'Re-auth failed'),
        codeSent: (verificationId, _) async {},
        codeAutoRetrievalTimeout: (_) {},
      );
    } on FirebaseAuthException catch (e) {
      onError(e.message ?? e.code);
    }
  }

  Future<void> _ensureUserDoc() async {
    final user = _auth.currentUser;
    if (user == null) return;
    final ref = _db.collection(AppConstants.usersCol).doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'phone': user.phoneNumber ?? '',
        'email': user.email ?? '',
        'name': user.displayName ?? '',
        'photoUrl': user.photoURL ?? '',
        'businessIds': <String>[],
        'createdAt': FieldValue.serverTimestamp(),
        'lastSeenAt': FieldValue.serverTimestamp(),
      });
    } else {
      await ref.update({'lastSeenAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> _deleteUserData(String uid) async {
    final batch = _db.batch();
    final owned = await _db
        .collection(AppConstants.businessesCol)
        .where('ownerId', isEqualTo: uid)
        .get();
    for (final doc in owned.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  /// Firestore doc id list of this user's registered sessions (devices).
  Stream<QuerySnapshot<Map<String, dynamic>>> sessionsStream() => _db
      .collection(AppConstants.usersCol)
      .doc(_auth.currentUser?.uid ?? 'none')
      .collection('sessions')
      .snapshots();
}

typedef VoidSuccess = void Function();
typedef VoidError = void Function(String message);
