import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

// ===========================================================================
// LocalStore — offline document database (replaces Firestore entirely).
//
// Data is kept as path-keyed collections, mirroring the old Firestore layout:
//   'businesses'
//   'businesses/{bid}/borrowers'
//   'businesses/{bid}/loans/{lid}/payments'
//   ...
//
// Every collection is a map of docId -> data. The whole database is persisted
// as a single JSON blob in SharedPreferences after each mutation and loaded
// once at startup. Streams notify watchers whose path is the mutated path,
// an ancestor of it, or a descendant of it, so higher-level collections
// (e.g. loans) re-emit when a child (payments) changes.
// ===========================================================================

typedef LocalCollection = Map<String, Map<String, dynamic>>;

class LocalStore {
  LocalStore._();
  static final LocalStore instance = LocalStore._();

  static const String _prefKey = 'lendmate_local_db';

  final Map<String, LocalCollection> _cols = {};
  final Map<String, StreamController<LocalCollection>> _controllers = {};
  bool _loaded = false;

  Future<void> _pendingPersist = Future.value();

  /// Loads the persisted database. Must be awaited before runApp.
  Future<void> init() async {
    if (_loaded) return;
    _loaded = true;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefKey);
    if (raw == null || raw.isEmpty) return;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      decoded.forEach((path, docs) {
        if (docs is Map<String, dynamic>) {
          _cols[path] = {
            for (final e in docs.entries)
              if (e.value is Map)
                e.key: Map<String, dynamic>.from(e.value as Map),
          };
        }
      });
    } catch (_) {
      // Corrupt payload — start fresh rather than crash at boot.
      _cols.clear();
    }
  }

  // ---------------------------------------------------------------- reads --

  /// Synchronous snapshot of one collection (empty when it doesn't exist).
  LocalCollection snapshot(String path) {
    final col = _cols[path];
    if (col == null) return const {};
    return Map<String, Map<String, dynamic>>.unmodifiable(col);
  }

  /// Live view of [path]: emits the current contents immediately, then a new
  /// snapshot whenever [path] itself or any path above/below it changes.
  Stream<LocalCollection> watch(String path) async* {
    yield snapshot(path);
    yield* _controller(path).stream;
  }

  // --------------------------------------------------------------- writes --

  /// Adds a new doc with a fresh id, returns the id.
  Future<String> add(String path, Map<String, dynamic> data) async {
    final id = const Uuid().v4();
    _col(path)[id] = Map<String, dynamic>.from(data);
    await _commit(path);
    return id;
  }

  /// Creates or fully replaces a doc.
  Future<void> set(String path, String id, Map<String, dynamic> data) async {
    _col(path)[id] = Map<String, dynamic>.from(data);
    await _commit(path);
  }

  /// Merges [patch] into an existing doc (creates it when missing).
  Future<void> update(
      String path, String id, Map<String, dynamic> patch) async {
    final col = _col(path);
    final existing = col[id] ?? <String, dynamic>{};
    col[id] = Map<String, dynamic>.from(existing)
      ..removeWhere((_, v) => v == null)
      ..addAll(patch);
    await _commit(path);
  }

  Future<void> delete(String path, String id) async {
    final col = _cols[path];
    if (col == null || !col.containsKey(id)) return;
    col.remove(id);
    await _commit(path);
  }

  // ------------------------------------------------------------ internals --

  LocalCollection _col(String path) =>
      _cols.putIfAbsent(path, () => <String, Map<String, dynamic>>{});

  StreamController<LocalCollection> _controller(String path) =>
      _controllers.putIfAbsent(
          path, () => StreamController<LocalCollection>.broadcast());

  Future<void> _commit(String changedPath) async {
    // Notify every watcher related to the change (self, ancestors, children).
    for (final entry in _controllers.entries) {
      if (_related(entry.key, changedPath)) {
        entry.value.add(snapshot(entry.key));
      }
    }
    // Serialize persistence so a slow write can never clobber a newer one.
    _pendingPersist = _pendingPersist.then((_) => _persist());
    await _pendingPersist;
  }

  bool _related(String watcherPath, String changedPath) {
    if (watcherPath == changedPath) return true;
    if (changedPath.startsWith('$watcherPath/')) return true;
    return watcherPath.startsWith('$changedPath/');
  }

  Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = <String, dynamic>{
        for (final e in _cols.entries) e.key: e.value,
      };
      await prefs.setString(
        _prefKey,
        jsonEncode(data, toEncodable: (o) {
          if (o is DateTime) return o.toIso8601String();
          return o.toString();
        }),
      );
    } catch (_) {
      // Never crash the app over a persistence hiccup; in-memory state stays
      // authoritative for the session.
    }
  }

  /// Test-only: wipe everything.
  Future<void> resetForTest() async {
    _cols.clear();
    for (final c in _controllers.values) {
      c.close();
    }
    _controllers.clear();
    _loaded = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefKey);
  }
}
