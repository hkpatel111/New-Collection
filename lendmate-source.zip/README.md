# LendMate 📱💰

**Loan + Khata management app** — Flutter, **fully offline**. Saara data sirf device
par rehta hai (SharedPreferences local DB) — koi server, koi login, koi OTP nahi.

> Source code `LendMate_Features_List.md` spec ke mutabik ready hai.
> Flutter SDK install hone ke baad sirf 2 steps me Android APK ban jayega (neeche dekho).

## ✨ Features (spec ke mutabik)

- 🔓 **Direct open** — app kholo, seedha dashboard. No setup/login wall.
- 🏪 **Multi-Business** support — ek jagah kai businesses, switcher ke saath
- 👥 **Borrowers** — pin, custom fields, search, detail page, per-borrower loans
- 📒 **Customers (Khata)** — gave/got ledger, balance, PDF statement, WhatsApp share
- 💸 **Loans** — Interest + Daily Collection, Flat / Reducing / Interest-Only,
  daily-weekly-monthly-custom cycles, upfront interest, open-ended, guarantor,
  collateral (+value tracker), bill no., notes, live EMI preview
- 🧾 **Payments** — single + **bulk entry**, late fee, payment history, auto status
- 📅 **Due Calendar** + Collection dashboard (aaj / hafta / mahina) + **Profit & Loss**
- 🧮 **Calculator** — cycle-by-cycle breakdown + history (local)
- 📷 **AI Scan (OCR)** — draft entry flow (ML Kit hook ready, pluggable)
- 🔐 **Document Locker** — camera/gallery images device par save hote hain
- 👔 **Staff** + roles, audit log (kaun kab kya kiya)
- 🔔 **Tasks** with local alarm notifications
- 💸 **Expense Tracker** with monthly summary
- 📤 **Export** — PDF statements/bills, PNG image, **CSV/Excel**, WhatsApp share
- 🌐 **3 languages**: English / हिन्दी / ગુજરાતી
- 🌓 Dark/Light theme
- 🔒 **App Lock** — 4-digit PIN (SHA-256 hashed) + fingerprint/biometric
- 🚫 No Play Billing, no IAP, no subscription — spec ke mutabik removed

## 🚀 Android App kaise banaye (2 steps)

### Step 0 — Flutter install (agar nahi hai)
https://docs.flutter.dev/get-started/install/windows

Check karo:
```bash
flutter doctor
```

### Step 1 — Flutter project folders generate karo
Project root me:
```bash
flutter create . --org com.lendmate --project-name lendmate --platforms android
```
Ye `android/` folder + launcher icons generate karega (existing `lib/`, `test/`, `pubspec.yaml` ko touch nahi karta).

> Firebase ya kisi bhi cloud config ki **jarurat nahi hai** — setup step hat gaya hai.

### Step 2 — Android permissions add karo
`android/app/src/main/AndroidManifest.xml` me `<manifest>` ke andar (application ke bahar) ye add karo:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.USE_BIOMETRIC"/>
<uses-permission android:name="android.permission.USE_FINGERPRINT"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
```

### Step 3 — Build APK
```bash
flutter pub get
flutter run                # phone pe test
flutter build apk --release   # APK: build/app/outputs/flutter-apk/app-release.apk
```

CI se auto build bhi ho jata hai — `.github/workflows/build-apk.yml` zip extract
karta hai, test + analyze chalata hai, aur APK artifact upload karta hai.

## 🗄️ Offline data layout

Ek hi local DB (`SharedPreferences` key `lendmate_local_db`), JSON blob me:

```
businesses/{businessId}                  ← ownerId = 'local'
  borrowers/{id}
  customers/{id}/entries/{entryId}       ← khata ledger
  loans/{id}/payments/{paymentId}
  documents/{id}                         ← locker (app documents dir me files)
  tasks/{id}  expenses/{id}  auditLog/{id}
  loanTemplates/{id}  staff/{id}  reminders/{id}
```

`LocalStore` path-keyed collections chalata hai + change events broadcast karta
hai; `Repository` same API se typed streams deta hai (purane FirestoreService
call-sites ke liye drop-in).

> ⚠️ Data sirf usi device par hai — uninstall karne se delete ho jayega.
> (Backup/export feature add karna ho to bolo.)

## ⚠️ Notes

- **OCR fully automatic tab hoga jab** `google_mlkit_text_recognition` package add
  karke `OcrService._recognize()` me plug karoge (hook already ready hai).
- App Lock PIN device par locally (hashed) store hota hai — privacy-safe.
- Test: `flutter test` (EMI engine ke unit tests included)

## 📁 Structure

```
lib/
  core/        theme, constants, enums, utils, localizations (en/hi/gu)
  models/      domain models (toMap/fromMap, ISO date strings)
  services/    local store, repository, emi engine, export(pdf/csv),
               storage, notifications, ocr hook, app lock
  providers/   auth (offline session) + settings + live data (provider package)
  screens/     15+ screens (dashboard → sab modules)
```
