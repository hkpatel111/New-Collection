# LendMate 📱💰

**Loan + Khata management app** — Flutter + Firebase. Fully online (server is source of truth).

> Source code `LendMate_Features_List.md` spec ke mutabik ready hai.
> Flutter SDK install hone ke baad sirf 3 steps me Android APK ban jayega (neeche dekho).

## ✨ Features (spec ke mutabik)

- 📞 Phone OTP + Google login (Firebase Auth)
- 🏪 **Multi-Business** support — ek account me kai businesses, switcher ke saath
- 👥 **Borrowers** — pin, custom fields, search, detail page, per-borrower loans
- 📒 **Customers (Khata)** — gave/got ledger, balance, PDF statement, WhatsApp share
- 💸 **Loans** — Interest + Daily Collection, Flat / Reducing / Interest-Only,
  daily-weekly-monthly-custom cycles, upfront interest, open-ended, guarantor,
  collateral (+value tracker), bill no., notes, live EMI preview
- 🧾 **Payments** — single + **bulk entry**, late fee, payment history, auto status
- 📅 **Due Calendar** + Collection dashboard (aaj / hafta / mahina) + **Profit & Loss**
- 🧮 **Calculator** — cycle-by-cycle breakdown + history (Firestore)
- 📷 **AI Scan (OCR)** — draft entry flow (ML Kit hook ready, pluggable)
- 🔐 **Document Locker** — camera/gallery upload → Firebase Storage
- 👔 **Staff** + roles, audit log (kaun kab kya kiya)
- 🔔 **Tasks** with local alarm notifications
- 💸 **Expense Tracker** with monthly summary
- 📤 **Export** — PDF statements/bills, PNG image, **CSV/Excel**, WhatsApp share
- 🌐 **3 languages**: English / हिन्दी / ગુજરાતી
- 🌓 Dark/Light theme
- 🔒 **App Lock** — 4-digit PIN (SHA-256 hashed) + fingerprint/biometric
- 🚫 No Play Billing, no IAP, no subscription — spec ke mutabik removed

## 🚀 Android App kaise banaye (3 steps)

### Step 0 — Flutter install (agar nahi hai)
https://docs.flutter.dev/get-started/install/windows

Check karo:
```bash
flutter doctor
```

### Step 1 — Flutter project folders generate karo
Project root me:
```bash
flutter create . --org com.lendmate --project-name lendmate --platforms android
```
Ye `android/` folder + launcher icons generate karega (existing `lib/`, `test/`, `pubspec.yaml` ko touch nahi karta).

### Step 2 — Firebase connect karo
1. https://console.firebase.google.com → project banao
2. **Authentication** → Sign-in method → **Phone** (+ **Google**) enable karo
3. **Firestore Database** → create (production mode)
4. **Storage** → create
5. Ab project root me:
```bash
dart pub global activate flutterfire_cli
dart run flutterfire configure
```
   → ye real `lib/firebase_options.dart` generate karega (placeholder replace ho jayega)

6. `android/app/google-services.json` Firebase console se download karke copy karo
   (flutterfire configure usually ye khud kar deta hai)

### Step 3 — Android permissions add karo
`android/app/src/main/AndroidManifest.xml` me `<manifest>` ke andar (application ke bahar) ye add karo:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
<uses-permission android:name="android.permission.USE_BIOMETRIC"/>
<uses-permission android:name="android.permission.USE_FINGERPRINT"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
```
Aur `<application>` tag me (Google Sign-In ke liye) apna SHA-1 + Web Client ID setup karo
(Firebase console → Authentication → Google → steps wahan milenge).

### Step 4 — Build APK
```bash
flutter pub get
flutter run                # phone pe test
flutter build apk --release   # APK: build/app/outputs/flutter-apk/app-release.apk
```

## 🔥 Firestore data layout

```
users/{uid}
businesses/{businessId}                  ← ownerId = uid
  borrowers/{id}
  customers/{id}/entries/{entryId}       ← khata ledger
  loans/{id}/payments/{paymentId}
  documents/{id}                         ← locker
  tasks/{id}  expenses/{id}  auditLog/{id}
  loanTemplates/{id}  staff/{id}  reminders/{id}
syncRequests/{id}                        ← ledger sync (phone-key based)
```

## ⚠️ Notes

- **OCR fully automatic tab hoga jab** `google_mlkit_text_recognition` package add
  karke `OcrService._recognize()` me plug karoge (hook already ready hai).
- **Due-day auto reminders (server side)** ke liye ek scheduled Cloud Function
  chahiye jo `loans` scan karke WhatsApp/SMS/FCM bheje — client code + reminder
  history logging ready hai.
- **Ledger Sync** request/accept flow Firestore me already wired hai
  (`syncRequests` collection, phone-key identity).
- App Lock PIN device par locally (hashed) store hota hai — privacy-safe.
- Test: `flutter test` (EMI engine ke 10 unit tests included)

## 📁 Structure

```
lib/
  core/        theme, constants, enums, utils, localizations (en/hi/gu)
  models/      Firestore models (toMap/fromMap)
  services/    auth, firestore, emi engine, export(pdf/csv), storage,
               notifications, ocr hook, app lock
  providers/   auth + settings + live data (provider package)
  screens/     15+ screens (login → dashboard → sab modules)
```
