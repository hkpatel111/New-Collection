# LendMate – Complete Features List (Final Spec)

> **App Name:** LendMate  
> **Nature:** Fully online, standalone loan + khata management app  
> **No Google Play dependency • No In-App Purchases • No old app traces**  
> **Tech Direction:** Flutter (lightweight + smooth) + Firebase (simple & generic)

---

## 1. Core Concept

**LendMate** is a digital Khata + Loan management app for money lenders and individuals.

Two main entity types:
- **Borrowers** → Interest-bearing loans
- **Customers** → Simple non-interest Khata (give / take)

**Languages:** English, Hindi, Gujarati  
**Architecture:** Fully online (server is source of truth)

---

## 2. Authentication & Account

- Phone number login (OTP)
- Google Sign-In (optional)
- Account deletion with re-authentication
- Sign out
- Active sessions / devices list
- No subscription or payment screens

---

## 3. Business / Lender Profile

- Business name
- Logo / profile picture
- Address & contact details
- Details appear on receipts, loan bills, statements, PDFs & shared images
- **Multi-Business Support** → One user can manage multiple businesses

---

## 4. Borrowers Management

- Add / Edit / Delete Borrower
- Fields: Name, Mobile, Address, Notes, Documents/Photos
- Borrower profile page
- Search & filter
- **Pin Important Borrowers** (top pe fix)
- Messaging settings per borrower (Record updates + Due reminders)
- Mobile number required for reminders & ledger sync
- **Custom Fields** support (user-defined extra fields)

---

## 5. Customers (Non-Interest Khata)

- Separate list from Borrowers
- Simple give / take ledger (no interest)
- Balance = You gave − You got
- AI Scan support
- Sync Khata with customer (if both use app)
- Khata statement generation
- **Custom Fields** support

---

## 6. Loan Types & Interest Calculation

### Loan Categories
1. **Interest Loan**
2. **Daily Collection** (fixed daily amount)

### Interest Types
- Flat Rate
- Reducing Balance
- Interest Only
- Upfront interest support

### Payment Cycles
- Daily / Weekly / Monthly / Custom (every X months)
- Fixed number of EMIs or open-ended

### Additional Loan Features
- Principal, Rate, Processing fee
- Guarantor (name + phone)
- Collateral (note + photos + value + return date)
- **Collateral Value Tracker** (approx current value)
- Bill number
- Disbursement mode
- Notes + **Voice Notes**
- Start date
- **Loan Templates** (save & reuse common loan setups)
- **Group / Joint Loan** (2-3 people on one loan)
- **Loan Transfer** (staff se staff ko shift)

---

## 7. Payments & EMI Management

- Record full / partial payment
- Automatic EMI schedule
- Late fee (optional)
- Overdue tracking
- Settle / Close loan
- Mute loan
- Payment history
- **Bulk Payment Entry** (ek saath kai borrowers ki payment)
- **Voice Notes** on payment

---

## 8. AI / OCR Scan

- Camera or Gallery
- Reads printed numbers + handwriting
- Creates draft entries for review (Loan or Khata)
- Bulk scan support
- Requires internet

---

## 9. Document Locker

- Store photos of documents (ID, agreements, collateral etc.)
- Organized per borrower / loan

---

## 10. Reports & Documents

- Loan Statement
- Loan Bill / Agreement page
- Borrower-wise report
- Khata Statement
- Export as PDF or Image
- **Excel / CSV Export** (full data)
- **Quick WhatsApp Share** (statement seedha WhatsApp pe)
- Business logo printed on documents

---

## 11. Calculator

- Standalone interest calculator
- Supports Flat / Reducing / Interest-Only
- Cycle-by-cycle breakdown
- Calculation history

---

## 12. Staff / Multi-user

- Add staff members
- Staff can create loans, customers, payments
- “Added by” attribution
- Basic role management
- **Loan Transfer** between staff

---

## 13. Auto Reminders & Messaging

- Due-day auto reminders
- Channels: WhatsApp / SMS (via backend)
- Per-borrower toggle (Record updates + Due reminders)
- Daily collection loans excluded
- **Payment Reminder History** (kitni baar reminder gaya)

---

## 14. Ledger Sync (Peer-to-Peer)

- Sync full loan ledger with Borrower
- Sync Khata with Customer
- Request → Accept / Reject flow
- Options: Sync from now OR Share full history
- Requires verified phone number on both sides

---

## 15. Tasks / To-Do

- Add personal or business tasks
- Task reminders / alarms

---

## 16. Dashboard / Home

- Active Loans overview
- Totals (Principal, Payable, Balance etc.)
- Filters (Active / Settled / Closed / Muted / Added by me / Staff)
- Search
- Quick actions: Calculator, Locker, Payment, Reports, Staff
- **Collection Dashboard** → Aaj / Is hafte / Is mahine kitna collect hua
- **Due Calendar View** → Pura mahina ek nazar mein overdue + upcoming
- **Profit & Loss Summary** → Kitna interest kamaya, kitna overdue
- **Home Screen Widget** → Today’s collection / overdue (optional)

---

## 17. App Lock & Security

- App Lock (PIN + Biometric / Fingerprint)
- Unlock required to open the app
- **Audit Log** → Kaun kab kya change kiya (important actions)

---

## 18. Expense Tracker (Simple)

- Lender ke apne business expenses track karna
- Category + amount + date + note
- Simple monthly summary

---

## 19. Backup

- **Current:** No backup feature (data already on server)
- **Future:** Google Drive backup

---

## 20. Notifications

- Due payment reminders
- Sync requests
- Task alarms
- System notifications with action buttons

---

## 21. Settings

- Language (English / Hindi / Gujarati)
- Appearance (Light / Dark)
- App Lock settings
- Notification preferences
- Account management
- Business profile
- Multi-business switcher
- About

---

## 22. Explicitly Removed

| Feature                        | Status                  |
|--------------------------------|-------------------------|
| Google Play Billing            | Removed                 |
| In-App Purchases               | Removed                 |
| Pro / Premium / Subscription   | Removed                 |
| Any old app name or branding   | Removed                 |
| Play Store license check       | Removed                 |

---

## 23. Complete Feature Summary

### Core Modules
| Module                    | Status |
|---------------------------|--------|
| Borrowers                 | Yes    |
| Customers (Khata)         | Yes    |
| Loans & EMI               | Yes    |
| Payments                  | Yes    |
| AI Scan (OCR)             | Yes    |
| Document Locker           | Yes    |
| Reports + PDF + Excel     | Yes    |
| Calculator                | Yes    |
| Staff                     | Yes    |
| Auto Reminders            | Yes    |
| Ledger Sync               | Yes    |
| App Lock + Biometric      | Yes    |
| Tasks                     | Yes    |
| Multi-Business            | Yes    |

### Extra Power Features (All Included)
| Feature                        | Status |
|--------------------------------|--------|
| Due Calendar View              | Yes    |
| Collection Dashboard           | Yes    |
| Bulk Payment Entry             | Yes    |
| Loan Templates                 | Yes    |
| Excel / CSV Export             | Yes    |
| UPI Payment Link               | Yes    |
| Voice Notes                    | Yes    |
| Group / Joint Loan             | Yes    |
| Loan Transfer (Staff)          | Yes    |
| Audit Log                      | Yes    |
| Quick WhatsApp Share           | Yes    |
| Home Screen Widget             | Yes    |
| Pin Important Borrowers        | Yes    |
| Payment Reminder History       | Yes    |
| Collateral Value Tracker       | Yes    |
| Simple Expense Tracker         | Yes    |
| Custom Fields                  | Yes    |
| Profit & Loss Summary          | Yes    |

### Future
| Feature                        | Status     |
|--------------------------------|------------|
| Google Drive Backup            | Later      |
| Offline Mode                   | Later      |
| Multi-currency                 | Later      |

---

**This is the complete and final feature list for LendMate.**  
All requested features (original + extra) are included.
